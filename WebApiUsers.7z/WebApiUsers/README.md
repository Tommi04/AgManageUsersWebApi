# dotnet-6-crud-api

.NET 6.0 - CRUD API Example

Documentation at https://jasonwatmore.com/post/2022/03/15/net-6-crud-api-example-and-tutorial