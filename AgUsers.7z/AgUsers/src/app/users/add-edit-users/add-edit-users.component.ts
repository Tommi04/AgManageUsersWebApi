import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { SharedService } from "src/app/shared.service";
import {citiesList} from "src/app/cities/citiesList";

@Component({
  selector: 'app-add-edit-users',
  templateUrl: './add-edit-users.component.html',
  styleUrls: ['./add-edit-users.component.css']
})
export class AddEditUsersComponent implements OnInit {


  @Input() users:any;
  id:string = "";
  firstname: string ="";
  lastname: string ="";
  country: string ="";
  cities: any;
  selectedValue = null;

  @Output() close = new EventEmitter<string>();

  constructor(private service: SharedService) { }

  ngOnInit(): void {
    this.id = this.users.id;
    this.firstname = this.users.firstname;
    this.lastname = this.users.lastname;
    this.country = this.users.country;
    this.cities = citiesList;
  }

  addUsers(){
    var val = {
      firstname:this.firstname,
      lastname:this.lastname,
      country:this.country
    };
    if(this.firstname == '' || this.lastname == '' || this.country == ''){
      alert('Inserire tutti i campi!');
      return;
    }
    this.service.addUsers(val).subscribe({
      next: data => {
        alert('Utente aggiunto con successo!');
        this.close.emit();
      },
      error: error => {
        alert('Errore, utente non inserito!');
      }})
  }

  updateUsers(){
    var val = {
      firstname:this.firstname,
      lastname:this.lastname,
      country:this.country};
      if(this.firstname == '' || this.lastname == '' || this.country == ''){
        alert('Inserire tutti i campi!');
        return;
      }
      this.service.updateUsers(this.id, val).subscribe({
        next: data => {
          alert('Utente id: '+this.id+' modificato con successo!');
          this.close.emit();
        },
        error: error => {
          alert('Errore, utente id: '+this.id+' non modificato!');
        }
      })
  }



}
