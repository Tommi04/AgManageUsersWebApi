import { SharedService } from "src/app/shared.service";

import { Component, Inject, OnInit, Input, Output, EventEmitter, AfterViewInit, OnDestroy, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSelect } from '@angular/material/select';
import { UntypedFormControl } from '@angular/forms';

import {City, citiesList} from "src/app/cities/citiesList";

import { ReplaySubject, Subject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-add-edit-users',
  templateUrl: './add-edit-users.component.html',
  styleUrls: ['./add-edit-users.component.css']
})
export class AddEditUsersComponent implements OnInit, AfterViewInit, OnDestroy {

  @Input() users:any;
  id:string = "";
  firstname: string ="";
  lastname: string ="";
  country: string ="";

  public title: string | undefined;

  /** list of banks */
  protected cities: City[] = citiesList;

  /** controllo per le citt� selezionate */
  public city: UntypedFormControl = new UntypedFormControl();

  /** controllo per il filtro della MatSelect  */
  public cityFilterCtrl: UntypedFormControl = new UntypedFormControl();

  /** lista delle citt� filtrate per la parola da ricercare */
  public filteredCities: ReplaySubject<City[]> = new ReplaySubject<City[]>(1);

  @ViewChild('singleSelect', { static: true }) singleSelect!: MatSelect;

  /** Subject that emits when the component has been destroyed. */
  protected _onDestroy = new Subject<void>();

  @Output() close = new EventEmitter<string>();

  constructor(private service: SharedService,
    @Inject(MAT_DIALOG_DATA) private data: any,
    private dialogRef: MatDialogRef<AddEditUsersComponent>
    )
    {
      if(data){
        this.users = data.users;
        this.title = data.title;
      }
    }

  ngOnInit(): void {
    this.id = this.users.id;
    this.firstname = this.users.firstname;
    this.lastname = this.users.lastname;
    this.country = this.users.country;

    this.city.setValue(this.country);

    // load the initial bank list
    this.filteredCities.next( this.cities.slice());

    // listen for search field value changes
    this.cityFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterCities();
      });
  }

  ngAfterViewInit(): void {
    this.setInitialValue();
  }
  ngOnDestroy(): void {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  /**
   * setta il valore iniziale dopo che filteredCities sono state caricate
   */
   protected setInitialValue() {
    this.filteredCities
      .pipe(take(0), takeUntil(this._onDestroy))
      .subscribe(() => {
        this.singleSelect.compareWith = (a: City, b: City) => a && b && a.name === b.name;
      });
  }

  protected filterCities() {
    if (!this.cities) {
      return;
    }
    let search = this.cityFilterCtrl.value;
    if (!search) {
      this.filteredCities.next(this.cities.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filtra le citt�
    this.filteredCities.next(
    this.cities.filter((city: { name: string; }) => city.name.toLowerCase().indexOf(search) > -1)
    );
  }

  addUsers(){
    var val = {
      firstname:this.firstname,
      lastname:this.lastname,
      country:this.city.value
    };
    console.log(this.city.value);
    if(val.firstname == '' || val.lastname == '' || val.country == ''){
      alert('Inserire tutti i campi!');
      return;
    }
    this.service.addUsers(val).subscribe({
      next: data => {
        alert('Utente aggiunto con successo!');
      },
      error: error => {
        alert('Errore, utente non inserito!');
      }
    })
    this.onCloseButton();
  }

  updateUsers(){
    var val = {
      firstname:this.firstname,
      lastname:this.lastname,
      country:this.city.value
    };
    if(val.firstname == '' || val.lastname == '' || val.country == ''){
      alert('Inserire tutti i campi!');
      return;
    }
    this.service.updateUsers(this.id, val).subscribe({
      next: data => {
        alert('Utente id: '+this.id+' modificato con successo!');
      },
      error: error => {
        alert('Errore, utente id: '+this.id+' non modificato!');
      }
    })
    this.onCloseButton();
  }

  onCloseButton(): void {
    this.dialogRef.close(true);
  }
}
