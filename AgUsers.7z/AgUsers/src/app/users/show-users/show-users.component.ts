import { Component, OnInit, ViewChild } from '@angular/core';
import { SharedService } from "src/app/shared.service";
import {citiesList} from "src/app/cities/citiesList";
import { ButtonModifyComponent } from 'src/app/buttons/buttonModify.component';
import { ButtonDeleteComponent } from 'src/app/buttons/buttonDelete.component';
import {AddEditUsersComponent} from 'src/app/users/add-edit-users/add-edit-users.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-show-users',
  templateUrl: './show-users.component.html',
  styleUrls: ['./show-users.component.css']
})
export class ShowUsersComponent implements OnInit {
  components: any;
  users:any;

  columnDefs = [
    { field: 'firstname', headerName:'Nome'},
    { field: 'lastname', headerName:'Cognome'},
    { field: 'codCat', headerName:'Citta\'' },
    {
      headerName: '',
      cellRenderer: 'buttonModify',
      cellRendererParams: {
        onClick: this.editUser.bind(this),
      }
    },
    {
      headerName: '',
      cellRenderer: 'buttonDelete',
      cellRendererParams: {
        onClick: this.deleteUser.bind(this),
      }
    }
  ];
  defaultColDef = {
    sortable: true,
    filter: true
  };

  rowData:any = [];

  constructor(private sharedService: SharedService, private dialog: MatDialog,) {
    this.components = {
      buttonModify: ButtonModifyComponent,
      buttonDelete: ButtonDeleteComponent,
    }
   }

  ngOnInit(): void {
    this.refreshUsersList();
  }

  refreshUsersList() {
    this.sharedService.getUsersList().subscribe(data =>{
      this.rowData = data;
      this.rowData.forEach((user:any) => {
        const city: any = citiesList.find( c => c.codCat === user.country);
        user.codCat = city.name;
      });
    });
  }

  openDialog(users: object, title: string) {
    const dialog = this.dialog.open(AddEditUsersComponent,{
      data:{
        users: users,
        title: title
      }
    });
    dialog.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        this.refreshUsersList();
      }
    });
  }

  AddUsers(){
    this.users={
      id:0,
      firstname:"",
      lastname:"",
      country:""
    }
    this.openDialog( this.users, 'Aggiungi un utente');
  }

  editUser(item: any){
    this.users = item;
    this.openDialog( this.users, 'Modifica utente');
  }

  deleteUser(item: any){
    if(confirm('Sei sicuro??')){
      this.sharedService.deleteUsers(item.id).subscribe({
        next: data => {
            this.refreshUsersList();
            alert('Utente id: '+item.id+' cancellato con successo!');
        },
        error: error => {
          alert('Errore, utente id: '+item.id+' non cancellato!');
        }})
    }
  }
}
