import { Component, OnInit, ViewChild } from '@angular/core';
import { SharedService } from "src/app/shared.service";
import {citiesList} from "src/app/cities/citiesList";
import { ButtonModifyComponent } from 'src/app/buttons/buttonModify.component';
import { ButtonDeleteComponent } from 'src/app/buttons/buttonDelete.component';

@Component({
  selector: 'app-show-users',
  templateUrl: './show-users.component.html',
  styleUrls: ['./show-users.component.css']
})
export class ShowUsersComponent implements OnInit {
  usersList:any = [];
  modalTitle:any;
  activateAddEditUsersCom:boolean = false;
  components: any;
  users:any;

  columnDefs = [
    { field: 'firstname', headerName:'Nome'},
    { field: 'lastname', headerName:'Cognome'},
    { field: 'codCat', headerName:'Citta\'' },
    {
      headerName: '',
      cellRenderer: 'buttonModify',
      cellRendererParams: {
        onClick: this.editUser.bind(this),
      }
    },
    {
      headerName: '',
      cellRenderer: 'buttonDelete',
      cellRendererParams: {
        onClick: this.deleteUser.bind(this),
      }
    }
  ];
  defaultColDef = {
    sortable: true,
    filter: true
  };

  rowData:any = [];


  @ViewChild('closebutton') closebutton: any;

  constructor(private sharedService: SharedService) {
    this.components = {
      buttonModify: ButtonModifyComponent,
      buttonDelete: ButtonDeleteComponent,
    }
   }

  ngOnInit(): void {
    this.refreshUsersList();
  }

  refreshUsersList() {
    this.sharedService.getUsersList().subscribe(data =>{
      this.rowData = data;
      this.rowData.forEach((user:any) => {
        const city: any = citiesList.find( c => c.codCat === user.country);
        user.codCat = city.name;
      });
    });
  }

  AddUsers(){
    this.users={
      id:0,
      firstname:"",
      lastname:"",
      country:""
    }
    this.modalTitle = "Aggiungi utente";
    this.activateAddEditUsersCom = true;
  }

  editUser(item: any){
    this.users = item;
    this.activateAddEditUsersCom = true;
    this.modalTitle = "Aggiorna utente";
  }

  deleteUser(item: any){
    if(confirm('Sei sicuro??')){
      this.sharedService.deleteUsers(item.id).subscribe({
        next: data => {
            this.refreshUsersList();
            this.closeClick();
            alert('Utente id: '+item.id+' cancellato con successo!');
        },
        error: error => {
          alert('Errore, utente id: '+item.id+' non cancellato!');
        }})
    }
  }

  closeClick(){
    this.activateAddEditUsersCom=false;
    this.refreshUsersList();
    this.closebutton.nativeElement.click();
  }


  onBtnClick1(e: { rowData: any; }) {
    this.users = e.rowData;
  }
}
