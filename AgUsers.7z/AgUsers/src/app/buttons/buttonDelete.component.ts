import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'app-button-delete',
  template: `<button class="btn btn-danger float-right h1"
                    type="button"
                    (click)="onClick()"
                >Elimina</button>`
})

export class ButtonDeleteComponent implements ICellRendererAngularComp {

  params: any;

  agInit(params: any): void {
    this.params = params;
  }

  refresh(params?: any): boolean {
    return true;
  }

  onClick() {
    if (this.params.onClick instanceof Function) {
        this.params.onClick(this.params.node.data);
    }
  }
}