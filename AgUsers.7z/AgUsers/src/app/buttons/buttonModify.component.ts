import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'app-button-modify',
  template: `<button class="btn btn-primary float-right h1"
                    type="button"
                    data-bs-toggle="modal"
                    data-bs-target="#userModal"
                    (click)="onClick()"
                >Modifica</button>`
})

export class ButtonModifyComponent implements ICellRendererAngularComp {

  params: any;
  label: string | undefined;

  agInit(params: any): void {
    this.params = params;
    this.label = this.params.label || null;
  }

  refresh(params?: any): boolean {
    return true;
  }

  onClick() {
    if (this.params.onClick instanceof Function) {
        this.params.onClick(this.params.node.data);
    }
  }
}