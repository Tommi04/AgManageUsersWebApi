import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  readonly APIUrl = "http://localhost:7149";
  constructor(private http: HttpClient) { }

  getUsersList(): Observable<any[]>{
    return this.http.get<any>(this.APIUrl + '/Users');
  }

  addUsers(val:any){
    return this.http.post(this.APIUrl + '/Users',val);
  }

  updateUsers(id:any, val:any){
    return this.http.put(this.APIUrl + '/Users/'+id, val);
  }

  deleteUsers(id: any){
    return this.http.delete(this.APIUrl + '/Users/'+id);
  }

}
