
export interface City {
    name: string;
    codCat: string;
  }


export const citiesList: City[] =
    [
        {
            name: "Seleziona una città",
            codCat: ""
        },
        {
            name: "Agliè",
            codCat: "A074"
        },
        {
            name: "Airasca",
            codCat: "A109"
        },
        {
            name: "Ala di Stura",
            codCat: "A117"
        },
        {
            name: "Albiano d'Ivrea",
            codCat: "A157"
        },
        {
            name: "Almese",
            codCat: "A218"
        },
        {
            name: "Alpette",
            codCat: "A221"
        },
        {
            name: "Alpignano",
            codCat: "A222"
        },
        {
            name: "Andezeno",
            codCat: "A275"
        },
        {
            name: "Andrate",
            codCat: "A282"
        },
        {
            name: "Angrogna",
            codCat: "A295"
        },
        {
            name: "Arignano",
            codCat: "A405"
        },
        {
            name: "Avigliana",
            codCat: "A518"
        },
        {
            name: "Azeglio",
            codCat: "A525"
        },
        {
            name: "Bairo",
            codCat: "A584"
        },
        {
            name: "Balangero",
            codCat: "A587"
        },
        {
            name: "Baldissero Canavese",
            codCat: "A590"
        },
        {
            name: "Baldissero Torinese",
            codCat: "A591"
        },
        {
            name: "Balme",
            codCat: "A599"
        },
        {
            name: "Banchette",
            codCat: "A607"
        },
        {
            name: "Barbania",
            codCat: "A625"
        },
        {
            name: "Bardonecchia",
            codCat: "A651"
        },
        {
            name: "Barone Canavese",
            codCat: "A673"
        },
        {
            name: "Beinasco",
            codCat: "A734"
        },
        {
            name: "Bibiana",
            codCat: "A853"
        },
        {
            name: "Bobbio Pellice",
            codCat: "A910"
        },
        {
            name: "Bollengo",
            codCat: "A941"
        },
        {
            name: "Borgaro Torinese",
            codCat: "A990"
        },
        {
            name: "Borgiallo",
            codCat: "B003"
        },
        {
            name: "Borgofranco d'Ivrea",
            codCat: "B015"
        },
        {
            name: "Borgomasino",
            codCat: "B021"
        },
        {
            name: "Borgone Susa",
            codCat: "B024"
        },
        {
            name: "Bosconero",
            codCat: "B075"
        },
        {
            name: "Brandizzo",
            codCat: "B121"
        },
        {
            name: "Bricherasio",
            codCat: "B171"
        },
        {
            name: "Brosso",
            codCat: "B205"
        },
        {
            name: "Brozolo",
            codCat: "B209"
        },
        {
            name: "Bruino",
            codCat: "B216"
        },
        {
            name: "Brusasco",
            codCat: "B225"
        },
        {
            name: "Bruzolo",
            codCat: "B232"
        },
        {
            name: "Buriasco",
            codCat: "B278"
        },
        {
            name: "Burolo",
            codCat: "B279"
        },
        {
            name: "Busano",
            codCat: "B284"
        },
        {
            name: "Bussoleno",
            codCat: "B297"
        },
        {
            name: "Buttigliera Alta",
            codCat: "B305"
        },
        {
            name: "Cafasse",
            codCat: "B350"
        },
        {
            name: "Caluso",
            codCat: "B435"
        },
        {
            name: "Cambiano",
            codCat: "B462"
        },
        {
            name: "Campiglione Fenile",
            codCat: "B512"
        },
        {
            name: "Candia Canavese",
            codCat: "B588"
        },
        {
            name: "Candiolo",
            codCat: "B592"
        },
        {
            name: "Canischio",
            codCat: "B605"
        },
        {
            name: "Cantalupa",
            codCat: "B628"
        },
        {
            name: "Cantoira",
            codCat: "B637"
        },
        {
            name: "Caprie",
            codCat: "B705"
        },
        {
            name: "Caravino",
            codCat: "B733"
        },
        {
            name: "Carema",
            codCat: "B762"
        },
        {
            name: "Carignano",
            codCat: "B777"
        },
        {
            name: "Carmagnola",
            codCat: "B791"
        },
        {
            name: "Casalborgone",
            codCat: "B867"
        },
        {
            name: "Cascinette d'Ivrea",
            codCat: "B953"
        },
        {
            name: "Caselette",
            codCat: "B955"
        },
        {
            name: "Caselle Torinese",
            codCat: "B960"
        },
        {
            name: "Castagneto Po",
            codCat: "C045"
        },
        {
            name: "Castagnole Piemonte",
            codCat: "C048"
        },
        {
            name: "Castellamonte",
            codCat: "C133"
        },
        {
            name: "Castelnuovo Nigra",
            codCat: "C241"
        },
        {
            name: "Castiglione Torinese",
            codCat: "C307"
        },
        {
            name: "Cavagnolo",
            codCat: "C369"
        },
        {
            name: "Cavour",
            codCat: "C404"
        },
        {
            name: "Cercenasco",
            codCat: "C487"
        },
        {
            name: "Ceres",
            codCat: "C497"
        },
        {
            name: "Ceresole Reale",
            codCat: "C505"
        },
        {
            name: "Cesana Torinese",
            codCat: "C564"
        },
        {
            name: "Chialamberto",
            codCat: "C604"
        },
        {
            name: "Chianocco",
            codCat: "C610"
        },
        {
            name: "Chiaverano",
            codCat: "C624"
        },
        {
            name: "Chieri",
            codCat: "C627"
        },
        {
            name: "Chiesanuova",
            codCat: "C629"
        },
        {
            name: "Chiomonte",
            codCat: "C639"
        },
        {
            name: "Chiusa di San Michele",
            codCat: "C655"
        },
        {
            name: "Chivasso",
            codCat: "C665"
        },
        {
            name: "Ciconio",
            codCat: "C679"
        },
        {
            name: "Cintano",
            codCat: "C711"
        },
        {
            name: "Cinzano",
            codCat: "C715"
        },
        {
            name: "Ciriè",
            codCat: "C722"
        },
        {
            name: "Claviere",
            codCat: "C793"
        },
        {
            name: "Coassolo Torinese",
            codCat: "C801"
        },
        {
            name: "Coazze",
            codCat: "C803"
        },
        {
            name: "Collegno",
            codCat: "C860"
        },
        {
            name: "Colleretto Castelnuovo",
            codCat: "C867"
        },
        {
            name: "Colleretto Giacosa",
            codCat: "C868"
        },
        {
            name: "Condove",
            codCat: "C955"
        },
        {
            name: "Corio",
            codCat: "D008"
        },
        {
            name: "Cossano Canavese",
            codCat: "D092"
        },
        {
            name: "Cuceglio",
            codCat: "D197"
        },
        {
            name: "Cumiana",
            codCat: "D202"
        },
        {
            name: "Cuorgnè",
            codCat: "D208"
        },
        {
            name: "Druento",
            codCat: "D373"
        },
        {
            name: "Exilles",
            codCat: "D433"
        },
        {
            name: "Favria",
            codCat: "D520"
        },
        {
            name: "Feletto",
            codCat: "D524"
        },
        {
            name: "Fenestrelle",
            codCat: "D532"
        },
        {
            name: "Fiano",
            codCat: "D562"
        },
        {
            name: "Fiorano Canavese",
            codCat: "D608"
        },
        {
            name: "Foglizzo",
            codCat: "D646"
        },
        {
            name: "Forno Canavese",
            codCat: "D725"
        },
        {
            name: "Frassinetto",
            codCat: "D781"
        },
        {
            name: "Front",
            codCat: "D805"
        },
        {
            name: "Frossasco",
            codCat: "D812"
        },
        {
            name: "Garzigliana",
            codCat: "D931"
        },
        {
            name: "Gassino Torinese",
            codCat: "D933"
        },
        {
            name: "Germagnano",
            codCat: "D983"
        },
        {
            name: "Giaglione",
            codCat: "E009"
        },
        {
            name: "Giaveno",
            codCat: "E020"
        },
        {
            name: "Givoletto",
            codCat: "E067"
        },
        {
            name: "Gravere",
            codCat: "E154"
        },
        {
            name: "Groscavallo",
            codCat: "E199"
        },
        {
            name: "Grosso",
            codCat: "E203"
        },
        {
            name: "Grugliasco",
            codCat: "E216"
        },
        {
            name: "Ingria",
            codCat: "E301"
        },
        {
            name: "Inverso Pinasca",
            codCat: "E311"
        },
        {
            name: "Isolabella",
            codCat: "E345"
        },
        {
            name: "Issiglio",
            codCat: "E368"
        },
        {
            name: "Ivrea",
            codCat: "E379"
        },
        {
            name: "La Cassa",
            codCat: "E394"
        },
        {
            name: "La Loggia",
            codCat: "E423"
        },
        {
            name: "Lanzo Torinese",
            codCat: "E445"
        },
        {
            name: "Lauriano",
            codCat: "E484"
        },
        {
            name: "Leini",
            codCat: "E518"
        },
        {
            name: "Lemie",
            codCat: "E520"
        },
        {
            name: "Lessolo",
            codCat: "E551"
        },
        {
            name: "Levone",
            codCat: "E566"
        },
        {
            name: "Locana",
            codCat: "E635"
        },
        {
            name: "Lombardore",
            codCat: "E660"
        },
        {
            name: "Lombriasco",
            codCat: "E661"
        },
        {
            name: "Loranzè",
            codCat: "E683"
        },
        {
            name: "Luserna San Giovanni",
            codCat: "E758"
        },
        {
            name: "Lusernetta",
            codCat: "E759"
        },
        {
            name: "Lusigliè",
            codCat: "E763"
        },
        {
            name: "Macello",
            codCat: "E782"
        },
        {
            name: "Maglione",
            codCat: "E817"
        },
        {
            name: "Marentino",
            codCat: "E941"
        },
        {
            name: "Massello",
            codCat: "F041"
        },
        {
            name: "Mathi",
            codCat: "F053"
        },
        {
            name: "Mattie",
            codCat: "F058"
        },
        {
            name: "Mazzè",
            codCat: "F067"
        },
        {
            name: "Meana di Susa",
            codCat: "F074"
        },
        {
            name: "Mercenasco",
            codCat: "F140"
        },
        {
            name: "Mezzenile",
            codCat: "F182"
        },
        {
            name: "Mombello di Torino",
            codCat: "F315"
        },
        {
            name: "Mompantero",
            codCat: "F318"
        },
        {
            name: "Monastero di Lanzo",
            codCat: "F327"
        },
        {
            name: "Moncalieri",
            codCat: "F335"
        },
        {
            name: "Moncenisio",
            codCat: "D553"
        },
        {
            name: "Montaldo Torinese",
            codCat: "F407"
        },
        {
            name: "Montalenghe",
            codCat: "F411"
        },
        {
            name: "Montalto Dora",
            codCat: "F420"
        },
        {
            name: "Montanaro",
            codCat: "F422"
        },
        {
            name: "Monteu da Po",
            codCat: "F651"
        },
        {
            name: "Moriondo Torinese",
            codCat: "F733"
        },
        {
            name: "Nichelino",
            codCat: "F889"
        },
        {
            name: "Noasca",
            codCat: "F906"
        },
        {
            name: "Nole",
            codCat: "F925"
        },
        {
            name: "Nomaglio",
            codCat: "F927"
        },
        {
            name: "None",
            codCat: "F931"
        },
        {
            name: "Novalesa",
            codCat: "F948"
        },
        {
            name: "Oglianico",
            codCat: "G010"
        },
        {
            name: "Orbassano",
            codCat: "G087"
        },
        {
            name: "Orio Canavese",
            codCat: "G109"
        },
        {
            name: "Osasco",
            codCat: "G151"
        },
        {
            name: "Osasio",
            codCat: "G152"
        },
        {
            name: "Oulx",
            codCat: "G196"
        },
        {
            name: "Ozegna",
            codCat: "G202"
        },
        {
            name: "Palazzo Canavese",
            codCat: "G262"
        },
        {
            name: "Pancalieri",
            codCat: "G303"
        },
        {
            name: "Parella",
            codCat: "G330"
        },
        {
            name: "Pavarolo",
            codCat: "G387"
        },
        {
            name: "Pavone Canavese",
            codCat: "G392"
        },
        {
            name: "Pecetto Torinese",
            codCat: "G398"
        },
        {
            name: "Perosa Argentina",
            codCat: "G463"
        },
        {
            name: "Perosa Canavese",
            codCat: "G462"
        },
        {
            name: "Perrero",
            codCat: "G465"
        },
        {
            name: "Pertusio",
            codCat: "G477"
        },
        {
            name: "Pessinetto",
            codCat: "G505"
        },
        {
            name: "Pianezza",
            codCat: "G559"
        },
        {
            name: "Pinasca",
            codCat: "G672"
        },
        {
            name: "Pinerolo",
            codCat: "G674"
        },
        {
            name: "Pino Torinese",
            codCat: "G678"
        },
        {
            name: "Piobesi Torinese",
            codCat: "G684"
        },
        {
            name: "Piossasco",
            codCat: "G691"
        },
        {
            name: "Piscina",
            codCat: "G705"
        },
        {
            name: "Piverone",
            codCat: "G719"
        },
        {
            name: "Poirino",
            codCat: "G777"
        },
        {
            name: "Pomaretto",
            codCat: "G805"
        },
        {
            name: "Pont Canavese",
            codCat: "G826"
        },
        {
            name: "Porte",
            codCat: "G900"
        },
        {
            name: "Pragelato",
            codCat: "G973"
        },
        {
            name: "Prali",
            codCat: "G978"
        },
        {
            name: "Pralormo",
            codCat: "G979"
        },
        {
            name: "Pramollo",
            codCat: "G982"
        },
        {
            name: "Prarostino",
            codCat: "G986"
        },
        {
            name: "Prascorsano",
            codCat: "G988"
        },
        {
            name: "Pratiglione",
            codCat: "G997"
        },
        {
            name: "Quagliuzzo",
            codCat: "H100"
        },
        {
            name: "Quassolo",
            codCat: "H120"
        },
        {
            name: "Quincinetto",
            codCat: "H127"
        },
        {
            name: "Reano",
            codCat: "H207"
        },
        {
            name: "Ribordone",
            codCat: "H270"
        },
        {
            name: "Rivalba",
            codCat: "H333"
        },
        {
            name: "Rivalta di Torino",
            codCat: "H335"
        },
        {
            name: "Riva presso Chieri",
            codCat: "H337"
        },
        {
            name: "Rivara",
            codCat: "H338"
        },
        {
            name: "Rivarolo Canavese",
            codCat: "H340"
        },
        {
            name: "Rivarossa",
            codCat: "H344"
        },
        {
            name: "Rivoli",
            codCat: "H355"
        },
        {
            name: "Robassomero",
            codCat: "H367"
        },
        {
            name: "Rocca Canavese",
            codCat: "H386"
        },
        {
            name: "Roletto",
            codCat: "H498"
        },
        {
            name: "Romano Canavese",
            codCat: "H511"
        },
        {
            name: "Ronco Canavese",
            codCat: "H539"
        },
        {
            name: "Rondissone",
            codCat: "H547"
        },
        {
            name: "Rorà",
            codCat: "H554"
        },
        {
            name: "Roure",
            codCat: "H555"
        },
        {
            name: "Rosta",
            codCat: "H583"
        },
        {
            name: "Rubiana",
            codCat: "H627"
        },
        {
            name: "Rueglio",
            codCat: "H631"
        },
        {
            name: "Salassa",
            codCat: "H691"
        },
        {
            name: "Salbertrand",
            codCat: "H684"
        },
        {
            name: "Salerano Canavese",
            codCat: "H702"
        },
        {
            name: "Salza di Pinerolo",
            codCat: "H734"
        },
        {
            name: "Samone",
            codCat: "H753"
        },
        {
            name: "San Benigno Canavese",
            codCat: "H775"
        },
        {
            name: "San Carlo Canavese",
            codCat: "H789"
        },
        {
            name: "San Colombano Belmonte",
            codCat: "H804"
        },
        {
            name: "San Didero",
            codCat: "H820"
        },
        {
            name: "San Francesco al Campo",
            codCat: "H847"
        },
        {
            name: "Sangano",
            codCat: "H855"
        },
        {
            name: "San Germano Chisone",
            codCat: "H862"
        },
        {
            name: "San Gillio",
            codCat: "H873"
        },
        {
            name: "San Giorgio Canavese",
            codCat: "H890"
        },
        {
            name: "San Giorio di Susa",
            codCat: "H900"
        },
        {
            name: "San Giusto Canavese",
            codCat: "H936"
        },
        {
            name: "San Martino Canavese",
            codCat: "H997"
        },
        {
            name: "San Maurizio Canavese",
            codCat: "I024"
        },
        {
            name: "San Mauro Torinese",
            codCat: "I030"
        },
        {
            name: "San Pietro Val Lemina",
            codCat: "I090"
        },
        {
            name: "San Ponso",
            codCat: "I126"
        },
        {
            name: "San Raffaele Cimena",
            codCat: "I137"
        },
        {
            name: "San Sebastiano da Po",
            codCat: "I152"
        },
        {
            name: "San Secondo di Pinerolo",
            codCat: "I154"
        },
        {
            name: "Sant'Ambrogio di Torino",
            codCat: "I258"
        },
        {
            name: "Sant'Antonino di Susa",
            codCat: "I296"
        },
        {
            name: "Santena",
            codCat: "I327"
        },
        {
            name: "Sauze di Cesana",
            codCat: "I465"
        },
        {
            name: "Sauze d'Oulx",
            codCat: "I466"
        },
        {
            name: "Scalenghe",
            codCat: "I490"
        },
        {
            name: "Scarmagno",
            codCat: "I511"
        },
        {
            name: "Sciolze",
            codCat: "I539"
        },
        {
            name: "Sestriere",
            codCat: "I692"
        },
        {
            name: "Settimo Rottaro",
            codCat: "I701"
        },
        {
            name: "Settimo Torinese",
            codCat: "I703"
        },
        {
            name: "Settimo Vittone",
            codCat: "I702"
        },
        {
            name: "Sparone",
            codCat: "I886"
        },
        {
            name: "Strambinello",
            codCat: "I969"
        },
        {
            name: "Strambino",
            codCat: "I970"
        },
        {
            name: "Susa",
            codCat: "L013"
        },
        {
            name: "Tavagnasco",
            codCat: "L066"
        },
        {
            name: "Torino",
            codCat: "L219"
        },
        {
            name: "Torrazza Piemonte",
            codCat: "L238"
        },
        {
            name: "Torre Canavese",
            codCat: "L247"
        },
        {
            name: "Torre Pellice",
            codCat: "L277"
        },
        {
            name: "Trana",
            codCat: "L327"
        },
        {
            name: "Traversella",
            codCat: "L345"
        },
        {
            name: "Traves",
            codCat: "L340"
        },
        {
            name: "Trofarello",
            codCat: "L445"
        },
        {
            name: "Usseaux",
            codCat: "L515"
        },
        {
            name: "Usseglio",
            codCat: "L516"
        },
        {
            name: "Vaie",
            codCat: "L538"
        },
        {
            name: "Val della Torre",
            codCat: "L555"
        },
        {
            name: "Valgioie",
            codCat: "L578"
        },
        {
            name: "Vallo Torinese",
            codCat: "L629"
        },
        {
            name: "Valperga",
            codCat: "L644"
        },
        {
            name: "Valprato Soana",
            codCat: "B510"
        },
        {
            name: "Varisella",
            codCat: "L685"
        },
        {
            name: "Vauda Canavese",
            codCat: "L698"
        },
        {
            name: "Venaus",
            codCat: "L726"
        },
        {
            name: "Venaria Reale",
            codCat: "L727"
        },
        {
            name: "Verolengo",
            codCat: "L779"
        },
        {
            name: "Verrua Savoia",
            codCat: "L787"
        },
        {
            name: "Vestignè",
            codCat: "L811"
        },
        {
            name: "Vialfrè",
            codCat: "L830"
        },
        {
            name: "Vidracco",
            codCat: "L857"
        },
        {
            name: "Vigone",
            codCat: "L898"
        },
        {
            name: "Villafranca Piemonte",
            codCat: "L948"
        },
        {
            name: "Villanova Canavese",
            codCat: "L982"
        },
        {
            name: "Villarbasse",
            codCat: "M002"
        },
        {
            name: "Villar Dora",
            codCat: "L999"
        },
        {
            name: "Villareggia",
            codCat: "M004"
        },
        {
            name: "Villar Focchiardo",
            codCat: "M007"
        },
        {
            name: "Villar Pellice",
            codCat: "M013"
        },
        {
            name: "Villar Perosa",
            codCat: "M014"
        },
        {
            name: "Villastellone",
            codCat: "M027"
        },
        {
            name: "Vinovo",
            codCat: "M060"
        },
        {
            name: "Virle Piemonte",
            codCat: "M069"
        },
        {
            name: "Vische",
            codCat: "M071"
        },
        {
            name: "Vistrorio",
            codCat: "M080"
        },
        {
            name: "Viù",
            codCat: "M094"
        },
        {
            name: "Volpiano",
            codCat: "M122"
        },
        {
            name: "Volvera",
            codCat: "M133"
        },
        {
            name: "Mappano",
            codCat: "M316"
        },
        {
            name: "Val di Chy",
            codCat: "M405"
        },
        {
            name: "Valchiusa",
            codCat: "M415"
        },
        {
            name: "Alagna Valsesia",
            codCat: "A119"
        },
        {
            name: "Albano Vercellese",
            codCat: "A130"
        },
        {
            name: "Alice Castello",
            codCat: "A198"
        },
        {
            name: "Arborio",
            codCat: "A358"
        },
        {
            name: "Asigliano Vercellese",
            codCat: "A466"
        },
        {
            name: "Balmuccia",
            codCat: "A600"
        },
        {
            name: "Balocco",
            codCat: "A601"
        },
        {
            name: "Bianzè",
            codCat: "A847"
        },
        {
            name: "Boccioleto",
            codCat: "A914"
        },
        {
            name: "Borgo d'Ale",
            codCat: "B009"
        },
        {
            name: "Borgosesia",
            codCat: "B041"
        },
        {
            name: "Borgo Vercelli",
            codCat: "B046"
        },
        {
            name: "Buronzo",
            codCat: "B280"
        },
        {
            name: "Campertogno",
            codCat: "B505"
        },
        {
            name: "Carcoforo",
            codCat: "B752"
        },
        {
            name: "Caresana",
            codCat: "B767"
        },
        {
            name: "Caresanablot",
            codCat: "B768"
        },
        {
            name: "Carisio",
            codCat: "B782"
        },
        {
            name: "Casanova Elvo",
            codCat: "B928"
        },
        {
            name: "San Giacomo Vercellese",
            codCat: "B952"
        },
        {
            name: "Cervatto",
            codCat: "C548"
        },
        {
            name: "Cigliano",
            codCat: "C680"
        },
        {
            name: "Civiasco",
            codCat: "C757"
        },
        {
            name: "Collobiano",
            codCat: "C884"
        },
        {
            name: "Costanzana",
            codCat: "D113"
        },
        {
            name: "Cravagliana",
            codCat: "D132"
        },
        {
            name: "Crescentino",
            codCat: "D154"
        },
        {
            name: "Crova",
            codCat: "D187"
        },
        {
            name: "Desana",
            codCat: "D281"
        },
        {
            name: "Fobello",
            codCat: "D641"
        },
        {
            name: "Fontanetto Po",
            codCat: "D676"
        },
        {
            name: "Formigliana",
            codCat: "D712"
        },
        {
            name: "Gattinara",
            codCat: "D938"
        },
        {
            name: "Ghislarengo",
            codCat: "E007"
        },
        {
            name: "Greggio",
            codCat: "E163"
        },
        {
            name: "Guardabosone",
            codCat: "E237"
        },
        {
            name: "Lamporo",
            codCat: "E433"
        },
        {
            name: "Lenta",
            codCat: "E528"
        },
        {
            name: "Lignana",
            codCat: "E583"
        },
        {
            name: "Livorno Ferraris",
            codCat: "E626"
        },
        {
            name: "Lozzolo",
            codCat: "E711"
        },
        {
            name: "Mollia",
            codCat: "F297"
        },
        {
            name: "Moncrivello",
            codCat: "F342"
        },
        {
            name: "Motta de' Conti",
            codCat: "F774"
        },
        {
            name: "Olcenengo",
            codCat: "G016"
        },
        {
            name: "Oldenico",
            codCat: "G018"
        },
        {
            name: "Palazzolo Vercellese",
            codCat: "G266"
        },
        {
            name: "Pertengo",
            codCat: "G471"
        },
        {
            name: "Pezzana",
            codCat: "G528"
        },
        {
            name: "Pila",
            codCat: "G666"
        },
        {
            name: "Piode",
            codCat: "G685"
        },
        {
            name: "Postua",
            codCat: "G940"
        },
        {
            name: "Prarolo",
            codCat: "G985"
        },
        {
            name: "Quarona",
            codCat: "H108"
        },
        {
            name: "Quinto Vercellese",
            codCat: "H132"
        },
        {
            name: "Rassa",
            codCat: "H188"
        },
        {
            name: "Rimella",
            codCat: "H293"
        },
        {
            name: "Rive",
            codCat: "H346"
        },
        {
            name: "Roasio",
            codCat: "H365"
        },
        {
            name: "Ronsecco",
            codCat: "H549"
        },
        {
            name: "Rossa",
            codCat: "H577"
        },
        {
            name: "Rovasenda",
            codCat: "H364"
        },
        {
            name: "Salasco",
            codCat: "H690"
        },
        {
            name: "Sali Vercellese",
            codCat: "H707"
        },
        {
            name: "Saluggia",
            codCat: "H725"
        },
        {
            name: "San Germano Vercellese",
            codCat: "H861"
        },
        {
            name: "Santhià",
            codCat: "I337"
        },
        {
            name: "Scopa",
            codCat: "I544"
        },
        {
            name: "Scopello",
            codCat: "I545"
        },
        {
            name: "Serravalle Sesia",
            codCat: "I663"
        },
        {
            name: "Stroppiana",
            codCat: "I984"
        },
        {
            name: "Tricerro",
            codCat: "L420"
        },
        {
            name: "Trino",
            codCat: "L429"
        },
        {
            name: "Tronzano Vercellese",
            codCat: "L451"
        },
        {
            name: "Valduggia",
            codCat: "L566"
        },
        {
            name: "Varallo",
            codCat: "L669"
        },
        {
            name: "Vercelli",
            codCat: "L750"
        },
        {
            name: "Villarboit",
            codCat: "M003"
        },
        {
            name: "Villata",
            codCat: "M028"
        },
        {
            name: "Vocca",
            codCat: "M106"
        },
        {
            name: "Alto Sermenza",
            codCat: "M389"
        },
        {
            name: "Cellio con Breia",
            codCat: "M398"
        },
        {
            name: "Agrate Conturbia",
            codCat: "A088"
        },
        {
            name: "Ameno",
            codCat: "A264"
        },
        {
            name: "Armeno",
            codCat: "A414"
        },
        {
            name: "Arona",
            codCat: "A429"
        },
        {
            name: "Barengo",
            codCat: "A653"
        },
        {
            name: "Bellinzago Novarese",
            codCat: "A752"
        },
        {
            name: "Biandrate",
            codCat: "A844"
        },
        {
            name: "Boca",
            codCat: "A911"
        },
        {
            name: "Bogogno",
            codCat: "A929"
        },
        {
            name: "Bolzano Novarese",
            codCat: "A953"
        },
        {
            name: "Borgolavezzaro",
            codCat: "B016"
        },
        {
            name: "Borgomanero",
            codCat: "B019"
        },
        {
            name: "Borgo Ticino",
            codCat: "B043"
        },
        {
            name: "Briga Novarese",
            codCat: "B176"
        },
        {
            name: "Briona",
            codCat: "B183"
        },
        {
            name: "Caltignaga",
            codCat: "B431"
        },
        {
            name: "Cameri",
            codCat: "B473"
        },
        {
            name: "Carpignano Sesia",
            codCat: "B823"
        },
        {
            name: "Casalbeltrame",
            codCat: "B864"
        },
        {
            name: "Casaleggio Novara",
            codCat: "B883"
        },
        {
            name: "Casalino",
            codCat: "B897"
        },
        {
            name: "Casalvolone",
            codCat: "B920"
        },
        {
            name: "Castellazzo Novarese",
            codCat: "C149"
        },
        {
            name: "Castelletto sopra Ticino",
            codCat: "C166"
        },
        {
            name: "Cavaglietto",
            codCat: "C364"
        },
        {
            name: "Cavaglio d'Agogna",
            codCat: "C365"
        },
        {
            name: "Cavallirio",
            codCat: "C378"
        },
        {
            name: "Cerano",
            codCat: "C483"
        },
        {
            name: "Colazza",
            codCat: "C829"
        },
        {
            name: "Comignago",
            codCat: "C926"
        },
        {
            name: "Cressa",
            codCat: "D162"
        },
        {
            name: "Cureggio",
            codCat: "D216"
        },
        {
            name: "Divignano",
            codCat: "D309"
        },
        {
            name: "Dormelletto",
            codCat: "D347"
        },
        {
            name: "Fara Novarese",
            codCat: "D492"
        },
        {
            name: "Fontaneto d'Agogna",
            codCat: "D675"
        },
        {
            name: "Galliate",
            codCat: "D872"
        },
        {
            name: "Garbagna Novarese",
            codCat: "D911"
        },
        {
            name: "Gargallo",
            codCat: "D921"
        },
        {
            name: "Ghemme",
            codCat: "E001"
        },
        {
            name: "Gozzano",
            codCat: "E120"
        },
        {
            name: "Granozzo con Monticello",
            codCat: "E143"
        },
        {
            name: "Grignasco",
            codCat: "E177"
        },
        {
            name: "Invorio",
            codCat: "E314"
        },
        {
            name: "Landiona",
            codCat: "E436"
        },
        {
            name: "Lesa",
            codCat: "E544"
        },
        {
            name: "Maggiora",
            codCat: "E803"
        },
        {
            name: "Mandello Vitta",
            codCat: "E880"
        },
        {
            name: "Marano Ticino",
            codCat: "E907"
        },
        {
            name: "Massino Visconti",
            codCat: "F047"
        },
        {
            name: "Meina",
            codCat: "F093"
        },
        {
            name: "Mezzomerico",
            codCat: "F188"
        },
        {
            name: "Miasino",
            codCat: "F191"
        },
        {
            name: "Momo",
            codCat: "F317"
        },
        {
            name: "Nebbiuno",
            codCat: "F859"
        },
        {
            name: "Nibbiola",
            codCat: "F886"
        },
        {
            name: "Novara",
            codCat: "F952"
        },
        {
            name: "Oleggio",
            codCat: "G019"
        },
        {
            name: "Oleggio Castello",
            codCat: "G020"
        },
        {
            name: "Orta San Giulio",
            codCat: "G134"
        },
        {
            name: "Paruzzaro",
            codCat: "G349"
        },
        {
            name: "Pella",
            codCat: "G421"
        },
        {
            name: "Pettenasco",
            codCat: "G520"
        },
        {
            name: "Pisano",
            codCat: "G703"
        },
        {
            name: "Pogno",
            codCat: "G775"
        },
        {
            name: "Pombia",
            codCat: "G809"
        },
        {
            name: "Prato Sesia",
            codCat: "H001"
        },
        {
            name: "Recetto",
            codCat: "H213"
        },
        {
            name: "Romagnano Sesia",
            codCat: "H502"
        },
        {
            name: "Romentino",
            codCat: "H518"
        },
        {
            name: "San Maurizio d'Opaglio",
            codCat: "I025"
        },
        {
            name: "San Nazzaro Sesia",
            codCat: "I052"
        },
        {
            name: "San Pietro Mosezzo",
            codCat: "I116"
        },
        {
            name: "Sillavengo",
            codCat: "I736"
        },
        {
            name: "Sizzano",
            codCat: "I767"
        },
        {
            name: "Soriso",
            codCat: "I857"
        },
        {
            name: "Sozzago",
            codCat: "I880"
        },
        {
            name: "Suno",
            codCat: "L007"
        },
        {
            name: "Terdobbiate",
            codCat: "L104"
        },
        {
            name: "Tornaco",
            codCat: "L223"
        },
        {
            name: "Trecate",
            codCat: "L356"
        },
        {
            name: "Vaprio d'Agogna",
            codCat: "L668"
        },
        {
            name: "Varallo Pombia",
            codCat: "L670"
        },
        {
            name: "Vespolate",
            codCat: "L808"
        },
        {
            name: "Vicolungo",
            codCat: "L847"
        },
        {
            name: "Vinzaglio",
            codCat: "M062"
        },
        {
            name: "Gattico-Veruno",
            codCat: "M416"
        },
        {
            name: "Acceglio",
            codCat: "A016"
        },
        {
            name: "Aisone",
            codCat: "A113"
        },
        {
            name: "Alba",
            codCat: "A124"
        },
        {
            name: "Albaretto della Torre",
            codCat: "A139"
        },
        {
            name: "Alto",
            codCat: "A238"
        },
        {
            name: "Argentera",
            codCat: "A394"
        },
        {
            name: "Arguello",
            codCat: "A396"
        },
        {
            name: "Bagnasco",
            codCat: "A555"
        },
        {
            name: "Bagnolo Piemonte",
            codCat: "A571"
        },
        {
            name: "Baldissero d'Alba",
            codCat: "A589"
        },
        {
            name: "Barbaresco",
            codCat: "A629"
        },
        {
            name: "Barge",
            codCat: "A660"
        },
        {
            name: "Barolo",
            codCat: "A671"
        },
        {
            name: "Bastia Mondovì",
            codCat: "A709"
        },
        {
            name: "Battifollo",
            codCat: "A716"
        },
        {
            name: "Beinette",
            codCat: "A735"
        },
        {
            name: "Bellino",
            codCat: "A750"
        },
        {
            name: "Belvedere Langhe",
            codCat: "A774"
        },
        {
            name: "Bene Vagienna",
            codCat: "A779"
        },
        {
            name: "Benevello",
            codCat: "A782"
        },
        {
            name: "Bergolo",
            codCat: "A798"
        },
        {
            name: "Bernezzo",
            codCat: "A805"
        },
        {
            name: "Bonvicino",
            codCat: "A979"
        },
        {
            name: "Borgomale",
            codCat: "B018"
        },
        {
            name: "Borgo San Dalmazzo",
            codCat: "B033"
        },
        {
            name: "Bosia",
            codCat: "B079"
        },
        {
            name: "Bossolasco",
            codCat: "B084"
        },
        {
            name: "Boves",
            codCat: "B101"
        },
        {
            name: "Bra",
            codCat: "B111"
        },
        {
            name: "Briaglia",
            codCat: "B167"
        },
        {
            name: "Briga Alta",
            codCat: "B175"
        },
        {
            name: "Brondello",
            codCat: "B200"
        },
        {
            name: "Brossasco",
            codCat: "B204"
        },
        {
            name: "Busca",
            codCat: "B285"
        },
        {
            name: "Camerana",
            codCat: "B467"
        },
        {
            name: "Canale",
            codCat: "B573"
        },
        {
            name: "Canosio",
            codCat: "B621"
        },
        {
            name: "Caprauna",
            codCat: "B692"
        },
        {
            name: "Caraglio",
            codCat: "B719"
        },
        {
            name: "Caramagna Piemonte",
            codCat: "B720"
        },
        {
            name: "Cardè",
            codCat: "B755"
        },
        {
            name: "Carrù",
            codCat: "B841"
        },
        {
            name: "Cartignano",
            codCat: "B845"
        },
        {
            name: "Casalgrasso",
            codCat: "B894"
        },
        {
            name: "Castagnito",
            codCat: "C046"
        },
        {
            name: "Casteldelfino",
            codCat: "C081"
        },
        {
            name: "Castelletto Stura",
            codCat: "C165"
        },
        {
            name: "Castelletto Uzzone",
            codCat: "C167"
        },
        {
            name: "Castellinaldo d'Alba",
            codCat: "C173"
        },
        {
            name: "Castellino Tanaro",
            codCat: "C176"
        },
        {
            name: "Castelmagno",
            codCat: "C205"
        },
        {
            name: "Castelnuovo di Ceva",
            codCat: "C214"
        },
        {
            name: "Castiglione Falletto",
            codCat: "C314"
        },
        {
            name: "Castiglione Tinella",
            codCat: "C317"
        },
        {
            name: "Castino",
            codCat: "C323"
        },
        {
            name: "Cavallerleone",
            codCat: "C375"
        },
        {
            name: "Cavallermaggiore",
            codCat: "C376"
        },
        {
            name: "Celle di Macra",
            codCat: "C441"
        },
        {
            name: "Centallo",
            codCat: "C466"
        },
        {
            name: "Ceresole Alba",
            codCat: "C504"
        },
        {
            name: "Cerretto Langhe",
            codCat: "C530"
        },
        {
            name: "Cervasca",
            codCat: "C547"
        },
        {
            name: "Cervere",
            codCat: "C550"
        },
        {
            name: "Ceva",
            codCat: "C589"
        },
        {
            name: "Cherasco",
            codCat: "C599"
        },
        {
            name: "Chiusa di Pesio",
            codCat: "C653"
        },
        {
            name: "Cigliè",
            codCat: "C681"
        },
        {
            name: "Cissone",
            codCat: "C738"
        },
        {
            name: "Clavesana",
            codCat: "C792"
        },
        {
            name: "Corneliano d'Alba",
            codCat: "D022"
        },
        {
            name: "Cortemilia",
            codCat: "D062"
        },
        {
            name: "Cossano Belbo",
            codCat: "D093"
        },
        {
            name: "Costigliole Saluzzo",
            codCat: "D120"
        },
        {
            name: "Cravanzana",
            codCat: "D133"
        },
        {
            name: "Crissolo",
            codCat: "D172"
        },
        {
            name: "Cuneo",
            codCat: "D205"
        },
        {
            name: "Demonte",
            codCat: "D271"
        },
        {
            name: "Diano d'Alba",
            codCat: "D291"
        },
        {
            name: "Dogliani",
            codCat: "D314"
        },
        {
            name: "Dronero",
            codCat: "D372"
        },
        {
            name: "Elva",
            codCat: "D401"
        },
        {
            name: "Entracque",
            codCat: "D410"
        },
        {
            name: "Envie",
            codCat: "D412"
        },
        {
            name: "Farigliano",
            codCat: "D499"
        },
        {
            name: "Faule",
            codCat: "D511"
        },
        {
            name: "Feisoglio",
            codCat: "D523"
        },
        {
            name: "Fossano",
            codCat: "D742"
        },
        {
            name: "Frabosa Soprana",
            codCat: "D751"
        },
        {
            name: "Frabosa Sottana",
            codCat: "D752"
        },
        {
            name: "Frassino",
            codCat: "D782"
        },
        {
            name: "Gaiola",
            codCat: "D856"
        },
        {
            name: "Gambasca",
            codCat: "D894"
        },
        {
            name: "Garessio",
            codCat: "D920"
        },
        {
            name: "Genola",
            codCat: "D967"
        },
        {
            name: "Gorzegno",
            codCat: "E111"
        },
        {
            name: "Gottasecca",
            codCat: "E115"
        },
        {
            name: "Govone",
            codCat: "E118"
        },
        {
            name: "Grinzane Cavour",
            codCat: "E182"
        },
        {
            name: "Guarene",
            codCat: "E251"
        },
        {
            name: "Igliano",
            codCat: "E282"
        },
        {
            name: "Isasca",
            codCat: "E327"
        },
        {
            name: "Lagnasco",
            codCat: "E406"
        },
        {
            name: "La Morra",
            codCat: "E430"
        },
        {
            name: "Lequio Berria",
            codCat: "E540"
        },
        {
            name: "Lequio Tanaro",
            codCat: "E539"
        },
        {
            name: "Lesegno",
            codCat: "E546"
        },
        {
            name: "Levice",
            codCat: "E564"
        },
        {
            name: "Limone Piemonte",
            codCat: "E597"
        },
        {
            name: "Lisio",
            codCat: "E615"
        },
        {
            name: "Macra",
            codCat: "E789"
        },
        {
            name: "Magliano Alfieri",
            codCat: "E809"
        },
        {
            name: "Magliano Alpi",
            codCat: "E808"
        },
        {
            name: "Mango",
            codCat: "E887"
        },
        {
            name: "Manta",
            codCat: "E894"
        },
        {
            name: "Marene",
            codCat: "E939"
        },
        {
            name: "Margarita",
            codCat: "E945"
        },
        {
            name: "Marmora",
            codCat: "E963"
        },
        {
            name: "Marsaglia",
            codCat: "E973"
        },
        {
            name: "Martiniana Po",
            codCat: "E988"
        },
        {
            name: "Melle",
            codCat: "F114"
        },
        {
            name: "Moiola",
            codCat: "F279"
        },
        {
            name: "Mombarcaro",
            codCat: "F309"
        },
        {
            name: "Mombasiglio",
            codCat: "F312"
        },
        {
            name: "Monastero di Vasco",
            codCat: "F326"
        },
        {
            name: "Monasterolo Casotto",
            codCat: "F329"
        },
        {
            name: "Monasterolo di Savigliano",
            codCat: "F330"
        },
        {
            name: "Monchiero",
            codCat: "F338"
        },
        {
            name: "Mondovì",
            codCat: "F351"
        },
        {
            name: "Monesiglio",
            codCat: "F355"
        },
        {
            name: "Monforte d'Alba",
            codCat: "F358"
        },
        {
            name: "Montà",
            codCat: "F385"
        },
        {
            name: "Montaldo di Mondovì",
            codCat: "F405"
        },
        {
            name: "Montaldo Roero",
            codCat: "F408"
        },
        {
            name: "Montanera",
            codCat: "F424"
        },
        {
            name: "Montelupo Albese",
            codCat: "F550"
        },
        {
            name: "Montemale di Cuneo",
            codCat: "F558"
        },
        {
            name: "Monterosso Grana",
            codCat: "F608"
        },
        {
            name: "Monteu Roero",
            codCat: "F654"
        },
        {
            name: "Montezemolo",
            codCat: "F666"
        },
        {
            name: "Monticello d'Alba",
            codCat: "F669"
        },
        {
            name: "Moretta",
            codCat: "F723"
        },
        {
            name: "Morozzo",
            codCat: "F743"
        },
        {
            name: "Murazzano",
            codCat: "F809"
        },
        {
            name: "Murello",
            codCat: "F811"
        },
        {
            name: "Narzole",
            codCat: "F846"
        },
        {
            name: "Neive",
            codCat: "F863"
        },
        {
            name: "Neviglie",
            codCat: "F883"
        },
        {
            name: "Niella Belbo",
            codCat: "F894"
        },
        {
            name: "Niella Tanaro",
            codCat: "F895"
        },
        {
            name: "Novello",
            codCat: "F961"
        },
        {
            name: "Nucetto",
            codCat: "F972"
        },
        {
            name: "Oncino",
            codCat: "G066"
        },
        {
            name: "Ormea",
            codCat: "G114"
        },
        {
            name: "Ostana",
            codCat: "G183"
        },
        {
            name: "Paesana",
            codCat: "G228"
        },
        {
            name: "Pagno",
            codCat: "G240"
        },
        {
            name: "Pamparato",
            codCat: "G302"
        },
        {
            name: "Paroldo",
            codCat: "G339"
        },
        {
            name: "Perletto",
            codCat: "G457"
        },
        {
            name: "Perlo",
            codCat: "G458"
        },
        {
            name: "Peveragno",
            codCat: "G526"
        },
        {
            name: "Pezzolo Valle Uzzone",
            codCat: "G532"
        },
        {
            name: "Pianfei",
            codCat: "G561"
        },
        {
            name: "Piasco",
            codCat: "G575"
        },
        {
            name: "Pietraporzio",
            codCat: "G625"
        },
        {
            name: "Piobesi d'Alba",
            codCat: "G683"
        },
        {
            name: "Piozzo",
            codCat: "G697"
        },
        {
            name: "Pocapaglia",
            codCat: "G742"
        },
        {
            name: "Polonghera",
            codCat: "G800"
        },
        {
            name: "Pontechianale",
            codCat: "G837"
        },
        {
            name: "Pradleves",
            codCat: "G970"
        },
        {
            name: "Prazzo",
            codCat: "H011"
        },
        {
            name: "Priero",
            codCat: "H059"
        },
        {
            name: "Priocca",
            codCat: "H068"
        },
        {
            name: "Priola",
            codCat: "H069"
        },
        {
            name: "Prunetto",
            codCat: "H085"
        },
        {
            name: "Racconigi",
            codCat: "H150"
        },
        {
            name: "Revello",
            codCat: "H247"
        },
        {
            name: "Rifreddo",
            codCat: "H285"
        },
        {
            name: "Rittana",
            codCat: "H326"
        },
        {
            name: "Roaschia",
            codCat: "H362"
        },
        {
            name: "Roascio",
            codCat: "H363"
        },
        {
            name: "Robilante",
            codCat: "H377"
        },
        {
            name: "Roburent",
            codCat: "H378"
        },
        {
            name: "Roccabruna",
            codCat: "H385"
        },
        {
            name: "Rocca Cigliè",
            codCat: "H391"
        },
        {
            name: "Rocca de' Baldi",
            codCat: "H395"
        },
        {
            name: "Roccaforte Mondovì",
            codCat: "H407"
        },
        {
            name: "Roccasparvera",
            codCat: "H447"
        },
        {
            name: "Roccavione",
            codCat: "H453"
        },
        {
            name: "Rocchetta Belbo",
            codCat: "H462"
        },
        {
            name: "Roddi",
            codCat: "H472"
        },
        {
            name: "Roddino",
            codCat: "H473"
        },
        {
            name: "Rodello",
            codCat: "H474"
        },
        {
            name: "Rossana",
            codCat: "H578"
        },
        {
            name: "Ruffia",
            codCat: "H633"
        },
        {
            name: "Sale delle Langhe",
            codCat: "H695"
        },
        {
            name: "Sale San Giovanni",
            codCat: "H704"
        },
        {
            name: "Saliceto",
            codCat: "H710"
        },
        {
            name: "Salmour",
            codCat: "H716"
        },
        {
            name: "Saluzzo",
            codCat: "H727"
        },
        {
            name: "Sambuco",
            codCat: "H746"
        },
        {
            name: "Sampeyre",
            codCat: "H755"
        },
        {
            name: "San Benedetto Belbo",
            codCat: "H770"
        },
        {
            name: "San Damiano Macra",
            codCat: "H812"
        },
        {
            name: "Sanfrè",
            codCat: "H851"
        },
        {
            name: "Sanfront",
            codCat: "H852"
        },
        {
            name: "San Michele Mondovì",
            codCat: "I037"
        },
        {
            name: "Sant'Albano Stura",
            codCat: "I210"
        },
        {
            name: "Santa Vittoria d'Alba",
            codCat: "I316"
        },
        {
            name: "Santo Stefano Belbo",
            codCat: "I367"
        },
        {
            name: "Santo Stefano Roero",
            codCat: "I372"
        },
        {
            name: "Savigliano",
            codCat: "I470"
        },
        {
            name: "Scagnello",
            codCat: "I484"
        },
        {
            name: "Scarnafigi",
            codCat: "I512"
        },
        {
            name: "Serralunga d'Alba",
            codCat: "I646"
        },
        {
            name: "Serravalle Langhe",
            codCat: "I659"
        },
        {
            name: "Sinio",
            codCat: "I750"
        },
        {
            name: "Somano",
            codCat: "I817"
        },
        {
            name: "Sommariva del Bosco",
            codCat: "I822"
        },
        {
            name: "Sommariva Perno",
            codCat: "I823"
        },
        {
            name: "Stroppo",
            codCat: "I985"
        },
        {
            name: "Tarantasca",
            codCat: "L048"
        },
        {
            name: "Torre Bormida",
            codCat: "L252"
        },
        {
            name: "Torre Mondovì",
            codCat: "L241"
        },
        {
            name: "Torre San Giorgio",
            codCat: "L278"
        },
        {
            name: "Torresina",
            codCat: "L281"
        },
        {
            name: "Treiso",
            codCat: "L367"
        },
        {
            name: "Trezzo Tinella",
            codCat: "L410"
        },
        {
            name: "Trinità",
            codCat: "L427"
        },
        {
            name: "Valdieri",
            codCat: "L558"
        },
        {
            name: "Valgrana",
            codCat: "L580"
        },
        {
            name: "Valloriate",
            codCat: "L631"
        },
        {
            name: "Venasca",
            codCat: "L729"
        },
        {
            name: "Verduno",
            codCat: "L758"
        },
        {
            name: "Vernante",
            codCat: "L771"
        },
        {
            name: "Verzuolo",
            codCat: "L804"
        },
        {
            name: "Vezza d'Alba",
            codCat: "L817"
        },
        {
            name: "Vicoforte",
            codCat: "L841"
        },
        {
            name: "Vignolo",
            codCat: "L888"
        },
        {
            name: "Villafalletto",
            codCat: "L942"
        },
        {
            name: "Villanova Mondovì",
            codCat: "L974"
        },
        {
            name: "Villanova Solaro",
            codCat: "L990"
        },
        {
            name: "Villar San Costanzo",
            codCat: "M015"
        },
        {
            name: "Vinadio",
            codCat: "M055"
        },
        {
            name: "Viola",
            codCat: "M063"
        },
        {
            name: "Vottignasco",
            codCat: "M136"
        },
        {
            name: "Agliano Terme",
            codCat: "A072"
        },
        {
            name: "Albugnano",
            codCat: "A173"
        },
        {
            name: "Antignano",
            codCat: "A312"
        },
        {
            name: "Aramengo",
            codCat: "A352"
        },
        {
            name: "Asti",
            codCat: "A479"
        },
        {
            name: "Azzano d'Asti",
            codCat: "A527"
        },
        {
            name: "Baldichieri d'Asti",
            codCat: "A588"
        },
        {
            name: "Belveglio",
            codCat: "A770"
        },
        {
            name: "Berzano di San Pietro",
            codCat: "A812"
        },
        {
            name: "Bruno",
            codCat: "B221"
        },
        {
            name: "Bubbio",
            codCat: "B236"
        },
        {
            name: "Buttigliera d'Asti",
            codCat: "B306"
        },
        {
            name: "Calamandrana",
            codCat: "B376"
        },
        {
            name: "Calliano",
            codCat: "B418"
        },
        {
            name: "Calosso",
            codCat: "B425"
        },
        {
            name: "Camerano Casasco",
            codCat: "B469"
        },
        {
            name: "Canelli",
            codCat: "B594"
        },
        {
            name: "Cantarana",
            codCat: "B633"
        },
        {
            name: "Capriglio",
            codCat: "B707"
        },
        {
            name: "Casorzo Monferrato",
            codCat: "B991"
        },
        {
            name: "Cassinasco",
            codCat: "C022"
        },
        {
            name: "Castagnole delle Lanze",
            codCat: "C049"
        },
        {
            name: "Castagnole Monferrato",
            codCat: "C047"
        },
        {
            name: "Castel Boglione",
            codCat: "C064"
        },
        {
            name: "Castell'Alfero",
            codCat: "C127"
        },
        {
            name: "Castellero",
            codCat: "C154"
        },
        {
            name: "Castelletto Molina",
            codCat: "C161"
        },
        {
            name: "Castello di Annone",
            codCat: "A300"
        },
        {
            name: "Castelnuovo Belbo",
            codCat: "C226"
        },
        {
            name: "Castelnuovo Calcea",
            codCat: "C230"
        },
        {
            name: "Castelnuovo Don Bosco",
            codCat: "C232"
        },
        {
            name: "Castel Rocchero",
            codCat: "C253"
        },
        {
            name: "Cellarengo",
            codCat: "C438"
        },
        {
            name: "Celle Enomondo",
            codCat: "C440"
        },
        {
            name: "Cerreto d'Asti",
            codCat: "C528"
        },
        {
            name: "Cerro Tanaro",
            codCat: "C533"
        },
        {
            name: "Cessole",
            codCat: "C583"
        },
        {
            name: "Chiusano d'Asti",
            codCat: "C658"
        },
        {
            name: "Cinaglio",
            codCat: "C701"
        },
        {
            name: "Cisterna d'Asti",
            codCat: "C739"
        },
        {
            name: "Coazzolo",
            codCat: "C804"
        },
        {
            name: "Cocconato",
            codCat: "C807"
        },
        {
            name: "Corsione",
            codCat: "D046"
        },
        {
            name: "Cortandone",
            codCat: "D050"
        },
        {
            name: "Cortanze",
            codCat: "D051"
        },
        {
            name: "Cortazzone",
            codCat: "D052"
        },
        {
            name: "Cortiglione",
            codCat: "D072"
        },
        {
            name: "Cossombrato",
            codCat: "D101"
        },
        {
            name: "Costigliole d'Asti",
            codCat: "D119"
        },
        {
            name: "Cunico",
            codCat: "D207"
        },
        {
            name: "Dusino San Michele",
            codCat: "D388"
        },
        {
            name: "Ferrere",
            codCat: "D554"
        },
        {
            name: "Fontanile",
            codCat: "D678"
        },
        {
            name: "Frinco",
            codCat: "D802"
        },
        {
            name: "Grana",
            codCat: "E134"
        },
        {
            name: "Grazzano Badoglio",
            codCat: "E159"
        },
        {
            name: "Incisa Scapaccino",
            codCat: "E295"
        },
        {
            name: "Isola d'Asti",
            codCat: "E338"
        },
        {
            name: "Loazzolo",
            codCat: "E633"
        },
        {
            name: "Maranzana",
            codCat: "E917"
        },
        {
            name: "Maretto",
            codCat: "E944"
        },
        {
            name: "Moasca",
            codCat: "F254"
        },
        {
            name: "Mombaldone",
            codCat: "F308"
        },
        {
            name: "Mombaruzzo",
            codCat: "F311"
        },
        {
            name: "Mombercelli",
            codCat: "F316"
        },
        {
            name: "Monale",
            codCat: "F323"
        },
        {
            name: "Monastero Bormida",
            codCat: "F325"
        },
        {
            name: "Moncalvo",
            codCat: "F336"
        },
        {
            name: "Moncucco Torinese",
            codCat: "F343"
        },
        {
            name: "Mongardino",
            codCat: "F361"
        },
        {
            name: "Montabone",
            codCat: "F386"
        },
        {
            name: "Montafia",
            codCat: "F390"
        },
        {
            name: "Montaldo Scarampi",
            codCat: "F409"
        },
        {
            name: "Montechiaro d'Asti",
            codCat: "F468"
        },
        {
            name: "Montegrosso d'Asti",
            codCat: "F527"
        },
        {
            name: "Montemagno",
            codCat: "F556"
        },
        {
            name: "Moransengo",
            codCat: "F709"
        },
        {
            name: "Nizza Monferrato",
            codCat: "F902"
        },
        {
            name: "Olmo Gentile",
            codCat: "G048"
        },
        {
            name: "Passerano Marmorito",
            codCat: "G358"
        },
        {
            name: "Penango",
            codCat: "G430"
        },
        {
            name: "Piea",
            codCat: "G593"
        },
        {
            name: "Pino d'Asti",
            codCat: "G676"
        },
        {
            name: "Piovà Massaia",
            codCat: "G692"
        },
        {
            name: "Portacomaro",
            codCat: "G894"
        },
        {
            name: "Quaranti",
            codCat: "H102"
        },
        {
            name: "Refrancore",
            codCat: "H219"
        },
        {
            name: "Revigliasco d'Asti",
            codCat: "H250"
        },
        {
            name: "Roatto",
            codCat: "H366"
        },
        {
            name: "Robella",
            codCat: "H376"
        },
        {
            name: "Rocca d'Arazzo",
            codCat: "H392"
        },
        {
            name: "Roccaverano",
            codCat: "H451"
        },
        {
            name: "Rocchetta Palafea",
            codCat: "H466"
        },
        {
            name: "Rocchetta Tanaro",
            codCat: "H468"
        },
        {
            name: "San Damiano d'Asti",
            codCat: "H811"
        },
        {
            name: "San Giorgio Scarampi",
            codCat: "H899"
        },
        {
            name: "San Martino Alfieri",
            codCat: "H987"
        },
        {
            name: "San Marzano Oliveto",
            codCat: "I017"
        },
        {
            name: "San Paolo Solbrito",
            codCat: "I076"
        },
        {
            name: "Scurzolengo",
            codCat: "I555"
        },
        {
            name: "Serole",
            codCat: "I637"
        },
        {
            name: "Sessame",
            codCat: "I678"
        },
        {
            name: "Settime",
            codCat: "I698"
        },
        {
            name: "Soglio",
            codCat: "I781"
        },
        {
            name: "Tigliole",
            codCat: "L168"
        },
        {
            name: "Tonco",
            codCat: "L203"
        },
        {
            name: "Tonengo",
            codCat: "L204"
        },
        {
            name: "Vaglio Serra",
            codCat: "L531"
        },
        {
            name: "Valfenera",
            codCat: "L574"
        },
        {
            name: "Vesime",
            codCat: "L807"
        },
        {
            name: "Viale",
            codCat: "L829"
        },
        {
            name: "Viarigi",
            codCat: "L834"
        },
        {
            name: "Vigliano d'Asti",
            codCat: "L879"
        },
        {
            name: "Villafranca d'Asti",
            codCat: "L945"
        },
        {
            name: "Villanova d'Asti",
            codCat: "L984"
        },
        {
            name: "Villa San Secondo",
            codCat: "M019"
        },
        {
            name: "Vinchio",
            codCat: "M058"
        },
        {
            name: "Montiglio Monferrato",
            codCat: "M302"
        },
        {
            name: "Acqui Terme",
            codCat: "A052"
        },
        {
            name: "Albera Ligure",
            codCat: "A146"
        },
        {
            name: "Alessandria",
            codCat: "A182"
        },
        {
            name: "Alfiano Natta",
            codCat: "A189"
        },
        {
            name: "Alice Bel Colle",
            codCat: "A197"
        },
        {
            name: "Altavilla Monferrato",
            codCat: "A227"
        },
        {
            name: "Alzano Scrivia",
            codCat: "A245"
        },
        {
            name: "Arquata Scrivia",
            codCat: "A436"
        },
        {
            name: "Avolasca",
            codCat: "A523"
        },
        {
            name: "Balzola",
            codCat: "A605"
        },
        {
            name: "Basaluzzo",
            codCat: "A689"
        },
        {
            name: "Bassignana",
            codCat: "A708"
        },
        {
            name: "Belforte Monferrato",
            codCat: "A738"
        },
        {
            name: "Bergamasco",
            codCat: "A793"
        },
        {
            name: "Berzano di Tortona",
            codCat: "A813"
        },
        {
            name: "Bistagno",
            codCat: "A889"
        },
        {
            name: "Borghetto di Borbera",
            codCat: "A998"
        },
        {
            name: "Borgoratto Alessandrino",
            codCat: "B029"
        },
        {
            name: "Borgo San Martino",
            codCat: "B037"
        },
        {
            name: "Bosco Marengo",
            codCat: "B071"
        },
        {
            name: "Bosio",
            codCat: "B080"
        },
        {
            name: "Bozzole",
            codCat: "B109"
        },
        {
            name: "Brignano-Frascata",
            codCat: "B179"
        },
        {
            name: "Cabella Ligure",
            codCat: "B311"
        },
        {
            name: "Camagna Monferrato",
            codCat: "B453"
        },
        {
            name: "Camino",
            codCat: "B482"
        },
        {
            name: "Cantalupo Ligure",
            codCat: "B629"
        },
        {
            name: "Capriata d'Orba",
            codCat: "B701"
        },
        {
            name: "Carbonara Scrivia",
            codCat: "B736"
        },
        {
            name: "Carentino",
            codCat: "B765"
        },
        {
            name: "Carezzano",
            codCat: "B769"
        },
        {
            name: "Carpeneto",
            codCat: "B818"
        },
        {
            name: "Carrega Ligure",
            codCat: "B836"
        },
        {
            name: "Carrosio",
            codCat: "B840"
        },
        {
            name: "Cartosio",
            codCat: "B847"
        },
        {
            name: "Casal Cermelli",
            codCat: "B870"
        },
        {
            name: "Casaleggio Boiro",
            codCat: "B882"
        },
        {
            name: "Casale Monferrato",
            codCat: "B885"
        },
        {
            name: "Casalnoceto",
            codCat: "B902"
        },
        {
            name: "Casasco",
            codCat: "B941"
        },
        {
            name: "Cassine",
            codCat: "C027"
        },
        {
            name: "Cassinelle",
            codCat: "C030"
        },
        {
            name: "Castellania Coppi",
            codCat: "C137"
        },
        {
            name: "Castellar Guidobono",
            codCat: "C142"
        },
        {
            name: "Castellazzo Bormida",
            codCat: "C148"
        },
        {
            name: "Castelletto d'Erro",
            codCat: "C156"
        },
        {
            name: "Castelletto d'Orba",
            codCat: "C158"
        },
        {
            name: "Castelletto Merli",
            codCat: "C160"
        },
        {
            name: "Castelletto Monferrato",
            codCat: "C162"
        },
        {
            name: "Castelnuovo Bormida",
            codCat: "C229"
        },
        {
            name: "Castelnuovo Scrivia",
            codCat: "C243"
        },
        {
            name: "Castelspina",
            codCat: "C274"
        },
        {
            name: "Cavatore",
            codCat: "C387"
        },
        {
            name: "Cella Monte",
            codCat: "C432"
        },
        {
            name: "Cereseto",
            codCat: "C503"
        },
        {
            name: "Cerreto Grue",
            codCat: "C507"
        },
        {
            name: "Cerrina Monferrato",
            codCat: "C531"
        },
        {
            name: "Coniolo",
            codCat: "C962"
        },
        {
            name: "Conzano",
            codCat: "C977"
        },
        {
            name: "Costa Vescovato",
            codCat: "D102"
        },
        {
            name: "Cremolino",
            codCat: "D149"
        },
        {
            name: "Denice",
            codCat: "D272"
        },
        {
            name: "Dernice",
            codCat: "D277"
        },
        {
            name: "Fabbrica Curone",
            codCat: "D447"
        },
        {
            name: "Felizzano",
            codCat: "D528"
        },
        {
            name: "Fraconalto",
            codCat: "D559"
        },
        {
            name: "Francavilla Bisio",
            codCat: "D759"
        },
        {
            name: "Frascaro",
            codCat: "D770"
        },
        {
            name: "Frassinello Monferrato",
            codCat: "D777"
        },
        {
            name: "Frassineto Po",
            codCat: "D780"
        },
        {
            name: "Fresonara",
            codCat: "D797"
        },
        {
            name: "Frugarolo",
            codCat: "D813"
        },
        {
            name: "Fubine Monferrato",
            codCat: "D814"
        },
        {
            name: "Gabiano",
            codCat: "D835"
        },
        {
            name: "Gamalero",
            codCat: "D890"
        },
        {
            name: "Garbagna",
            codCat: "D910"
        },
        {
            name: "Gavi",
            codCat: "D944"
        },
        {
            name: "Giarole",
            codCat: "E015"
        },
        {
            name: "Gremiasco",
            codCat: "E164"
        },
        {
            name: "Grognardo",
            codCat: "E188"
        },
        {
            name: "Grondona",
            codCat: "E191"
        },
        {
            name: "Guazzora",
            codCat: "E255"
        },
        {
            name: "Isola Sant'Antonio",
            codCat: "E360"
        },
        {
            name: "Lerma",
            codCat: "E543"
        },
        {
            name: "Malvicino",
            codCat: "E870"
        },
        {
            name: "Masio",
            codCat: "F015"
        },
        {
            name: "Melazzo",
            codCat: "F096"
        },
        {
            name: "Merana",
            codCat: "F131"
        },
        {
            name: "Mirabello Monferrato",
            codCat: "F232"
        },
        {
            name: "Molare",
            codCat: "F281"
        },
        {
            name: "Molino dei Torti",
            codCat: "F293"
        },
        {
            name: "Mombello Monferrato",
            codCat: "F313"
        },
        {
            name: "Momperone",
            codCat: "F320"
        },
        {
            name: "Moncestino",
            codCat: "F337"
        },
        {
            name: "Mongiardino Ligure",
            codCat: "F365"
        },
        {
            name: "Monleale",
            codCat: "F374"
        },
        {
            name: "Montacuto",
            codCat: "F387"
        },
        {
            name: "Montaldeo",
            codCat: "F403"
        },
        {
            name: "Montaldo Bormida",
            codCat: "F404"
        },
        {
            name: "Montecastello",
            codCat: "F455"
        },
        {
            name: "Montechiaro d'Acqui",
            codCat: "F469"
        },
        {
            name: "Montegioco",
            codCat: "F518"
        },
        {
            name: "Montemarzino",
            codCat: "F562"
        },
        {
            name: "Morano sul Po",
            codCat: "F707"
        },
        {
            name: "Morbello",
            codCat: "F713"
        },
        {
            name: "Mornese",
            codCat: "F737"
        },
        {
            name: "Morsasco",
            codCat: "F751"
        },
        {
            name: "Murisengo",
            codCat: "F814"
        },
        {
            name: "Novi Ligure",
            codCat: "F965"
        },
        {
            name: "Occimiano",
            codCat: "F995"
        },
        {
            name: "Odalengo Grande",
            codCat: "F997"
        },
        {
            name: "Odalengo Piccolo",
            codCat: "F998"
        },
        {
            name: "Olivola",
            codCat: "G042"
        },
        {
            name: "Orsara Bormida",
            codCat: "G124"
        },
        {
            name: "Ottiglio",
            codCat: "G193"
        },
        {
            name: "Ovada",
            codCat: "G197"
        },
        {
            name: "Oviglio",
            codCat: "G199"
        },
        {
            name: "Ozzano Monferrato",
            codCat: "G204"
        },
        {
            name: "Paderna",
            codCat: "G215"
        },
        {
            name: "Pareto",
            codCat: "G334"
        },
        {
            name: "Parodi Ligure",
            codCat: "G338"
        },
        {
            name: "Pasturana",
            codCat: "G367"
        },
        {
            name: "Pecetto di Valenza",
            codCat: "G397"
        },
        {
            name: "Pietra Marazzi",
            codCat: "G619"
        },
        {
            name: "Pomaro Monferrato",
            codCat: "G807"
        },
        {
            name: "Pontecurone",
            codCat: "G839"
        },
        {
            name: "Pontestura",
            codCat: "G858"
        },
        {
            name: "Ponti",
            codCat: "G861"
        },
        {
            name: "Ponzano Monferrato",
            codCat: "G872"
        },
        {
            name: "Ponzone",
            codCat: "G877"
        },
        {
            name: "Pozzol Groppo",
            codCat: "G960"
        },
        {
            name: "Pozzolo Formigaro",
            codCat: "G961"
        },
        {
            name: "Prasco",
            codCat: "G987"
        },
        {
            name: "Predosa",
            codCat: "H021"
        },
        {
            name: "Quargnento",
            codCat: "H104"
        },
        {
            name: "Quattordio",
            codCat: "H121"
        },
        {
            name: "Ricaldone",
            codCat: "H272"
        },
        {
            name: "Rivalta Bormida",
            codCat: "H334"
        },
        {
            name: "Rivarone",
            codCat: "H343"
        },
        {
            name: "Roccaforte Ligure",
            codCat: "H406"
        },
        {
            name: "Rocca Grimalda",
            codCat: "H414"
        },
        {
            name: "Rocchetta Ligure",
            codCat: "H465"
        },
        {
            name: "Rosignano Monferrato",
            codCat: "H569"
        },
        {
            name: "Sala Monferrato",
            codCat: "H677"
        },
        {
            name: "Sale",
            codCat: "H694"
        },
        {
            name: "San Cristoforo",
            codCat: "H810"
        },
        {
            name: "San Giorgio Monferrato",
            codCat: "H878"
        },
        {
            name: "San Salvatore Monferrato",
            codCat: "I144"
        },
        {
            name: "San Sebastiano Curone",
            codCat: "I150"
        },
        {
            name: "Sant'Agata Fossili",
            codCat: "I190"
        },
        {
            name: "Sardigliano",
            codCat: "I429"
        },
        {
            name: "Sarezzano",
            codCat: "I432"
        },
        {
            name: "Serralunga di Crea",
            codCat: "I645"
        },
        {
            name: "Serravalle Scrivia",
            codCat: "I657"
        },
        {
            name: "Sezzadio",
            codCat: "I711"
        },
        {
            name: "Silvano d'Orba",
            codCat: "I738"
        },
        {
            name: "Solero",
            codCat: "I798"
        },
        {
            name: "Solonghello",
            codCat: "I808"
        },
        {
            name: "Spigno Monferrato",
            codCat: "I901"
        },
        {
            name: "Spineto Scrivia",
            codCat: "I911"
        },
        {
            name: "Stazzano",
            codCat: "I941"
        },
        {
            name: "Strevi",
            codCat: "I977"
        },
        {
            name: "Tagliolo Monferrato",
            codCat: "L027"
        },
        {
            name: "Tassarolo",
            codCat: "L059"
        },
        {
            name: "Terruggia",
            codCat: "L139"
        },
        {
            name: "Terzo",
            codCat: "L143"
        },
        {
            name: "Ticineto",
            codCat: "L165"
        },
        {
            name: "Tortona",
            codCat: "L304"
        },
        {
            name: "Treville",
            codCat: "L403"
        },
        {
            name: "Trisobbio",
            codCat: "L432"
        },
        {
            name: "Valenza",
            codCat: "L570"
        },
        {
            name: "Valmacca",
            codCat: "L633"
        },
        {
            name: "Vignale Monferrato",
            codCat: "L881"
        },
        {
            name: "Vignole Borbera",
            codCat: "L887"
        },
        {
            name: "Viguzzolo",
            codCat: "L904"
        },
        {
            name: "Villadeati",
            codCat: "L931"
        },
        {
            name: "Villalvernia",
            codCat: "L963"
        },
        {
            name: "Villamiroglio",
            codCat: "L970"
        },
        {
            name: "Villanova Monferrato",
            codCat: "L972"
        },
        {
            name: "Villaromagnano",
            codCat: "M009"
        },
        {
            name: "Visone",
            codCat: "M077"
        },
        {
            name: "Volpedo",
            codCat: "M120"
        },
        {
            name: "Volpeglino",
            codCat: "M121"
        },
        {
            name: "Voltaggio",
            codCat: "M123"
        },
        {
            name: "Cassano Spinola",
            codCat: "M388"
        },
        {
            name: "Alluvioni Piovera",
            codCat: "M397"
        },
        {
            name: "Lu e Cuccaro Monferrato",
            codCat: "M420"
        },
        {
            name: "Ailoche",
            codCat: "A107"
        },
        {
            name: "Andorno Micca",
            codCat: "A280"
        },
        {
            name: "Benna",
            codCat: "A784"
        },
        {
            name: "Biella",
            codCat: "A859"
        },
        {
            name: "Bioglio",
            codCat: "A876"
        },
        {
            name: "Borriana",
            codCat: "B058"
        },
        {
            name: "Brusnengo",
            codCat: "B229"
        },
        {
            name: "Callabiana",
            codCat: "B417"
        },
        {
            name: "Camandona",
            codCat: "B457"
        },
        {
            name: "Camburzano",
            codCat: "B465"
        },
        {
            name: "Candelo",
            codCat: "B586"
        },
        {
            name: "Caprile",
            codCat: "B708"
        },
        {
            name: "Casapinta",
            codCat: "B933"
        },
        {
            name: "Castelletto Cervo",
            codCat: "C155"
        },
        {
            name: "Cavaglià",
            codCat: "C363"
        },
        {
            name: "Cerrione",
            codCat: "C532"
        },
        {
            name: "Coggiola",
            codCat: "C819"
        },
        {
            name: "Cossato",
            codCat: "D094"
        },
        {
            name: "Crevacuore",
            codCat: "D165"
        },
        {
            name: "Curino",
            codCat: "D219"
        },
        {
            name: "Donato",
            codCat: "D339"
        },
        {
            name: "Dorzano",
            codCat: "D350"
        },
        {
            name: "Gaglianico",
            codCat: "D848"
        },
        {
            name: "Gifflenga",
            codCat: "E024"
        },
        {
            name: "Graglia",
            codCat: "E130"
        },
        {
            name: "Magnano",
            codCat: "E821"
        },
        {
            name: "Massazza",
            codCat: "F037"
        },
        {
            name: "Masserano",
            codCat: "F042"
        },
        {
            name: "Mezzana Mortigliengo",
            codCat: "F167"
        },
        {
            name: "Miagliano",
            codCat: "F189"
        },
        {
            name: "Mongrando",
            codCat: "F369"
        },
        {
            name: "Mottalciata",
            codCat: "F776"
        },
        {
            name: "Muzzano",
            codCat: "F833"
        },
        {
            name: "Netro",
            codCat: "F878"
        },
        {
            name: "Occhieppo Inferiore",
            codCat: "F992"
        },
        {
            name: "Occhieppo Superiore",
            codCat: "F993"
        },
        {
            name: "Pettinengo",
            codCat: "G521"
        },
        {
            name: "Piatto",
            codCat: "G577"
        },
        {
            name: "Piedicavallo",
            codCat: "G594"
        },
        {
            name: "Pollone",
            codCat: "G798"
        },
        {
            name: "Ponderano",
            codCat: "G820"
        },
        {
            name: "Portula",
            codCat: "G927"
        },
        {
            name: "Pralungo",
            codCat: "G980"
        },
        {
            name: "Pray",
            codCat: "G974"
        },
        {
            name: "Ronco Biellese",
            codCat: "H538"
        },
        {
            name: "Roppolo",
            codCat: "H553"
        },
        {
            name: "Rosazza",
            codCat: "H561"
        },
        {
            name: "Sagliano Micca",
            codCat: "H662"
        },
        {
            name: "Sala Biellese",
            codCat: "H681"
        },
        {
            name: "Salussola",
            codCat: "H726"
        },
        {
            name: "Sandigliano",
            codCat: "H821"
        },
        {
            name: "Sordevolo",
            codCat: "I847"
        },
        {
            name: "Sostegno",
            codCat: "I868"
        },
        {
            name: "Strona",
            codCat: "I980"
        },
        {
            name: "Tavigliano",
            codCat: "L075"
        },
        {
            name: "Ternengo",
            codCat: "L116"
        },
        {
            name: "Tollegno",
            codCat: "L193"
        },
        {
            name: "Torrazzo",
            codCat: "L239"
        },
        {
            name: "Valdengo",
            codCat: "L556"
        },
        {
            name: "Vallanzengo",
            codCat: "L586"
        },
        {
            name: "Valle San Nicolao",
            codCat: "L620"
        },
        {
            name: "Veglio",
            codCat: "L712"
        },
        {
            name: "Verrone",
            codCat: "L785"
        },
        {
            name: "Vigliano Biellese",
            codCat: "L880"
        },
        {
            name: "Villa del Bosco",
            codCat: "L933"
        },
        {
            name: "Villanova Biellese",
            codCat: "L978"
        },
        {
            name: "Viverone",
            codCat: "M098"
        },
        {
            name: "Zimone",
            codCat: "M179"
        },
        {
            name: "Zubiena",
            codCat: "M196"
        },
        {
            name: "Zumaglia",
            codCat: "M201"
        },
        {
            name: "Lessona",
            codCat: "M371"
        },
        {
            name: "Campiglia Cervo",
            codCat: "M373"
        },
        {
            name: "Quaregna Cerreto",
            codCat: "M414"
        },
        {
            name: "Valdilana",
            codCat: "M417"
        },
        {
            name: "Antrona Schieranco",
            codCat: "A317"
        },
        {
            name: "Anzola d'Ossola",
            codCat: "A325"
        },
        {
            name: "Arizzano",
            codCat: "A409"
        },
        {
            name: "Arola",
            codCat: "A427"
        },
        {
            name: "Aurano",
            codCat: "A497"
        },
        {
            name: "Baceno",
            codCat: "A534"
        },
        {
            name: "Bannio Anzino",
            codCat: "A610"
        },
        {
            name: "Baveno",
            codCat: "A725"
        },
        {
            name: "Bee",
            codCat: "A733"
        },
        {
            name: "Belgirate",
            codCat: "A742"
        },
        {
            name: "Beura-Cardezza",
            codCat: "A834"
        },
        {
            name: "Bognanco",
            codCat: "A925"
        },
        {
            name: "Brovello-Carpugnino",
            codCat: "B207"
        },
        {
            name: "Calasca-Castiglione",
            codCat: "B380"
        },
        {
            name: "Cambiasca",
            codCat: "B463"
        },
        {
            name: "Cannero Riviera",
            codCat: "B610"
        },
        {
            name: "Cannobio",
            codCat: "B615"
        },
        {
            name: "Caprezzo",
            codCat: "B694"
        },
        {
            name: "Casale Corte Cerro",
            codCat: "B876"
        },
        {
            name: "Ceppo Morelli",
            codCat: "C478"
        },
        {
            name: "Cesara",
            codCat: "C567"
        },
        {
            name: "Cossogno",
            codCat: "D099"
        },
        {
            name: "Craveggia",
            codCat: "D134"
        },
        {
            name: "Crevoladossola",
            codCat: "D168"
        },
        {
            name: "Crodo",
            codCat: "D177"
        },
        {
            name: "Domodossola",
            codCat: "D332"
        },
        {
            name: "Druogno",
            codCat: "D374"
        },
        {
            name: "Formazza",
            codCat: "D706"
        },
        {
            name: "Germagno",
            codCat: "D984"
        },
        {
            name: "Ghiffa",
            codCat: "E003"
        },
        {
            name: "Gignese",
            codCat: "E028"
        },
        {
            name: "Gravellona Toce",
            codCat: "E153"
        },
        {
            name: "Gurro",
            codCat: "E269"
        },
        {
            name: "Intragna",
            codCat: "E304"
        },
        {
            name: "Loreglia",
            codCat: "E685"
        },
        {
            name: "Macugnaga",
            codCat: "E790"
        },
        {
            name: "Madonna del Sasso",
            codCat: "E795"
        },
        {
            name: "Malesco",
            codCat: "E853"
        },
        {
            name: "Masera",
            codCat: "F010"
        },
        {
            name: "Massiola",
            codCat: "F048"
        },
        {
            name: "Mergozzo",
            codCat: "F146"
        },
        {
            name: "Miazzina",
            codCat: "F192"
        },
        {
            name: "Montecrestese",
            codCat: "F483"
        },
        {
            name: "Montescheno",
            codCat: "F639"
        },
        {
            name: "Nonio",
            codCat: "F932"
        },
        {
            name: "Oggebbio",
            codCat: "G007"
        },
        {
            name: "Omegna",
            codCat: "G062"
        },
        {
            name: "Ornavasso",
            codCat: "G117"
        },
        {
            name: "Pallanzeno",
            codCat: "G280"
        },
        {
            name: "Piedimulera",
            codCat: "G600"
        },
        {
            name: "Pieve Vergonte",
            codCat: "G658"
        },
        {
            name: "Premeno",
            codCat: "H030"
        },
        {
            name: "Premia",
            codCat: "H033"
        },
        {
            name: "Premosello-Chiovenda",
            codCat: "H037"
        },
        {
            name: "Quarna Sopra",
            codCat: "H106"
        },
        {
            name: "Quarna Sotto",
            codCat: "H107"
        },
        {
            name: "Re",
            codCat: "H203"
        },
        {
            name: "San Bernardino Verbano",
            codCat: "H777"
        },
        {
            name: "Santa Maria Maggiore",
            codCat: "I249"
        },
        {
            name: "Stresa",
            codCat: "I976"
        },
        {
            name: "Toceno",
            codCat: "L187"
        },
        {
            name: "Trarego Viggiona",
            codCat: "L333"
        },
        {
            name: "Trasquera",
            codCat: "L336"
        },
        {
            name: "Trontano",
            codCat: "L450"
        },
        {
            name: "Valstrona",
            codCat: "L651"
        },
        {
            name: "Vanzone con San Carlo",
            codCat: "L666"
        },
        {
            name: "Varzo",
            codCat: "L691"
        },
        {
            name: "Verbania",
            codCat: "L746"
        },
        {
            name: "Vignone",
            codCat: "L889"
        },
        {
            name: "Villadossola",
            codCat: "L906"
        },
        {
            name: "Villette",
            codCat: "M042"
        },
        {
            name: "Vogogna",
            codCat: "M111"
        },
        {
            name: "Borgomezzavalle",
            codCat: "M370"
        },
        {
            name: "Valle Cannobina",
            codCat: "M404"
        },
        {
            name: "Allein",
            codCat: "A205"
        },
        {
            name: "Antey-Saint-André",
            codCat: "A305"
        },
        {
            name: "Aosta",
            codCat: "A326"
        },
        {
            name: "Arnad",
            codCat: "A424"
        },
        {
            name: "Arvier",
            codCat: "A452"
        },
        {
            name: "Avise",
            codCat: "A521"
        },
        {
            name: "Ayas",
            codCat: "A094"
        },
        {
            name: "Aymavilles",
            codCat: "A108"
        },
        {
            name: "Bard",
            codCat: "A643"
        },
        {
            name: "Bionaz",
            codCat: "A877"
        },
        {
            name: "Brissogne",
            codCat: "B192"
        },
        {
            name: "Brusson",
            codCat: "B230"
        },
        {
            name: "Challand-Saint-Anselme",
            codCat: "C593"
        },
        {
            name: "Challand-Saint-Victor",
            codCat: "C594"
        },
        {
            name: "Chambave",
            codCat: "C595"
        },
        {
            name: "Chamois",
            codCat: "B491"
        },
        {
            name: "Champdepraz",
            codCat: "C596"
        },
        {
            name: "Champorcher",
            codCat: "B540"
        },
        {
            name: "Charvensod",
            codCat: "C598"
        },
        {
            name: "Châtillon",
            codCat: "C294"
        },
        {
            name: "Cogne",
            codCat: "C821"
        },
        {
            name: "Courmayeur",
            codCat: "D012"
        },
        {
            name: "Donnas",
            codCat: "D338"
        },
        {
            name: "Doues",
            codCat: "D356"
        },
        {
            name: "Emarèse",
            codCat: "D402"
        },
        {
            name: "Etroubles",
            codCat: "D444"
        },
        {
            name: "Fénis",
            codCat: "D537"
        },
        {
            name: "Fontainemore",
            codCat: "D666"
        },
        {
            name: "Gaby",
            codCat: "D839"
        },
        {
            name: "Gignod",
            codCat: "E029"
        },
        {
            name: "Gressan",
            codCat: "E165"
        },
        {
            name: "Gressoney-La-Trinité",
            codCat: "E167"
        },
        {
            name: "Gressoney-Saint-Jean",
            codCat: "E168"
        },
        {
            name: "Hône",
            codCat: "E273"
        },
        {
            name: "Introd",
            codCat: "E306"
        },
        {
            name: "Issime",
            codCat: "E369"
        },
        {
            name: "Issogne",
            codCat: "E371"
        },
        {
            name: "Jovençan",
            codCat: "E391"
        },
        {
            name: "La Magdeleine",
            codCat: "A308"
        },
        {
            name: "La Salle",
            codCat: "E458"
        },
        {
            name: "La Thuile",
            codCat: "E470"
        },
        {
            name: "Lillianes",
            codCat: "E587"
        },
        {
            name: "Montjovet",
            codCat: "F367"
        },
        {
            name: "Morgex",
            codCat: "F726"
        },
        {
            name: "Nus",
            codCat: "F987"
        },
        {
            name: "Ollomont",
            codCat: "G045"
        },
        {
            name: "Oyace",
            codCat: "G012"
        },
        {
            name: "Perloz",
            codCat: "G459"
        },
        {
            name: "Pollein",
            codCat: "G794"
        },
        {
            name: "Pontboset",
            codCat: "G545"
        },
        {
            name: "Pontey",
            codCat: "G860"
        },
        {
            name: "Pont-Saint-Martin",
            codCat: "G854"
        },
        {
            name: "Pré-Saint-Didier",
            codCat: "H042"
        },
        {
            name: "Quart",
            codCat: "H110"
        },
        {
            name: "Rhêmes-Notre-Dame",
            codCat: "H262"
        },
        {
            name: "Rhêmes-Saint-Georges",
            codCat: "H263"
        },
        {
            name: "Roisan",
            codCat: "H497"
        },
        {
            name: "Saint-Christophe",
            codCat: "H669"
        },
        {
            name: "Saint-Denis",
            codCat: "H670"
        },
        {
            name: "Saint-Marcel",
            codCat: "H671"
        },
        {
            name: "Saint-Nicolas",
            codCat: "H672"
        },
        {
            name: "Saint-Oyen",
            codCat: "H673"
        },
        {
            name: "Saint-Pierre",
            codCat: "H674"
        },
        {
            name: "Saint-Rhémy-en-Bosses",
            codCat: "H675"
        },
        {
            name: "Saint-Vincent",
            codCat: "H676"
        },
        {
            name: "Sarre",
            codCat: "I442"
        },
        {
            name: "Torgnon",
            codCat: "L217"
        },
        {
            name: "Valgrisenche",
            codCat: "L582"
        },
        {
            name: "Valpelline",
            codCat: "L643"
        },
        {
            name: "Valsavarenche",
            codCat: "L647"
        },
        {
            name: "Valtournenche",
            codCat: "L654"
        },
        {
            name: "Verrayes",
            codCat: "L783"
        },
        {
            name: "Verrès",
            codCat: "C282"
        },
        {
            name: "Villeneuve",
            codCat: "L981"
        },
        {
            name: "Agra",
            codCat: "A085"
        },
        {
            name: "Albizzate",
            codCat: "A167"
        },
        {
            name: "Angera",
            codCat: "A290"
        },
        {
            name: "Arcisate",
            codCat: "A371"
        },
        {
            name: "Arsago Seprio",
            codCat: "A441"
        },
        {
            name: "Azzate",
            codCat: "A531"
        },
        {
            name: "Azzio",
            codCat: "A532"
        },
        {
            name: "Barasso",
            codCat: "A619"
        },
        {
            name: "Bardello",
            codCat: "A645"
        },
        {
            name: "Bedero Valcuvia",
            codCat: "A728"
        },
        {
            name: "Besano",
            codCat: "A819"
        },
        {
            name: "Besnate",
            codCat: "A825"
        },
        {
            name: "Besozzo",
            codCat: "A826"
        },
        {
            name: "Biandronno",
            codCat: "A845"
        },
        {
            name: "Bisuschio",
            codCat: "A891"
        },
        {
            name: "Bodio Lomnago",
            codCat: "A918"
        },
        {
            name: "Brebbia",
            codCat: "B126"
        },
        {
            name: "Bregano",
            codCat: "B131"
        },
        {
            name: "Brenta",
            codCat: "B150"
        },
        {
            name: "Brezzo di Bedero",
            codCat: "B166"
        },
        {
            name: "Brinzio",
            codCat: "B182"
        },
        {
            name: "Brissago-Valtravaglia",
            codCat: "B191"
        },
        {
            name: "Brunello",
            codCat: "B219"
        },
        {
            name: "Brusimpiano",
            codCat: "B228"
        },
        {
            name: "Buguggiate",
            codCat: "B258"
        },
        {
            name: "Busto Arsizio",
            codCat: "B300"
        },
        {
            name: "Cadegliano-Viconago",
            codCat: "B326"
        },
        {
            name: "Cairate",
            codCat: "B368"
        },
        {
            name: "Cantello",
            codCat: "B634"
        },
        {
            name: "Caravate",
            codCat: "B732"
        },
        {
            name: "Cardano al Campo",
            codCat: "B754"
        },
        {
            name: "Carnago",
            codCat: "B796"
        },
        {
            name: "Caronno Pertusella",
            codCat: "B805"
        },
        {
            name: "Caronno Varesino",
            codCat: "B807"
        },
        {
            name: "Casale Litta",
            codCat: "B875"
        },
        {
            name: "Casalzuigno",
            codCat: "B921"
        },
        {
            name: "Casciago",
            codCat: "B949"
        },
        {
            name: "Casorate Sempione",
            codCat: "B987"
        },
        {
            name: "Cassano Magnago",
            codCat: "C004"
        },
        {
            name: "Cassano Valcuvia",
            codCat: "B999"
        },
        {
            name: "Castellanza",
            codCat: "C139"
        },
        {
            name: "Castello Cabiaglio",
            codCat: "B312"
        },
        {
            name: "Castelseprio",
            codCat: "C273"
        },
        {
            name: "Castelveccana",
            codCat: "C181"
        },
        {
            name: "Castiglione Olona",
            codCat: "C300"
        },
        {
            name: "Castronno",
            codCat: "C343"
        },
        {
            name: "Cavaria con Premezzo",
            codCat: "C382"
        },
        {
            name: "Cazzago Brabbia",
            codCat: "C409"
        },
        {
            name: "Cislago",
            codCat: "C732"
        },
        {
            name: "Cittiglio",
            codCat: "C751"
        },
        {
            name: "Clivio",
            codCat: "C796"
        },
        {
            name: "Cocquio-Trevisago",
            codCat: "C810"
        },
        {
            name: "Comabbio",
            codCat: "C911"
        },
        {
            name: "Comerio",
            codCat: "C922"
        },
        {
            name: "Cremenaga",
            codCat: "D144"
        },
        {
            name: "Crosio della Valle",
            codCat: "D185"
        },
        {
            name: "Cuasso al Monte",
            codCat: "D192"
        },
        {
            name: "Cugliate-Fabiasco",
            codCat: "D199"
        },
        {
            name: "Cunardo",
            codCat: "D204"
        },
        {
            name: "Curiglia con Monteviasco",
            codCat: "D217"
        },
        {
            name: "Cuveglio",
            codCat: "D238"
        },
        {
            name: "Cuvio",
            codCat: "D239"
        },
        {
            name: "Daverio",
            codCat: "D256"
        },
        {
            name: "Dumenza",
            codCat: "D384"
        },
        {
            name: "Duno",
            codCat: "D385"
        },
        {
            name: "Fagnano Olona",
            codCat: "D467"
        },
        {
            name: "Ferno",
            codCat: "D543"
        },
        {
            name: "Ferrera di Varese",
            codCat: "D551"
        },
        {
            name: "Gallarate",
            codCat: "D869"
        },
        {
            name: "Galliate Lombardo",
            codCat: "D871"
        },
        {
            name: "Gavirate",
            codCat: "D946"
        },
        {
            name: "Gazzada Schianno",
            codCat: "D951"
        },
        {
            name: "Gemonio",
            codCat: "D963"
        },
        {
            name: "Gerenzano",
            codCat: "D981"
        },
        {
            name: "Germignaga",
            codCat: "D987"
        },
        {
            name: "Golasecca",
            codCat: "E079"
        },
        {
            name: "Gorla Maggiore",
            codCat: "E101"
        },
        {
            name: "Gorla Minore",
            codCat: "E102"
        },
        {
            name: "Gornate Olona",
            codCat: "E104"
        },
        {
            name: "Grantola",
            codCat: "E144"
        },
        {
            name: "Inarzo",
            codCat: "E292"
        },
        {
            name: "Induno Olona",
            codCat: "E299"
        },
        {
            name: "Ispra",
            codCat: "E367"
        },
        {
            name: "Jerago con Orago",
            codCat: "E386"
        },
        {
            name: "Lavena Ponte Tresa",
            codCat: "E494"
        },
        {
            name: "Laveno-Mombello",
            codCat: "E496"
        },
        {
            name: "Leggiuno",
            codCat: "E510"
        },
        {
            name: "Lonate Ceppino",
            codCat: "E665"
        },
        {
            name: "Lonate Pozzolo",
            codCat: "E666"
        },
        {
            name: "Lozza",
            codCat: "E707"
        },
        {
            name: "Luino",
            codCat: "E734"
        },
        {
            name: "Luvinate",
            codCat: "E769"
        },
        {
            name: "Malgesso",
            codCat: "E856"
        },
        {
            name: "Malnate",
            codCat: "E863"
        },
        {
            name: "Marchirolo",
            codCat: "E929"
        },
        {
            name: "Marnate",
            codCat: "E965"
        },
        {
            name: "Marzio",
            codCat: "F002"
        },
        {
            name: "Masciago Primo",
            codCat: "F007"
        },
        {
            name: "Mercallo",
            codCat: "F134"
        },
        {
            name: "Mesenzana",
            codCat: "F154"
        },
        {
            name: "Montegrino Valtravaglia",
            codCat: "F526"
        },
        {
            name: "Monvalle",
            codCat: "F703"
        },
        {
            name: "Morazzone",
            codCat: "F711"
        },
        {
            name: "Mornago",
            codCat: "F736"
        },
        {
            name: "Oggiona con Santo Stefano",
            codCat: "G008"
        },
        {
            name: "Olgiate Olona",
            codCat: "G028"
        },
        {
            name: "Origgio",
            codCat: "G103"
        },
        {
            name: "Orino",
            codCat: "G105"
        },
        {
            name: "Porto Ceresio",
            codCat: "G906"
        },
        {
            name: "Porto Valtravaglia",
            codCat: "G907"
        },
        {
            name: "Rancio Valcuvia",
            codCat: "H173"
        },
        {
            name: "Ranco",
            codCat: "H174"
        },
        {
            name: "Saltrio",
            codCat: "H723"
        },
        {
            name: "Samarate",
            codCat: "H736"
        },
        {
            name: "Saronno",
            codCat: "I441"
        },
        {
            name: "Sesto Calende",
            codCat: "I688"
        },
        {
            name: "Solbiate Arno",
            codCat: "I793"
        },
        {
            name: "Solbiate Olona",
            codCat: "I794"
        },
        {
            name: "Somma Lombardo",
            codCat: "I819"
        },
        {
            name: "Sumirago",
            codCat: "L003"
        },
        {
            name: "Taino",
            codCat: "L032"
        },
        {
            name: "Ternate",
            codCat: "L115"
        },
        {
            name: "Tradate",
            codCat: "L319"
        },
        {
            name: "Travedona-Monate",
            codCat: "L342"
        },
        {
            name: "Tronzano Lago Maggiore",
            codCat: "A705"
        },
        {
            name: "Uboldo",
            codCat: "L480"
        },
        {
            name: "Valganna",
            codCat: "L577"
        },
        {
            name: "Varano Borghi",
            codCat: "L671"
        },
        {
            name: "Varese",
            codCat: "L682"
        },
        {
            name: "Vedano Olona",
            codCat: "L703"
        },
        {
            name: "Venegono Inferiore",
            codCat: "L733"
        },
        {
            name: "Venegono Superiore",
            codCat: "L734"
        },
        {
            name: "Vergiate",
            codCat: "L765"
        },
        {
            name: "Viggiù",
            codCat: "L876"
        },
        {
            name: "Vizzola Ticino",
            codCat: "M101"
        },
        {
            name: "Sangiano",
            codCat: "H872"
        },
        {
            name: "Maccagno con Pino e Veddasca",
            codCat: "M339"
        },
        {
            name: "Cadrezzate con Osmate",
            codCat: "M425"
        },
        {
            name: "Albavilla",
            codCat: "A143"
        },
        {
            name: "Albese con Cassano",
            codCat: "A153"
        },
        {
            name: "Albiolo",
            codCat: "A164"
        },
        {
            name: "Alserio",
            codCat: "A224"
        },
        {
            name: "Alzate Brianza",
            codCat: "A249"
        },
        {
            name: "Anzano del Parco",
            codCat: "A319"
        },
        {
            name: "Appiano Gentile",
            codCat: "A333"
        },
        {
            name: "Argegno",
            codCat: "A391"
        },
        {
            name: "Arosio",
            codCat: "A430"
        },
        {
            name: "Asso",
            codCat: "A476"
        },
        {
            name: "Barni",
            codCat: "A670"
        },
        {
            name: "Bene Lario",
            codCat: "A778"
        },
        {
            name: "Beregazzo con Figliaro",
            codCat: "A791"
        },
        {
            name: "Binago",
            codCat: "A870"
        },
        {
            name: "Bizzarone",
            codCat: "A898"
        },
        {
            name: "Blessagno",
            codCat: "A904"
        },
        {
            name: "Blevio",
            codCat: "A905"
        },
        {
            name: "Bregnano",
            codCat: "B134"
        },
        {
            name: "Brenna",
            codCat: "B144"
        },
        {
            name: "Brienno",
            codCat: "B172"
        },
        {
            name: "Brunate",
            codCat: "B218"
        },
        {
            name: "Bulgarograsso",
            codCat: "B262"
        },
        {
            name: "Cabiate",
            codCat: "B313"
        },
        {
            name: "Cadorago",
            codCat: "B346"
        },
        {
            name: "Caglio",
            codCat: "B355"
        },
        {
            name: "Campione d'Italia",
            codCat: "B513"
        },
        {
            name: "Cantù",
            codCat: "B639"
        },
        {
            name: "Canzo",
            codCat: "B641"
        },
        {
            name: "Capiago Intimiano",
            codCat: "B653"
        },
        {
            name: "Carate Urio",
            codCat: "B730"
        },
        {
            name: "Carbonate",
            codCat: "B742"
        },
        {
            name: "Carimate",
            codCat: "B778"
        },
        {
            name: "Carlazzo",
            codCat: "B785"
        },
        {
            name: "Carugo",
            codCat: "B851"
        },
        {
            name: "Caslino d'Erba",
            codCat: "B974"
        },
        {
            name: "Casnate con Bernate",
            codCat: "B977"
        },
        {
            name: "Cassina Rizzardi",
            codCat: "C020"
        },
        {
            name: "Castelmarte",
            codCat: "C206"
        },
        {
            name: "Castelnuovo Bozzente",
            codCat: "C220"
        },
        {
            name: "Cavargna",
            codCat: "C381"
        },
        {
            name: "Cerano d'Intelvi",
            codCat: "C482"
        },
        {
            name: "Cermenate",
            codCat: "C516"
        },
        {
            name: "Cernobbio",
            codCat: "C520"
        },
        {
            name: "Cirimido",
            codCat: "C724"
        },
        {
            name: "Claino con Osteno",
            codCat: "C787"
        },
        {
            name: "Colonno",
            codCat: "C902"
        },
        {
            name: "Como",
            codCat: "C933"
        },
        {
            name: "Corrido",
            codCat: "D041"
        },
        {
            name: "Cremia",
            codCat: "D147"
        },
        {
            name: "Cucciago",
            codCat: "D196"
        },
        {
            name: "Cusino",
            codCat: "D232"
        },
        {
            name: "Dizzasco",
            codCat: "D310"
        },
        {
            name: "Domaso",
            codCat: "D329"
        },
        {
            name: "Dongo",
            codCat: "D341"
        },
        {
            name: "Dosso del Liro",
            codCat: "D355"
        },
        {
            name: "Erba",
            codCat: "D416"
        },
        {
            name: "Eupilio",
            codCat: "D445"
        },
        {
            name: "Faggeto Lario",
            codCat: "D462"
        },
        {
            name: "Faloppio",
            codCat: "D482"
        },
        {
            name: "Fenegrò",
            codCat: "D531"
        },
        {
            name: "Figino Serenza",
            codCat: "D579"
        },
        {
            name: "Fino Mornasco",
            codCat: "D605"
        },
        {
            name: "Garzeno",
            codCat: "D930"
        },
        {
            name: "Gera Lario",
            codCat: "D974"
        },
        {
            name: "Grandate",
            codCat: "E139"
        },
        {
            name: "Grandola ed Uniti",
            codCat: "E141"
        },
        {
            name: "Griante",
            codCat: "E172"
        },
        {
            name: "Guanzate",
            codCat: "E235"
        },
        {
            name: "Inverigo",
            codCat: "E309"
        },
        {
            name: "Laglio",
            codCat: "E405"
        },
        {
            name: "Laino",
            codCat: "E416"
        },
        {
            name: "Lambrugo",
            codCat: "E428"
        },
        {
            name: "Lasnigo",
            codCat: "E462"
        },
        {
            name: "Lezzeno",
            codCat: "E569"
        },
        {
            name: "Limido Comasco",
            codCat: "E593"
        },
        {
            name: "Lipomo",
            codCat: "E607"
        },
        {
            name: "Livo",
            codCat: "E623"
        },
        {
            name: "Locate Varesino",
            codCat: "E638"
        },
        {
            name: "Lomazzo",
            codCat: "E659"
        },
        {
            name: "Longone al Segrino",
            codCat: "E679"
        },
        {
            name: "Luisago",
            codCat: "E735"
        },
        {
            name: "Lurago d'Erba",
            codCat: "E749"
        },
        {
            name: "Lurago Marinone",
            codCat: "E750"
        },
        {
            name: "Lurate Caccivio",
            codCat: "E753"
        },
        {
            name: "Magreglio",
            codCat: "E830"
        },
        {
            name: "Mariano Comense",
            codCat: "E951"
        },
        {
            name: "Maslianico",
            codCat: "F017"
        },
        {
            name: "Menaggio",
            codCat: "F120"
        },
        {
            name: "Merone",
            codCat: "F151"
        },
        {
            name: "Moltrasio",
            codCat: "F305"
        },
        {
            name: "Monguzzo",
            codCat: "F372"
        },
        {
            name: "Montano Lucino",
            codCat: "F427"
        },
        {
            name: "Montemezzo",
            codCat: "F564"
        },
        {
            name: "Montorfano",
            codCat: "F688"
        },
        {
            name: "Mozzate",
            codCat: "F788"
        },
        {
            name: "Musso",
            codCat: "F828"
        },
        {
            name: "Nesso",
            codCat: "F877"
        },
        {
            name: "Novedrate",
            codCat: "F958"
        },
        {
            name: "Olgiate Comasco",
            codCat: "G025"
        },
        {
            name: "Oltrona di San Mamette",
            codCat: "G056"
        },
        {
            name: "Orsenigo",
            codCat: "G126"
        },
        {
            name: "Peglio",
            codCat: "G415"
        },
        {
            name: "Pianello del Lario",
            codCat: "G556"
        },
        {
            name: "Pigra",
            codCat: "G665"
        },
        {
            name: "Plesio",
            codCat: "G737"
        },
        {
            name: "Pognana Lario",
            codCat: "G773"
        },
        {
            name: "Ponna",
            codCat: "G821"
        },
        {
            name: "Ponte Lambro",
            codCat: "G847"
        },
        {
            name: "Porlezza",
            codCat: "G889"
        },
        {
            name: "Proserpio",
            codCat: "H074"
        },
        {
            name: "Pusiano",
            codCat: "H094"
        },
        {
            name: "Rezzago",
            codCat: "H255"
        },
        {
            name: "Rodero",
            codCat: "H478"
        },
        {
            name: "Ronago",
            codCat: "H521"
        },
        {
            name: "Rovellasca",
            codCat: "H601"
        },
        {
            name: "Rovello Porro",
            codCat: "H602"
        },
        {
            name: "Sala Comacina",
            codCat: "H679"
        },
        {
            name: "San Bartolomeo Val Cavargna",
            codCat: "H760"
        },
        {
            name: "San Fermo della Battaglia",
            codCat: "H840"
        },
        {
            name: "San Nazzaro Val Cavargna",
            codCat: "I051"
        },
        {
            name: "Schignano",
            codCat: "I529"
        },
        {
            name: "Senna Comasco",
            codCat: "I611"
        },
        {
            name: "Sorico",
            codCat: "I856"
        },
        {
            name: "Sormano",
            codCat: "I860"
        },
        {
            name: "Stazzona",
            codCat: "I943"
        },
        {
            name: "Tavernerio",
            codCat: "L071"
        },
        {
            name: "Torno",
            codCat: "L228"
        },
        {
            name: "Trezzone",
            codCat: "L413"
        },
        {
            name: "Turate",
            codCat: "L470"
        },
        {
            name: "Uggiate-Trevano",
            codCat: "L487"
        },
        {
            name: "Valbrona",
            codCat: "L547"
        },
        {
            name: "Valmorea",
            codCat: "L640"
        },
        {
            name: "Val Rezzo",
            codCat: "H259"
        },
        {
            name: "Valsolda",
            codCat: "C936"
        },
        {
            name: "Veleso",
            codCat: "L715"
        },
        {
            name: "Veniano",
            codCat: "L737"
        },
        {
            name: "Vercana",
            codCat: "L748"
        },
        {
            name: "Vertemate con Minoprio",
            codCat: "L792"
        },
        {
            name: "Villa Guardia",
            codCat: "L956"
        },
        {
            name: "Zelbio",
            codCat: "M156"
        },
        {
            name: "San Siro",
            codCat: "I162"
        },
        {
            name: "Gravedona ed Uniti",
            codCat: "M315"
        },
        {
            name: "Bellagio",
            codCat: "M335"
        },
        {
            name: "Colverde",
            codCat: "M336"
        },
        {
            name: "Tremezzina",
            codCat: "M341"
        },
        {
            name: "Alta Valle Intelvi",
            codCat: "M383"
        },
        {
            name: "Centro Valle Intelvi",
            codCat: "M394"
        },
        {
            name: "Solbiate con Cagno",
            codCat: "M412"
        },
        {
            name: "Albaredo per San Marco",
            codCat: "A135"
        },
        {
            name: "Albosaggia",
            codCat: "A172"
        },
        {
            name: "Andalo Valtellino",
            codCat: "A273"
        },
        {
            name: "Aprica",
            codCat: "A337"
        },
        {
            name: "Ardenno",
            codCat: "A382"
        },
        {
            name: "Bema",
            codCat: "A777"
        },
        {
            name: "Berbenno di Valtellina",
            codCat: "A787"
        },
        {
            name: "Bianzone",
            codCat: "A848"
        },
        {
            name: "Bormio",
            codCat: "B049"
        },
        {
            name: "Buglio in Monte",
            codCat: "B255"
        },
        {
            name: "Caiolo",
            codCat: "B366"
        },
        {
            name: "Campodolcino",
            codCat: "B530"
        },
        {
            name: "Caspoggio",
            codCat: "B993"
        },
        {
            name: "Castello dell'Acqua",
            codCat: "C186"
        },
        {
            name: "Castione Andevenno",
            codCat: "C325"
        },
        {
            name: "Cedrasco",
            codCat: "C418"
        },
        {
            name: "Cercino",
            codCat: "C493"
        },
        {
            name: "Chiavenna",
            codCat: "C623"
        },
        {
            name: "Chiesa in Valmalenco",
            codCat: "C628"
        },
        {
            name: "Chiuro",
            codCat: "C651"
        },
        {
            name: "Cino",
            codCat: "C709"
        },
        {
            name: "Civo",
            codCat: "C785"
        },
        {
            name: "Colorina",
            codCat: "C903"
        },
        {
            name: "Cosio Valtellino",
            codCat: "D088"
        },
        {
            name: "Dazio",
            codCat: "D258"
        },
        {
            name: "Delebio",
            codCat: "D266"
        },
        {
            name: "Dubino",
            codCat: "D377"
        },
        {
            name: "Faedo Valtellino",
            codCat: "D456"
        },
        {
            name: "Forcola",
            codCat: "D694"
        },
        {
            name: "Fusine",
            codCat: "D830"
        },
        {
            name: "Gerola Alta",
            codCat: "D990"
        },
        {
            name: "Gordona",
            codCat: "E090"
        },
        {
            name: "Grosio",
            codCat: "E200"
        },
        {
            name: "Grosotto",
            codCat: "E201"
        },
        {
            name: "Madesimo",
            codCat: "E342"
        },
        {
            name: "Lanzada",
            codCat: "E443"
        },
        {
            name: "Livigno",
            codCat: "E621"
        },
        {
            name: "Lovero",
            codCat: "E705"
        },
        {
            name: "Mantello",
            codCat: "E896"
        },
        {
            name: "Mazzo di Valtellina",
            codCat: "F070"
        },
        {
            name: "Mello",
            codCat: "F115"
        },
        {
            name: "Mese",
            codCat: "F153"
        },
        {
            name: "Montagna in Valtellina",
            codCat: "F393"
        },
        {
            name: "Morbegno",
            codCat: "F712"
        },
        {
            name: "Novate Mezzola",
            codCat: "F956"
        },
        {
            name: "Pedesina",
            codCat: "G410"
        },
        {
            name: "Piantedo",
            codCat: "G572"
        },
        {
            name: "Piateda",
            codCat: "G576"
        },
        {
            name: "Piuro",
            codCat: "G718"
        },
        {
            name: "Poggiridenti",
            codCat: "G431"
        },
        {
            name: "Ponte in Valtellina",
            codCat: "G829"
        },
        {
            name: "Postalesio",
            codCat: "G937"
        },
        {
            name: "Prata Camportaccio",
            codCat: "G993"
        },
        {
            name: "Rasura",
            codCat: "H192"
        },
        {
            name: "Rogolo",
            codCat: "H493"
        },
        {
            name: "Samolaco",
            codCat: "H752"
        },
        {
            name: "San Giacomo Filippo",
            codCat: "H868"
        },
        {
            name: "Sernio",
            codCat: "I636"
        },
        {
            name: "Sondalo",
            codCat: "I828"
        },
        {
            name: "Sondrio",
            codCat: "I829"
        },
        {
            name: "Spriana",
            codCat: "I928"
        },
        {
            name: "Talamona",
            codCat: "L035"
        },
        {
            name: "Tartano",
            codCat: "L056"
        },
        {
            name: "Teglio",
            codCat: "L084"
        },
        {
            name: "Tirano",
            codCat: "L175"
        },
        {
            name: "Torre di Santa Maria",
            codCat: "L244"
        },
        {
            name: "Tovo di Sant'Agata",
            codCat: "L316"
        },
        {
            name: "Traona",
            codCat: "L330"
        },
        {
            name: "Tresivio",
            codCat: "L392"
        },
        {
            name: "Valdidentro",
            codCat: "L557"
        },
        {
            name: "Valdisotto",
            codCat: "L563"
        },
        {
            name: "Valfurva",
            codCat: "L576"
        },
        {
            name: "Val Masino",
            codCat: "L638"
        },
        {
            name: "Verceia",
            codCat: "L749"
        },
        {
            name: "Vervio",
            codCat: "L799"
        },
        {
            name: "Villa di Chiavenna",
            codCat: "L907"
        },
        {
            name: "Villa di Tirano",
            codCat: "L908"
        },
        {
            name: "Abbiategrasso",
            codCat: "A010"
        },
        {
            name: "Albairate",
            codCat: "A127"
        },
        {
            name: "Arconate",
            codCat: "A375"
        },
        {
            name: "Arese",
            codCat: "A389"
        },
        {
            name: "Arluno",
            codCat: "A413"
        },
        {
            name: "Assago",
            codCat: "A473"
        },
        {
            name: "Bareggio",
            codCat: "A652"
        },
        {
            name: "Basiano",
            codCat: "A697"
        },
        {
            name: "Basiglio",
            codCat: "A699"
        },
        {
            name: "Bellinzago Lombardo",
            codCat: "A751"
        },
        {
            name: "Bernate Ticino",
            codCat: "A804"
        },
        {
            name: "Besate",
            codCat: "A820"
        },
        {
            name: "Binasco",
            codCat: "A872"
        },
        {
            name: "Boffalora sopra Ticino",
            codCat: "A920"
        },
        {
            name: "Bollate",
            codCat: "A940"
        },
        {
            name: "Bresso",
            codCat: "B162"
        },
        {
            name: "Bubbiano",
            codCat: "B235"
        },
        {
            name: "Buccinasco",
            codCat: "B240"
        },
        {
            name: "Buscate",
            codCat: "B286"
        },
        {
            name: "Bussero",
            codCat: "B292"
        },
        {
            name: "Busto Garolfo",
            codCat: "B301"
        },
        {
            name: "Calvignasco",
            codCat: "B448"
        },
        {
            name: "Cambiago",
            codCat: "B461"
        },
        {
            name: "Canegrate",
            codCat: "B593"
        },
        {
            name: "Carpiano",
            codCat: "B820"
        },
        {
            name: "Carugate",
            codCat: "B850"
        },
        {
            name: "Casarile",
            codCat: "B938"
        },
        {
            name: "Casorezzo",
            codCat: "B989"
        },
        {
            name: "Cassano d'Adda",
            codCat: "C003"
        },
        {
            name: "Cassina de' Pecchi",
            codCat: "C014"
        },
        {
            name: "Cassinetta di Lugagnano",
            codCat: "C033"
        },
        {
            name: "Castano Primo",
            codCat: "C052"
        },
        {
            name: "Cernusco sul Naviglio",
            codCat: "C523"
        },
        {
            name: "Cerro al Lambro",
            codCat: "C536"
        },
        {
            name: "Cerro Maggiore",
            codCat: "C537"
        },
        {
            name: "Cesano Boscone",
            codCat: "C565"
        },
        {
            name: "Cesate",
            codCat: "C569"
        },
        {
            name: "Cinisello Balsamo",
            codCat: "C707"
        },
        {
            name: "Cisliano",
            codCat: "C733"
        },
        {
            name: "Cologno Monzese",
            codCat: "C895"
        },
        {
            name: "Colturano",
            codCat: "C908"
        },
        {
            name: "Corbetta",
            codCat: "C986"
        },
        {
            name: "Cormano",
            codCat: "D013"
        },
        {
            name: "Cornaredo",
            codCat: "D018"
        },
        {
            name: "Corsico",
            codCat: "D045"
        },
        {
            name: "Cuggiono",
            codCat: "D198"
        },
        {
            name: "Cusago",
            codCat: "D229"
        },
        {
            name: "Cusano Milanino",
            codCat: "D231"
        },
        {
            name: "Dairago",
            codCat: "D244"
        },
        {
            name: "Dresano",
            codCat: "D367"
        },
        {
            name: "Gaggiano",
            codCat: "D845"
        },
        {
            name: "Garbagnate Milanese",
            codCat: "D912"
        },
        {
            name: "Gessate",
            codCat: "D995"
        },
        {
            name: "Gorgonzola",
            codCat: "E094"
        },
        {
            name: "Grezzago",
            codCat: "E170"
        },
        {
            name: "Gudo Visconti",
            codCat: "E258"
        },
        {
            name: "Inveruno",
            codCat: "E313"
        },
        {
            name: "Inzago",
            codCat: "E317"
        },
        {
            name: "Lacchiarella",
            codCat: "E395"
        },
        {
            name: "Lainate",
            codCat: "E415"
        },
        {
            name: "Legnano",
            codCat: "E514"
        },
        {
            name: "Liscate",
            codCat: "E610"
        },
        {
            name: "Locate di Triulzi",
            codCat: "E639"
        },
        {
            name: "Magenta",
            codCat: "E801"
        },
        {
            name: "Magnago",
            codCat: "E819"
        },
        {
            name: "Marcallo con Casone",
            codCat: "E921"
        },
        {
            name: "Masate",
            codCat: "F003"
        },
        {
            name: "Mediglia",
            codCat: "F084"
        },
        {
            name: "Melegnano",
            codCat: "F100"
        },
        {
            name: "Melzo",
            codCat: "F119"
        },
        {
            name: "Mesero",
            codCat: "F155"
        },
        {
            name: "Milano",
            codCat: "F205"
        },
        {
            name: "Morimondo",
            codCat: "D033"
        },
        {
            name: "Motta Visconti",
            codCat: "F783"
        },
        {
            name: "Nerviano",
            codCat: "F874"
        },
        {
            name: "Nosate",
            codCat: "F939"
        },
        {
            name: "Novate Milanese",
            codCat: "F955"
        },
        {
            name: "Noviglio",
            codCat: "F968"
        },
        {
            name: "Opera",
            codCat: "G078"
        },
        {
            name: "Ossona",
            codCat: "G181"
        },
        {
            name: "Ozzero",
            codCat: "G206"
        },
        {
            name: "Paderno Dugnano",
            codCat: "G220"
        },
        {
            name: "Pantigliate",
            codCat: "G316"
        },
        {
            name: "Parabiago",
            codCat: "G324"
        },
        {
            name: "Paullo",
            codCat: "G385"
        },
        {
            name: "Pero",
            codCat: "C013"
        },
        {
            name: "Peschiera Borromeo",
            codCat: "G488"
        },
        {
            name: "Pessano con Bornago",
            codCat: "G502"
        },
        {
            name: "Pieve Emanuele",
            codCat: "G634"
        },
        {
            name: "Pioltello",
            codCat: "G686"
        },
        {
            name: "Pogliano Milanese",
            codCat: "G772"
        },
        {
            name: "Pozzo d'Adda",
            codCat: "G955"
        },
        {
            name: "Pozzuolo Martesana",
            codCat: "G965"
        },
        {
            name: "Pregnana Milanese",
            codCat: "H026"
        },
        {
            name: "Rescaldina",
            codCat: "H240"
        },
        {
            name: "Rho",
            codCat: "H264"
        },
        {
            name: "Robecchetto con Induno",
            codCat: "H371"
        },
        {
            name: "Robecco sul Naviglio",
            codCat: "H373"
        },
        {
            name: "Rodano",
            codCat: "H470"
        },
        {
            name: "Rosate",
            codCat: "H560"
        },
        {
            name: "Rozzano",
            codCat: "H623"
        },
        {
            name: "San Colombano al Lambro",
            codCat: "H803"
        },
        {
            name: "San Donato Milanese",
            codCat: "H827"
        },
        {
            name: "San Giorgio su Legnano",
            codCat: "H884"
        },
        {
            name: "San Giuliano Milanese",
            codCat: "H930"
        },
        {
            name: "Santo Stefano Ticino",
            codCat: "I361"
        },
        {
            name: "San Vittore Olona",
            codCat: "I409"
        },
        {
            name: "San Zenone al Lambro",
            codCat: "I415"
        },
        {
            name: "Sedriano",
            codCat: "I566"
        },
        {
            name: "Segrate",
            codCat: "I577"
        },
        {
            name: "Senago",
            codCat: "I602"
        },
        {
            name: "Sesto San Giovanni",
            codCat: "I690"
        },
        {
            name: "Settala",
            codCat: "I696"
        },
        {
            name: "Settimo Milanese",
            codCat: "I700"
        },
        {
            name: "Solaro",
            codCat: "I786"
        },
        {
            name: "Trezzano Rosa",
            codCat: "L408"
        },
        {
            name: "Trezzano sul Naviglio",
            codCat: "L409"
        },
        {
            name: "Trezzo sull'Adda",
            codCat: "L411"
        },
        {
            name: "Tribiano",
            codCat: "L415"
        },
        {
            name: "Truccazzano",
            codCat: "L454"
        },
        {
            name: "Turbigo",
            codCat: "L471"
        },
        {
            name: "Vanzago",
            codCat: "L665"
        },
        {
            name: "Vaprio d'Adda",
            codCat: "L667"
        },
        {
            name: "Vernate",
            codCat: "L773"
        },
        {
            name: "Vignate",
            codCat: "L883"
        },
        {
            name: "Vimodrone",
            codCat: "M053"
        },
        {
            name: "Vittuone",
            codCat: "M091"
        },
        {
            name: "Vizzolo Predabissi",
            codCat: "M102"
        },
        {
            name: "Zibido San Giacomo",
            codCat: "M176"
        },
        {
            name: "Villa Cortese",
            codCat: "L928"
        },
        {
            name: "Vanzaghello",
            codCat: "L664"
        },
        {
            name: "Baranzate",
            codCat: "A618"
        },
        {
            name: "Vermezzo con Zelo",
            codCat: "M424"
        },
        {
            name: "Adrara San Martino",
            codCat: "A057"
        },
        {
            name: "Adrara San Rocco",
            codCat: "A058"
        },
        {
            name: "Albano Sant'Alessandro",
            codCat: "A129"
        },
        {
            name: "Albino",
            codCat: "A163"
        },
        {
            name: "Almè",
            codCat: "A214"
        },
        {
            name: "Almenno San Bartolomeo",
            codCat: "A216"
        },
        {
            name: "Almenno San Salvatore",
            codCat: "A217"
        },
        {
            name: "Alzano Lombardo",
            codCat: "A246"
        },
        {
            name: "Ambivere",
            codCat: "A259"
        },
        {
            name: "Antegnate",
            codCat: "A304"
        },
        {
            name: "Arcene",
            codCat: "A365"
        },
        {
            name: "Ardesio",
            codCat: "A383"
        },
        {
            name: "Arzago d'Adda",
            codCat: "A440"
        },
        {
            name: "Averara",
            codCat: "A511"
        },
        {
            name: "Aviatico",
            codCat: "A517"
        },
        {
            name: "Azzano San Paolo",
            codCat: "A528"
        },
        {
            name: "Azzone",
            codCat: "A533"
        },
        {
            name: "Bagnatica",
            codCat: "A557"
        },
        {
            name: "Barbata",
            codCat: "A631"
        },
        {
            name: "Bariano",
            codCat: "A664"
        },
        {
            name: "Barzana",
            codCat: "A684"
        },
        {
            name: "Bedulita",
            codCat: "A732"
        },
        {
            name: "Berbenno",
            codCat: "A786"
        },
        {
            name: "Bergamo",
            codCat: "A794"
        },
        {
            name: "Berzo San Fermo",
            codCat: "A815"
        },
        {
            name: "Bianzano",
            codCat: "A846"
        },
        {
            name: "Blello",
            codCat: "A903"
        },
        {
            name: "Bolgare",
            codCat: "A937"
        },
        {
            name: "Boltiere",
            codCat: "A950"
        },
        {
            name: "Bonate Sopra",
            codCat: "A963"
        },
        {
            name: "Bonate Sotto",
            codCat: "A962"
        },
        {
            name: "Borgo di Terzo",
            codCat: "B010"
        },
        {
            name: "Bossico",
            codCat: "B083"
        },
        {
            name: "Bottanuco",
            codCat: "B088"
        },
        {
            name: "Bracca",
            codCat: "B112"
        },
        {
            name: "Branzi",
            codCat: "B123"
        },
        {
            name: "Brembate",
            codCat: "B137"
        },
        {
            name: "Brembate di Sopra",
            codCat: "B138"
        },
        {
            name: "Brignano Gera d'Adda",
            codCat: "B178"
        },
        {
            name: "Brumano",
            codCat: "B217"
        },
        {
            name: "Brusaporto",
            codCat: "B223"
        },
        {
            name: "Calcinate",
            codCat: "B393"
        },
        {
            name: "Calcio",
            codCat: "B395"
        },
        {
            name: "Calusco d'Adda",
            codCat: "B434"
        },
        {
            name: "Calvenzano",
            codCat: "B442"
        },
        {
            name: "Camerata Cornello",
            codCat: "B471"
        },
        {
            name: "Canonica d'Adda",
            codCat: "B618"
        },
        {
            name: "Capizzone",
            codCat: "B661"
        },
        {
            name: "Capriate San Gervasio",
            codCat: "B703"
        },
        {
            name: "Caprino Bergamasco",
            codCat: "B710"
        },
        {
            name: "Caravaggio",
            codCat: "B731"
        },
        {
            name: "Carobbio degli Angeli",
            codCat: "B801"
        },
        {
            name: "Carona",
            codCat: "B803"
        },
        {
            name: "Carvico",
            codCat: "B854"
        },
        {
            name: "Casazza",
            codCat: "B947"
        },
        {
            name: "Casirate d'Adda",
            codCat: "B971"
        },
        {
            name: "Casnigo",
            codCat: "B978"
        },
        {
            name: "Cassiglio",
            codCat: "C007"
        },
        {
            name: "Castelli Calepio",
            codCat: "C079"
        },
        {
            name: "Castel Rozzone",
            codCat: "C255"
        },
        {
            name: "Castione della Presolana",
            codCat: "C324"
        },
        {
            name: "Castro",
            codCat: "C337"
        },
        {
            name: "Cavernago",
            codCat: "C396"
        },
        {
            name: "Cazzano Sant'Andrea",
            codCat: "C410"
        },
        {
            name: "Cenate Sopra",
            codCat: "C456"
        },
        {
            name: "Cenate Sotto",
            codCat: "C457"
        },
        {
            name: "Cene",
            codCat: "C459"
        },
        {
            name: "Cerete",
            codCat: "C506"
        },
        {
            name: "Chignolo d'Isola",
            codCat: "C635"
        },
        {
            name: "Chiuduno",
            codCat: "C649"
        },
        {
            name: "Cisano Bergamasco",
            codCat: "C728"
        },
        {
            name: "Ciserano",
            codCat: "C730"
        },
        {
            name: "Cividate al Piano",
            codCat: "C759"
        },
        {
            name: "Clusone",
            codCat: "C800"
        },
        {
            name: "Colere",
            codCat: "C835"
        },
        {
            name: "Cologno al Serio",
            codCat: "C894"
        },
        {
            name: "Colzate",
            codCat: "C910"
        },
        {
            name: "Comun Nuovo",
            codCat: "C937"
        },
        {
            name: "Corna Imagna",
            codCat: "D015"
        },
        {
            name: "Cortenuova",
            codCat: "D066"
        },
        {
            name: "Costa di Mezzate",
            codCat: "D110"
        },
        {
            name: "Costa Valle Imagna",
            codCat: "D103"
        },
        {
            name: "Costa Volpino",
            codCat: "D117"
        },
        {
            name: "Covo",
            codCat: "D126"
        },
        {
            name: "Credaro",
            codCat: "D139"
        },
        {
            name: "Curno",
            codCat: "D221"
        },
        {
            name: "Cusio",
            codCat: "D233"
        },
        {
            name: "Dalmine",
            codCat: "D245"
        },
        {
            name: "Dossena",
            codCat: "D352"
        },
        {
            name: "Endine Gaiano",
            codCat: "D406"
        },
        {
            name: "Entratico",
            codCat: "D411"
        },
        {
            name: "Fara Gera d'Adda",
            codCat: "D490"
        },
        {
            name: "Fara Olivana con Sola",
            codCat: "D491"
        },
        {
            name: "Filago",
            codCat: "D588"
        },
        {
            name: "Fino del Monte",
            codCat: "D604"
        },
        {
            name: "Fiorano al Serio",
            codCat: "D606"
        },
        {
            name: "Fontanella",
            codCat: "D672"
        },
        {
            name: "Fonteno",
            codCat: "D684"
        },
        {
            name: "Foppolo",
            codCat: "D688"
        },
        {
            name: "Foresto Sparso",
            codCat: "D697"
        },
        {
            name: "Fornovo San Giovanni",
            codCat: "D727"
        },
        {
            name: "Fuipiano Valle Imagna",
            codCat: "D817"
        },
        {
            name: "Gandellino",
            codCat: "D903"
        },
        {
            name: "Gandino",
            codCat: "D905"
        },
        {
            name: "Gandosso",
            codCat: "D906"
        },
        {
            name: "Gaverina Terme",
            codCat: "D943"
        },
        {
            name: "Gazzaniga",
            codCat: "D952"
        },
        {
            name: "Ghisalba",
            codCat: "E006"
        },
        {
            name: "Gorlago",
            codCat: "E100"
        },
        {
            name: "Gorle",
            codCat: "E103"
        },
        {
            name: "Gorno",
            codCat: "E106"
        },
        {
            name: "Grassobbio",
            codCat: "E148"
        },
        {
            name: "Gromo",
            codCat: "E189"
        },
        {
            name: "Grone",
            codCat: "E192"
        },
        {
            name: "Grumello del Monte",
            codCat: "E219"
        },
        {
            name: "Isola di Fondra",
            codCat: "E353"
        },
        {
            name: "Isso",
            codCat: "E370"
        },
        {
            name: "Lallio",
            codCat: "E422"
        },
        {
            name: "Leffe",
            codCat: "E509"
        },
        {
            name: "Lenna",
            codCat: "E524"
        },
        {
            name: "Levate",
            codCat: "E562"
        },
        {
            name: "Locatello",
            codCat: "E640"
        },
        {
            name: "Lovere",
            codCat: "E704"
        },
        {
            name: "Lurano",
            codCat: "E751"
        },
        {
            name: "Luzzana",
            codCat: "E770"
        },
        {
            name: "Madone",
            codCat: "E794"
        },
        {
            name: "Mapello",
            codCat: "E901"
        },
        {
            name: "Martinengo",
            codCat: "E987"
        },
        {
            name: "Mezzoldo",
            codCat: "F186"
        },
        {
            name: "Misano di Gera d'Adda",
            codCat: "F243"
        },
        {
            name: "Moio de' Calvi",
            codCat: "F276"
        },
        {
            name: "Monasterolo del Castello",
            codCat: "F328"
        },
        {
            name: "Montello",
            codCat: "F547"
        },
        {
            name: "Morengo",
            codCat: "F720"
        },
        {
            name: "Mornico al Serio",
            codCat: "F738"
        },
        {
            name: "Mozzanica",
            codCat: "F786"
        },
        {
            name: "Mozzo",
            codCat: "F791"
        },
        {
            name: "Nembro",
            codCat: "F864"
        },
        {
            name: "Olmo al Brembo",
            codCat: "G049"
        },
        {
            name: "Oltre il Colle",
            codCat: "G050"
        },
        {
            name: "Oltressenda Alta",
            codCat: "G054"
        },
        {
            name: "Oneta",
            codCat: "G068"
        },
        {
            name: "Onore",
            codCat: "G075"
        },
        {
            name: "Orio al Serio",
            codCat: "G108"
        },
        {
            name: "Ornica",
            codCat: "G118"
        },
        {
            name: "Osio Sopra",
            codCat: "G159"
        },
        {
            name: "Osio Sotto",
            codCat: "G160"
        },
        {
            name: "Pagazzano",
            codCat: "G233"
        },
        {
            name: "Paladina",
            codCat: "G249"
        },
        {
            name: "Palazzago",
            codCat: "G259"
        },
        {
            name: "Palosco",
            codCat: "G295"
        },
        {
            name: "Parre",
            codCat: "G346"
        },
        {
            name: "Parzanica",
            codCat: "G350"
        },
        {
            name: "Pedrengo",
            codCat: "G412"
        },
        {
            name: "Peia",
            codCat: "G418"
        },
        {
            name: "Pianico",
            codCat: "G564"
        },
        {
            name: "Piario",
            codCat: "G574"
        },
        {
            name: "Piazza Brembana",
            codCat: "G579"
        },
        {
            name: "Piazzatorre",
            codCat: "G583"
        },
        {
            name: "Piazzolo",
            codCat: "G588"
        },
        {
            name: "Pognano",
            codCat: "G774"
        },
        {
            name: "Ponte Nossa",
            codCat: "F941"
        },
        {
            name: "Ponteranica",
            codCat: "G853"
        },
        {
            name: "Ponte San Pietro",
            codCat: "G856"
        },
        {
            name: "Pontida",
            codCat: "G864"
        },
        {
            name: "Pontirolo Nuovo",
            codCat: "G867"
        },
        {
            name: "Pradalunga",
            codCat: "G968"
        },
        {
            name: "Predore",
            codCat: "H020"
        },
        {
            name: "Premolo",
            codCat: "H036"
        },
        {
            name: "Presezzo",
            codCat: "H046"
        },
        {
            name: "Pumenengo",
            codCat: "H091"
        },
        {
            name: "Ranica",
            codCat: "H176"
        },
        {
            name: "Ranzanico",
            codCat: "H177"
        },
        {
            name: "Riva di Solto",
            codCat: "H331"
        },
        {
            name: "Rogno",
            codCat: "H492"
        },
        {
            name: "Romano di Lombardia",
            codCat: "H509"
        },
        {
            name: "Roncobello",
            codCat: "H535"
        },
        {
            name: "Roncola",
            codCat: "H544"
        },
        {
            name: "Rota d'Imagna",
            codCat: "H584"
        },
        {
            name: "Rovetta",
            codCat: "H615"
        },
        {
            name: "San Giovanni Bianco",
            codCat: "H910"
        },
        {
            name: "San Paolo d'Argon",
            codCat: "B310"
        },
        {
            name: "San Pellegrino Terme",
            codCat: "I079"
        },
        {
            name: "Santa Brigida",
            codCat: "I168"
        },
        {
            name: "Sarnico",
            codCat: "I437"
        },
        {
            name: "Scanzorosciate",
            codCat: "I506"
        },
        {
            name: "Schilpario",
            codCat: "I530"
        },
        {
            name: "Sedrina",
            codCat: "I567"
        },
        {
            name: "Selvino",
            codCat: "I597"
        },
        {
            name: "Seriate",
            codCat: "I628"
        },
        {
            name: "Serina",
            codCat: "I629"
        },
        {
            name: "Solto Collina",
            codCat: "I812"
        },
        {
            name: "Songavazzo",
            codCat: "I830"
        },
        {
            name: "Sorisole",
            codCat: "I858"
        },
        {
            name: "Sotto il Monte Giovanni XXIII",
            codCat: "I869"
        },
        {
            name: "Sovere",
            codCat: "I873"
        },
        {
            name: "Spinone al Lago",
            codCat: "I916"
        },
        {
            name: "Spirano",
            codCat: "I919"
        },
        {
            name: "Stezzano",
            codCat: "I951"
        },
        {
            name: "Strozza",
            codCat: "I986"
        },
        {
            name: "Suisio",
            codCat: "I997"
        },
        {
            name: "Taleggio",
            codCat: "L037"
        },
        {
            name: "Tavernola Bergamasca",
            codCat: "L073"
        },
        {
            name: "Telgate",
            codCat: "L087"
        },
        {
            name: "Terno d'Isola",
            codCat: "L118"
        },
        {
            name: "Torre Boldone",
            codCat: "L251"
        },
        {
            name: "Torre de' Busi",
            codCat: "L257"
        },
        {
            name: "Torre de' Roveri",
            codCat: "L265"
        },
        {
            name: "Torre Pallavicina",
            codCat: "L276"
        },
        {
            name: "Trescore Balneario",
            codCat: "L388"
        },
        {
            name: "Treviglio",
            codCat: "L400"
        },
        {
            name: "Treviolo",
            codCat: "L404"
        },
        {
            name: "Ubiale Clanezzo",
            codCat: "C789"
        },
        {
            name: "Urgnano",
            codCat: "L502"
        },
        {
            name: "Valbondione",
            codCat: "L544"
        },
        {
            name: "Valbrembo",
            codCat: "L545"
        },
        {
            name: "Valgoglio",
            codCat: "L579"
        },
        {
            name: "Valleve",
            codCat: "L623"
        },
        {
            name: "Valnegra",
            codCat: "L642"
        },
        {
            name: "Valtorta",
            codCat: "L655"
        },
        {
            name: "Vedeseta",
            codCat: "L707"
        },
        {
            name: "Verdellino",
            codCat: "L752"
        },
        {
            name: "Verdello",
            codCat: "L753"
        },
        {
            name: "Vertova",
            codCat: "L795"
        },
        {
            name: "Viadanica",
            codCat: "L827"
        },
        {
            name: "Vigano San Martino",
            codCat: "L865"
        },
        {
            name: "Vigolo",
            codCat: "L894"
        },
        {
            name: "Villa d'Adda",
            codCat: "L929"
        },
        {
            name: "Villa d'Almè",
            codCat: "A215"
        },
        {
            name: "Villa di Serio",
            codCat: "L936"
        },
        {
            name: "Villa d'Ogna",
            codCat: "L938"
        },
        {
            name: "Villongo",
            codCat: "M045"
        },
        {
            name: "Vilminore di Scalve",
            codCat: "M050"
        },
        {
            name: "Zandobbio",
            codCat: "M144"
        },
        {
            name: "Zanica",
            codCat: "M147"
        },
        {
            name: "Zogno",
            codCat: "M184"
        },
        {
            name: "Costa Serina",
            codCat: "D111"
        },
        {
            name: "Algua",
            codCat: "A193"
        },
        {
            name: "Cornalba",
            codCat: "D016"
        },
        {
            name: "Medolago",
            codCat: "F085"
        },
        {
            name: "Solza",
            codCat: "I813"
        },
        {
            name: "Sant'Omobono Terme",
            codCat: "M333"
        },
        {
            name: "Val Brembilla",
            codCat: "M334"
        },
        {
            name: "Acquafredda",
            codCat: "A034"
        },
        {
            name: "Adro",
            codCat: "A060"
        },
        {
            name: "Agnosine",
            codCat: "A082"
        },
        {
            name: "Alfianello",
            codCat: "A188"
        },
        {
            name: "Anfo",
            codCat: "A288"
        },
        {
            name: "Angolo Terme",
            codCat: "A293"
        },
        {
            name: "Artogne",
            codCat: "A451"
        },
        {
            name: "Azzano Mella",
            codCat: "A529"
        },
        {
            name: "Bagnolo Mella",
            codCat: "A569"
        },
        {
            name: "Bagolino",
            codCat: "A578"
        },
        {
            name: "Barbariga",
            codCat: "A630"
        },
        {
            name: "Barghe",
            codCat: "A661"
        },
        {
            name: "Bassano Bresciano",
            codCat: "A702"
        },
        {
            name: "Bedizzole",
            codCat: "A729"
        },
        {
            name: "Berlingo",
            codCat: "A799"
        },
        {
            name: "Berzo Demo",
            codCat: "A816"
        },
        {
            name: "Berzo Inferiore",
            codCat: "A817"
        },
        {
            name: "Bienno",
            codCat: "A861"
        },
        {
            name: "Bione",
            codCat: "A878"
        },
        {
            name: "Borgo San Giacomo",
            codCat: "B035"
        },
        {
            name: "Borgosatollo",
            codCat: "B040"
        },
        {
            name: "Borno",
            codCat: "B054"
        },
        {
            name: "Botticino",
            codCat: "B091"
        },
        {
            name: "Bovegno",
            codCat: "B100"
        },
        {
            name: "Bovezzo",
            codCat: "B102"
        },
        {
            name: "Brandico",
            codCat: "B120"
        },
        {
            name: "Braone",
            codCat: "B124"
        },
        {
            name: "Breno",
            codCat: "B149"
        },
        {
            name: "Brescia",
            codCat: "B157"
        },
        {
            name: "Brione",
            codCat: "B184"
        },
        {
            name: "Caino",
            codCat: "B365"
        },
        {
            name: "Calcinato",
            codCat: "B394"
        },
        {
            name: "Calvagese della Riviera",
            codCat: "B436"
        },
        {
            name: "Calvisano",
            codCat: "B450"
        },
        {
            name: "Capo di Ponte",
            codCat: "B664"
        },
        {
            name: "Capovalle",
            codCat: "B676"
        },
        {
            name: "Capriano del Colle",
            codCat: "B698"
        },
        {
            name: "Capriolo",
            codCat: "B711"
        },
        {
            name: "Carpenedolo",
            codCat: "B817"
        },
        {
            name: "Castegnato",
            codCat: "C055"
        },
        {
            name: "Castelcovati",
            codCat: "C072"
        },
        {
            name: "Castel Mella",
            codCat: "C208"
        },
        {
            name: "Castenedolo",
            codCat: "C293"
        },
        {
            name: "Casto",
            codCat: "C330"
        },
        {
            name: "Castrezzato",
            codCat: "C332"
        },
        {
            name: "Cazzago San Martino",
            codCat: "C408"
        },
        {
            name: "Cedegolo",
            codCat: "C417"
        },
        {
            name: "Cellatica",
            codCat: "C439"
        },
        {
            name: "Cerveno",
            codCat: "C549"
        },
        {
            name: "Ceto",
            codCat: "C585"
        },
        {
            name: "Cevo",
            codCat: "C591"
        },
        {
            name: "Chiari",
            codCat: "C618"
        },
        {
            name: "Cigole",
            codCat: "C685"
        },
        {
            name: "Cimbergo",
            codCat: "C691"
        },
        {
            name: "Cividate Camuno",
            codCat: "C760"
        },
        {
            name: "Coccaglio",
            codCat: "C806"
        },
        {
            name: "Collebeato",
            codCat: "C850"
        },
        {
            name: "Collio",
            codCat: "C883"
        },
        {
            name: "Cologne",
            codCat: "C893"
        },
        {
            name: "Comezzano-Cizzago",
            codCat: "C925"
        },
        {
            name: "Concesio",
            codCat: "C948"
        },
        {
            name: "Corte Franca",
            codCat: "D058"
        },
        {
            name: "Corteno Golgi",
            codCat: "D064"
        },
        {
            name: "Corzano",
            codCat: "D082"
        },
        {
            name: "Darfo Boario Terme",
            codCat: "D251"
        },
        {
            name: "Dello",
            codCat: "D270"
        },
        {
            name: "Desenzano del Garda",
            codCat: "D284"
        },
        {
            name: "Edolo",
            codCat: "D391"
        },
        {
            name: "Erbusco",
            codCat: "D421"
        },
        {
            name: "Esine",
            codCat: "D434"
        },
        {
            name: "Fiesse",
            codCat: "D576"
        },
        {
            name: "Flero",
            codCat: "D634"
        },
        {
            name: "Gambara",
            codCat: "D891"
        },
        {
            name: "Gardone Riviera",
            codCat: "D917"
        },
        {
            name: "Gardone Val Trompia",
            codCat: "D918"
        },
        {
            name: "Gargnano",
            codCat: "D924"
        },
        {
            name: "Gavardo",
            codCat: "D940"
        },
        {
            name: "Ghedi",
            codCat: "D999"
        },
        {
            name: "Gianico",
            codCat: "E010"
        },
        {
            name: "Gottolengo",
            codCat: "E116"
        },
        {
            name: "Gussago",
            codCat: "E271"
        },
        {
            name: "Idro",
            codCat: "E280"
        },
        {
            name: "Incudine",
            codCat: "E297"
        },
        {
            name: "Irma",
            codCat: "E325"
        },
        {
            name: "Iseo",
            codCat: "E333"
        },
        {
            name: "Isorella",
            codCat: "E364"
        },
        {
            name: "Lavenone",
            codCat: "E497"
        },
        {
            name: "Leno",
            codCat: "E526"
        },
        {
            name: "Limone sul Garda",
            codCat: "E596"
        },
        {
            name: "Lodrino",
            codCat: "E652"
        },
        {
            name: "Lograto",
            codCat: "E654"
        },
        {
            name: "Lonato del Garda",
            codCat: "M312"
        },
        {
            name: "Longhena",
            codCat: "E673"
        },
        {
            name: "Losine",
            codCat: "E698"
        },
        {
            name: "Lozio",
            codCat: "E706"
        },
        {
            name: "Lumezzane",
            codCat: "E738"
        },
        {
            name: "Maclodio",
            codCat: "E787"
        },
        {
            name: "Magasa",
            codCat: "E800"
        },
        {
            name: "Mairano",
            codCat: "E841"
        },
        {
            name: "Malegno",
            codCat: "E851"
        },
        {
            name: "Malonno",
            codCat: "E865"
        },
        {
            name: "Manerba del Garda",
            codCat: "E883"
        },
        {
            name: "Manerbio",
            codCat: "E884"
        },
        {
            name: "Marcheno",
            codCat: "E928"
        },
        {
            name: "Marmentino",
            codCat: "E961"
        },
        {
            name: "Marone",
            codCat: "E967"
        },
        {
            name: "Mazzano",
            codCat: "F063"
        },
        {
            name: "Milzano",
            codCat: "F216"
        },
        {
            name: "Moniga del Garda",
            codCat: "F373"
        },
        {
            name: "Monno",
            codCat: "F375"
        },
        {
            name: "Monte Isola",
            codCat: "F532"
        },
        {
            name: "Monticelli Brusati",
            codCat: "F672"
        },
        {
            name: "Montichiari",
            codCat: "F471"
        },
        {
            name: "Montirone",
            codCat: "F680"
        },
        {
            name: "Mura",
            codCat: "F806"
        },
        {
            name: "Muscoline",
            codCat: "F820"
        },
        {
            name: "Nave",
            codCat: "F851"
        },
        {
            name: "Niardo",
            codCat: "F884"
        },
        {
            name: "Nuvolento",
            codCat: "F989"
        },
        {
            name: "Nuvolera",
            codCat: "F990"
        },
        {
            name: "Odolo",
            codCat: "G001"
        },
        {
            name: "Offlaga",
            codCat: "G006"
        },
        {
            name: "Ome",
            codCat: "G061"
        },
        {
            name: "Ono San Pietro",
            codCat: "G074"
        },
        {
            name: "Orzinuovi",
            codCat: "G149"
        },
        {
            name: "Orzivecchi",
            codCat: "G150"
        },
        {
            name: "Ospitaletto",
            codCat: "G170"
        },
        {
            name: "Ossimo",
            codCat: "G179"
        },
        {
            name: "Padenghe sul Garda",
            codCat: "G213"
        },
        {
            name: "Paderno Franciacorta",
            codCat: "G217"
        },
        {
            name: "Paisco Loveno",
            codCat: "G247"
        },
        {
            name: "Paitone",
            codCat: "G248"
        },
        {
            name: "Palazzolo sull'Oglio",
            codCat: "G264"
        },
        {
            name: "Paratico",
            codCat: "G327"
        },
        {
            name: "Paspardo",
            codCat: "G354"
        },
        {
            name: "Passirano",
            codCat: "G361"
        },
        {
            name: "Pavone del Mella",
            codCat: "G391"
        },
        {
            name: "San Paolo",
            codCat: "G407"
        },
        {
            name: "Pertica Alta",
            codCat: "G474"
        },
        {
            name: "Pertica Bassa",
            codCat: "G475"
        },
        {
            name: "Pezzaze",
            codCat: "G529"
        },
        {
            name: "Pian Camuno",
            codCat: "G546"
        },
        {
            name: "Pisogne",
            codCat: "G710"
        },
        {
            name: "Polaveno",
            codCat: "G779"
        },
        {
            name: "Polpenazze del Garda",
            codCat: "G801"
        },
        {
            name: "Pompiano",
            codCat: "G815"
        },
        {
            name: "Poncarale",
            codCat: "G818"
        },
        {
            name: "Ponte di Legno",
            codCat: "G844"
        },
        {
            name: "Pontevico",
            codCat: "G859"
        },
        {
            name: "Pontoglio",
            codCat: "G869"
        },
        {
            name: "Pozzolengo",
            codCat: "G959"
        },
        {
            name: "Pralboino",
            codCat: "G977"
        },
        {
            name: "Preseglie",
            codCat: "H043"
        },
        {
            name: "Prevalle",
            codCat: "H055"
        },
        {
            name: "Provaglio d'Iseo",
            codCat: "H078"
        },
        {
            name: "Provaglio Val Sabbia",
            codCat: "H077"
        },
        {
            name: "Puegnago del Garda",
            codCat: "H086"
        },
        {
            name: "Quinzano d'Oglio",
            codCat: "H140"
        },
        {
            name: "Remedello",
            codCat: "H230"
        },
        {
            name: "Rezzato",
            codCat: "H256"
        },
        {
            name: "Roccafranca",
            codCat: "H410"
        },
        {
            name: "Rodengo Saiano",
            codCat: "H477"
        },
        {
            name: "Roè Volciano",
            codCat: "H484"
        },
        {
            name: "Roncadelle",
            codCat: "H525"
        },
        {
            name: "Rovato",
            codCat: "H598"
        },
        {
            name: "Rudiano",
            codCat: "H630"
        },
        {
            name: "Sabbio Chiese",
            codCat: "H650"
        },
        {
            name: "Sale Marasino",
            codCat: "H699"
        },
        {
            name: "Salò",
            codCat: "H717"
        },
        {
            name: "San Felice del Benaco",
            codCat: "H838"
        },
        {
            name: "San Gervasio Bresciano",
            codCat: "H865"
        },
        {
            name: "San Zeno Naviglio",
            codCat: "I412"
        },
        {
            name: "Sarezzo",
            codCat: "I433"
        },
        {
            name: "Saviore dell'Adamello",
            codCat: "I476"
        },
        {
            name: "Sellero",
            codCat: "I588"
        },
        {
            name: "Seniga",
            codCat: "I607"
        },
        {
            name: "Serle",
            codCat: "I631"
        },
        {
            name: "Sirmione",
            codCat: "I633"
        },
        {
            name: "Soiano del Lago",
            codCat: "I782"
        },
        {
            name: "Sonico",
            codCat: "I831"
        },
        {
            name: "Sulzano",
            codCat: "L002"
        },
        {
            name: "Tavernole sul Mella",
            codCat: "C698"
        },
        {
            name: "Temù",
            codCat: "L094"
        },
        {
            name: "Tignale",
            codCat: "L169"
        },
        {
            name: "Torbole Casaglia",
            codCat: "L210"
        },
        {
            name: "Toscolano-Maderno",
            codCat: "L312"
        },
        {
            name: "Travagliato",
            codCat: "L339"
        },
        {
            name: "Tremosine sul Garda",
            codCat: "L372"
        },
        {
            name: "Trenzano",
            codCat: "L380"
        },
        {
            name: "Treviso Bresciano",
            codCat: "L406"
        },
        {
            name: "Urago d'Oglio",
            codCat: "L494"
        },
        {
            name: "Vallio Terme",
            codCat: "L626"
        },
        {
            name: "Valvestino",
            codCat: "L468"
        },
        {
            name: "Verolanuova",
            codCat: "L777"
        },
        {
            name: "Verolavecchia",
            codCat: "L778"
        },
        {
            name: "Vestone",
            codCat: "L812"
        },
        {
            name: "Vezza d'Oglio",
            codCat: "L816"
        },
        {
            name: "Villa Carcina",
            codCat: "L919"
        },
        {
            name: "Villachiara",
            codCat: "L923"
        },
        {
            name: "Villanuova sul Clisi",
            codCat: "L995"
        },
        {
            name: "Vione",
            codCat: "M065"
        },
        {
            name: "Visano",
            codCat: "M070"
        },
        {
            name: "Vobarno",
            codCat: "M104"
        },
        {
            name: "Zone",
            codCat: "M188"
        },
        {
            name: "Piancogno",
            codCat: "G549"
        },
        {
            name: "Alagna",
            codCat: "A118"
        },
        {
            name: "Albaredo Arnaboldi",
            codCat: "A134"
        },
        {
            name: "Albonese",
            codCat: "A171"
        },
        {
            name: "Albuzzano",
            codCat: "A175"
        },
        {
            name: "Arena Po",
            codCat: "A387"
        },
        {
            name: "Badia Pavese",
            codCat: "A538"
        },
        {
            name: "Bagnaria",
            codCat: "A550"
        },
        {
            name: "Barbianello",
            codCat: "A634"
        },
        {
            name: "Bascapè",
            codCat: "A690"
        },
        {
            name: "Bastida Pancarana",
            codCat: "A712"
        },
        {
            name: "Battuda",
            codCat: "A718"
        },
        {
            name: "Belgioioso",
            codCat: "A741"
        },
        {
            name: "Bereguardo",
            codCat: "A792"
        },
        {
            name: "Borgarello",
            codCat: "A989"
        },
        {
            name: "Borgo Priolo",
            codCat: "B028"
        },
        {
            name: "Borgoratto Mormorolo",
            codCat: "B030"
        },
        {
            name: "Borgo San Siro",
            codCat: "B038"
        },
        {
            name: "Bornasco",
            codCat: "B051"
        },
        {
            name: "Bosnasco",
            codCat: "B082"
        },
        {
            name: "Brallo di Pregola",
            codCat: "B117"
        },
        {
            name: "Breme",
            codCat: "B142"
        },
        {
            name: "Bressana Bottarone",
            codCat: "B159"
        },
        {
            name: "Broni",
            codCat: "B201"
        },
        {
            name: "Calvignano",
            codCat: "B447"
        },
        {
            name: "Campospinoso",
            codCat: "B567"
        },
        {
            name: "Candia Lomellina",
            codCat: "B587"
        },
        {
            name: "Canneto Pavese",
            codCat: "B613"
        },
        {
            name: "Carbonara al Ticino",
            codCat: "B741"
        },
        {
            name: "Casanova Lonati",
            codCat: "B929"
        },
        {
            name: "Casatisma",
            codCat: "B945"
        },
        {
            name: "Casei Gerola",
            codCat: "B954"
        },
        {
            name: "Casorate Primo",
            codCat: "B988"
        },
        {
            name: "Cassolnovo",
            codCat: "C038"
        },
        {
            name: "Castana",
            codCat: "C050"
        },
        {
            name: "Casteggio",
            codCat: "C053"
        },
        {
            name: "Castelletto di Branduzzo",
            codCat: "C157"
        },
        {
            name: "Castello d'Agogna",
            codCat: "C184"
        },
        {
            name: "Castelnovetto",
            codCat: "C213"
        },
        {
            name: "Cava Manara",
            codCat: "C360"
        },
        {
            name: "Cecima",
            codCat: "C414"
        },
        {
            name: "Ceranova",
            codCat: "C484"
        },
        {
            name: "Ceretto Lomellina",
            codCat: "C508"
        },
        {
            name: "Cergnago",
            codCat: "C509"
        },
        {
            name: "Certosa di Pavia",
            codCat: "C541"
        },
        {
            name: "Cervesina",
            codCat: "C551"
        },
        {
            name: "Chignolo Po",
            codCat: "C637"
        },
        {
            name: "Cigognola",
            codCat: "C684"
        },
        {
            name: "Cilavegna",
            codCat: "C686"
        },
        {
            name: "Codevilla",
            codCat: "C813"
        },
        {
            name: "Confienza",
            codCat: "C958"
        },
        {
            name: "Copiano",
            codCat: "C979"
        },
        {
            name: "Corana",
            codCat: "C982"
        },
        {
            name: "Corvino San Quirico",
            codCat: "D081"
        },
        {
            name: "Costa de' Nobili",
            codCat: "D109"
        },
        {
            name: "Cozzo",
            codCat: "D127"
        },
        {
            name: "Cura Carpignano",
            codCat: "B824"
        },
        {
            name: "Dorno",
            codCat: "D348"
        },
        {
            name: "Ferrera Erbognone",
            codCat: "D552"
        },
        {
            name: "Filighera",
            codCat: "D594"
        },
        {
            name: "Fortunago",
            codCat: "D732"
        },
        {
            name: "Frascarolo",
            codCat: "D771"
        },
        {
            name: "Galliavola",
            codCat: "D873"
        },
        {
            name: "Gambarana",
            codCat: "D892"
        },
        {
            name: "Gambolò",
            codCat: "D901"
        },
        {
            name: "Garlasco",
            codCat: "D925"
        },
        {
            name: "Gerenzago",
            codCat: "D980"
        },
        {
            name: "Giussago",
            codCat: "E062"
        },
        {
            name: "Godiasco Salice Terme",
            codCat: "E072"
        },
        {
            name: "Golferenzo",
            codCat: "E081"
        },
        {
            name: "Gravellona Lomellina",
            codCat: "E152"
        },
        {
            name: "Gropello Cairoli",
            codCat: "E195"
        },
        {
            name: "Inverno e Monteleone",
            codCat: "E310"
        },
        {
            name: "Landriano",
            codCat: "E437"
        },
        {
            name: "Langosco",
            codCat: "E439"
        },
        {
            name: "Lardirago",
            codCat: "E454"
        },
        {
            name: "Linarolo",
            codCat: "E600"
        },
        {
            name: "Lirio",
            codCat: "E608"
        },
        {
            name: "Lomello",
            codCat: "E662"
        },
        {
            name: "Lungavilla",
            codCat: "B387"
        },
        {
            name: "Magherno",
            codCat: "E804"
        },
        {
            name: "Marcignago",
            codCat: "E934"
        },
        {
            name: "Marzano",
            codCat: "E999"
        },
        {
            name: "Mede",
            codCat: "F080"
        },
        {
            name: "Menconico",
            codCat: "F122"
        },
        {
            name: "Mezzana Bigli",
            codCat: "F170"
        },
        {
            name: "Mezzana Rabattone",
            codCat: "F171"
        },
        {
            name: "Mezzanino",
            codCat: "F175"
        },
        {
            name: "Miradolo Terme",
            codCat: "F238"
        },
        {
            name: "Montalto Pavese",
            codCat: "F417"
        },
        {
            name: "Montebello della Battaglia",
            codCat: "F440"
        },
        {
            name: "Montecalvo Versiggia",
            codCat: "F449"
        },
        {
            name: "Montescano",
            codCat: "F638"
        },
        {
            name: "Montesegale",
            codCat: "F644"
        },
        {
            name: "Monticelli Pavese",
            codCat: "F670"
        },
        {
            name: "Montù Beccaria",
            codCat: "F701"
        },
        {
            name: "Mornico Losana",
            codCat: "F739"
        },
        {
            name: "Mortara",
            codCat: "F754"
        },
        {
            name: "Nicorvo",
            codCat: "F891"
        },
        {
            name: "Olevano di Lomellina",
            codCat: "G021"
        },
        {
            name: "Oliva Gessi",
            codCat: "G032"
        },
        {
            name: "Ottobiano",
            codCat: "G194"
        },
        {
            name: "Palestro",
            codCat: "G275"
        },
        {
            name: "Pancarana",
            codCat: "G304"
        },
        {
            name: "Parona",
            codCat: "G342"
        },
        {
            name: "Pavia",
            codCat: "G388"
        },
        {
            name: "Pietra de' Giorgi",
            codCat: "G612"
        },
        {
            name: "Pieve Albignola",
            codCat: "G635"
        },
        {
            name: "Pieve del Cairo",
            codCat: "G639"
        },
        {
            name: "Pieve Porto Morone",
            codCat: "G650"
        },
        {
            name: "Pinarolo Po",
            codCat: "G671"
        },
        {
            name: "Pizzale",
            codCat: "G720"
        },
        {
            name: "Ponte Nizza",
            codCat: "G851"
        },
        {
            name: "Portalbera",
            codCat: "G895"
        },
        {
            name: "Rea",
            codCat: "H204"
        },
        {
            name: "Redavalle",
            codCat: "H216"
        },
        {
            name: "Retorbido",
            codCat: "H246"
        },
        {
            name: "Rivanazzano Terme",
            codCat: "H336"
        },
        {
            name: "Robbio",
            codCat: "H369"
        },
        {
            name: "Robecco Pavese",
            codCat: "H375"
        },
        {
            name: "Rocca de' Giorgi",
            codCat: "H396"
        },
        {
            name: "Rocca Susella",
            codCat: "H450"
        },
        {
            name: "Rognano",
            codCat: "H491"
        },
        {
            name: "Romagnese",
            codCat: "H505"
        },
        {
            name: "Roncaro",
            codCat: "H527"
        },
        {
            name: "Rosasco",
            codCat: "H559"
        },
        {
            name: "Rovescala",
            codCat: "H614"
        },
        {
            name: "San Cipriano Po",
            codCat: "H799"
        },
        {
            name: "San Damiano al Colle",
            codCat: "H814"
        },
        {
            name: "San Genesio ed Uniti",
            codCat: "H859"
        },
        {
            name: "San Giorgio di Lomellina",
            codCat: "H885"
        },
        {
            name: "San Martino Siccomario",
            codCat: "I014"
        },
        {
            name: "Sannazzaro de' Burgondi",
            codCat: "I048"
        },
        {
            name: "Santa Cristina e Bissone",
            codCat: "I175"
        },
        {
            name: "Santa Giuletta",
            codCat: "I203"
        },
        {
            name: "Sant'Alessio con Vialone",
            codCat: "I213"
        },
        {
            name: "Santa Margherita di Staffora",
            codCat: "I230"
        },
        {
            name: "Santa Maria della Versa",
            codCat: "I237"
        },
        {
            name: "Sant'Angelo Lomellina",
            codCat: "I276"
        },
        {
            name: "San Zenone al Po",
            codCat: "I416"
        },
        {
            name: "Sartirana Lomellina",
            codCat: "I447"
        },
        {
            name: "Scaldasole",
            codCat: "I487"
        },
        {
            name: "Semiana",
            codCat: "I599"
        },
        {
            name: "Silvano Pietra",
            codCat: "I739"
        },
        {
            name: "Siziano",
            codCat: "E265"
        },
        {
            name: "Sommo",
            codCat: "I825"
        },
        {
            name: "Spessa",
            codCat: "I894"
        },
        {
            name: "Stradella",
            codCat: "I968"
        },
        {
            name: "Suardi",
            codCat: "B014"
        },
        {
            name: "Torrazza Coste",
            codCat: "L237"
        },
        {
            name: "Torre Beretti e Castellaro",
            codCat: "L250"
        },
        {
            name: "Torre d'Arese",
            codCat: "L256"
        },
        {
            name: "Torre de' Negri",
            codCat: "L262"
        },
        {
            name: "Torre d'Isola",
            codCat: "L269"
        },
        {
            name: "Torrevecchia Pia",
            codCat: "L285"
        },
        {
            name: "Torricella Verzate",
            codCat: "L292"
        },
        {
            name: "Travacò Siccomario",
            codCat: "I236"
        },
        {
            name: "Trivolzio",
            codCat: "L440"
        },
        {
            name: "Tromello",
            codCat: "L449"
        },
        {
            name: "Trovo",
            codCat: "L453"
        },
        {
            name: "Val di Nizza",
            codCat: "L562"
        },
        {
            name: "Valeggio",
            codCat: "L568"
        },
        {
            name: "Valle Lomellina",
            codCat: "L593"
        },
        {
            name: "Valle Salimbene",
            codCat: "L617"
        },
        {
            name: "Varzi",
            codCat: "L690"
        },
        {
            name: "Velezzo Lomellina",
            codCat: "L716"
        },
        {
            name: "Vellezzo Bellini",
            codCat: "L720"
        },
        {
            name: "Verretto",
            codCat: "L784"
        },
        {
            name: "Verrua Po",
            codCat: "L788"
        },
        {
            name: "Vidigulfo",
            codCat: "L854"
        },
        {
            name: "Vigevano",
            codCat: "L872"
        },
        {
            name: "Villa Biscossi",
            codCat: "L917"
        },
        {
            name: "Villanova d'Ardenghi",
            codCat: "L983"
        },
        {
            name: "Villanterio",
            codCat: "L994"
        },
        {
            name: "Vistarino",
            codCat: "M079"
        },
        {
            name: "Voghera",
            codCat: "M109"
        },
        {
            name: "Volpara",
            codCat: "M119"
        },
        {
            name: "Zavattarello",
            codCat: "M150"
        },
        {
            name: "Zeccone",
            codCat: "M152"
        },
        {
            name: "Zeme",
            codCat: "M161"
        },
        {
            name: "Zenevredo",
            codCat: "M162"
        },
        {
            name: "Zerbo",
            codCat: "M166"
        },
        {
            name: "Zerbolò",
            codCat: "M167"
        },
        {
            name: "Zinasco",
            codCat: "M180"
        },
        {
            name: "Cornale e Bastida",
            codCat: "M338"
        },
        {
            name: "Corteolona e Genzone",
            codCat: "M372"
        },
        {
            name: "Colli Verdi",
            codCat: "M419"
        },
        {
            name: "Acquanegra Cremonese",
            codCat: "A039"
        },
        {
            name: "Agnadello",
            codCat: "A076"
        },
        {
            name: "Annicco",
            codCat: "A299"
        },
        {
            name: "Azzanello",
            codCat: "A526"
        },
        {
            name: "Bagnolo Cremasco",
            codCat: "A570"
        },
        {
            name: "Bonemerse",
            codCat: "A972"
        },
        {
            name: "Bordolano",
            codCat: "A986"
        },
        {
            name: "Calvatone",
            codCat: "B439"
        },
        {
            name: "Camisano",
            codCat: "B484"
        },
        {
            name: "Campagnola Cremasca",
            codCat: "B498"
        },
        {
            name: "Capergnanica",
            codCat: "B650"
        },
        {
            name: "Cappella Cantone",
            codCat: "B679"
        },
        {
            name: "Cappella de' Picenardi",
            codCat: "B680"
        },
        {
            name: "Capralba",
            codCat: "B686"
        },
        {
            name: "Casalbuttano ed Uniti",
            codCat: "B869"
        },
        {
            name: "Casale Cremasco-Vidolasco",
            codCat: "B881"
        },
        {
            name: "Casaletto Ceredano",
            codCat: "B889"
        },
        {
            name: "Casaletto di Sopra",
            codCat: "B890"
        },
        {
            name: "Casaletto Vaprio",
            codCat: "B891"
        },
        {
            name: "Casalmaggiore",
            codCat: "B898"
        },
        {
            name: "Casalmorano",
            codCat: "B900"
        },
        {
            name: "Casteldidone",
            codCat: "C089"
        },
        {
            name: "Castel Gabbiano",
            codCat: "C115"
        },
        {
            name: "Castelleone",
            codCat: "C153"
        },
        {
            name: "Castelverde",
            codCat: "B129"
        },
        {
            name: "Castelvisconti",
            codCat: "C290"
        },
        {
            name: "Cella Dati",
            codCat: "C435"
        },
        {
            name: "Chieve",
            codCat: "C634"
        },
        {
            name: "Cicognolo",
            codCat: "C678"
        },
        {
            name: "Cingia de' Botti",
            codCat: "C703"
        },
        {
            name: "Corte de' Cortesi con Cignone",
            codCat: "D056"
        },
        {
            name: "Corte de' Frati",
            codCat: "D057"
        },
        {
            name: "Credera Rubbiano",
            codCat: "D141"
        },
        {
            name: "Crema",
            codCat: "D142"
        },
        {
            name: "Cremona",
            codCat: "D150"
        },
        {
            name: "Cremosano",
            codCat: "D151"
        },
        {
            name: "Crotta d'Adda",
            codCat: "D186"
        },
        {
            name: "Cumignano sul Naviglio",
            codCat: "D203"
        },
        {
            name: "Derovere",
            codCat: "D278"
        },
        {
            name: "Dovera",
            codCat: "D358"
        },
        {
            name: "Fiesco",
            codCat: "D574"
        },
        {
            name: "Formigara",
            codCat: "D710"
        },
        {
            name: "Gabbioneta-Binanuova",
            codCat: "D834"
        },
        {
            name: "Gadesco-Pieve Delmona",
            codCat: "D841"
        },
        {
            name: "Genivolta",
            codCat: "D966"
        },
        {
            name: "Gerre de' Caprioli",
            codCat: "D993"
        },
        {
            name: "Gombito",
            codCat: "E082"
        },
        {
            name: "Grontardo",
            codCat: "E193"
        },
        {
            name: "Grumello Cremonese ed Uniti",
            codCat: "E217"
        },
        {
            name: "Gussola",
            codCat: "E272"
        },
        {
            name: "Isola Dovarese",
            codCat: "E356"
        },
        {
            name: "Izano",
            codCat: "E380"
        },
        {
            name: "Madignano",
            codCat: "E793"
        },
        {
            name: "Malagnino",
            codCat: "E843"
        },
        {
            name: "Martignana di Po",
            codCat: "E983"
        },
        {
            name: "Monte Cremasco",
            codCat: "F434"
        },
        {
            name: "Montodine",
            codCat: "F681"
        },
        {
            name: "Moscazzano",
            codCat: "F761"
        },
        {
            name: "Motta Baluffi",
            codCat: "F771"
        },
        {
            name: "Offanengo",
            codCat: "G004"
        },
        {
            name: "Olmeneta",
            codCat: "G047"
        },
        {
            name: "Ostiano",
            codCat: "G185"
        },
        {
            name: "Paderno Ponchielli",
            codCat: "G222"
        },
        {
            name: "Palazzo Pignano",
            codCat: "G260"
        },
        {
            name: "Pandino",
            codCat: "G306"
        },
        {
            name: "Persico Dosimo",
            codCat: "G469"
        },
        {
            name: "Pescarolo ed Uniti",
            codCat: "G483"
        },
        {
            name: "Pessina Cremonese",
            codCat: "G504"
        },
        {
            name: "Pianengo",
            codCat: "G558"
        },
        {
            name: "Pieranica",
            codCat: "G603"
        },
        {
            name: "Pieve d'Olmi",
            codCat: "G647"
        },
        {
            name: "Pieve San Giacomo",
            codCat: "G651"
        },
        {
            name: "Pizzighettone",
            codCat: "G721"
        },
        {
            name: "Pozzaglio ed Uniti",
            codCat: "B914"
        },
        {
            name: "Quintano",
            codCat: "H130"
        },
        {
            name: "Ricengo",
            codCat: "H276"
        },
        {
            name: "Ripalta Arpina",
            codCat: "H314"
        },
        {
            name: "Ripalta Cremasca",
            codCat: "H315"
        },
        {
            name: "Ripalta Guerina",
            codCat: "H316"
        },
        {
            name: "Rivarolo del Re ed Uniti",
            codCat: "H341"
        },
        {
            name: "Rivolta d'Adda",
            codCat: "H357"
        },
        {
            name: "Robecco d'Oglio",
            codCat: "H372"
        },
        {
            name: "Romanengo",
            codCat: "H508"
        },
        {
            name: "Salvirola",
            codCat: "H731"
        },
        {
            name: "San Bassano",
            codCat: "H767"
        },
        {
            name: "San Daniele Po",
            codCat: "H815"
        },
        {
            name: "San Giovanni in Croce",
            codCat: "H918"
        },
        {
            name: "San Martino del Lago",
            codCat: "I007"
        },
        {
            name: "Scandolara Ravara",
            codCat: "I497"
        },
        {
            name: "Scandolara Ripa d'Oglio",
            codCat: "I498"
        },
        {
            name: "Sergnano",
            codCat: "I627"
        },
        {
            name: "Sesto ed Uniti",
            codCat: "I683"
        },
        {
            name: "Solarolo Rainerio",
            codCat: "I790"
        },
        {
            name: "Soncino",
            codCat: "I827"
        },
        {
            name: "Soresina",
            codCat: "I849"
        },
        {
            name: "Sospiro",
            codCat: "I865"
        },
        {
            name: "Spinadesco",
            codCat: "I906"
        },
        {
            name: "Spineda",
            codCat: "I909"
        },
        {
            name: "Spino d'Adda",
            codCat: "I914"
        },
        {
            name: "Stagno Lombardo",
            codCat: "I935"
        },
        {
            name: "Ticengo",
            codCat: "L164"
        },
        {
            name: "Torlino Vimercati",
            codCat: "L221"
        },
        {
            name: "Tornata",
            codCat: "L225"
        },
        {
            name: "Torre de' Picenardi",
            codCat: "L258"
        },
        {
            name: "Torricella del Pizzo",
            codCat: "L296"
        },
        {
            name: "Trescore Cremasco",
            codCat: "L389"
        },
        {
            name: "Trigolo",
            codCat: "L426"
        },
        {
            name: "Vaiano Cremasco",
            codCat: "L535"
        },
        {
            name: "Vailate",
            codCat: "L539"
        },
        {
            name: "Vescovato",
            codCat: "L806"
        },
        {
            name: "Volongo",
            codCat: "M116"
        },
        {
            name: "Voltido",
            codCat: "M127"
        },
        {
            name: "Piadena Drizzona",
            codCat: "M418"
        },
        {
            name: "Acquanegra sul Chiese",
            codCat: "A038"
        },
        {
            name: "Asola",
            codCat: "A470"
        },
        {
            name: "Bagnolo San Vito",
            codCat: "A575"
        },
        {
            name: "Bozzolo",
            codCat: "B110"
        },
        {
            name: "Canneto sull'Oglio",
            codCat: "B612"
        },
        {
            name: "Casalmoro",
            codCat: "B901"
        },
        {
            name: "Casaloldo",
            codCat: "B907"
        },
        {
            name: "Casalromano",
            codCat: "B911"
        },
        {
            name: "Castelbelforte",
            codCat: "C059"
        },
        {
            name: "Castel d'Ario",
            codCat: "C076"
        },
        {
            name: "Castel Goffredo",
            codCat: "C118"
        },
        {
            name: "Castellucchio",
            codCat: "C195"
        },
        {
            name: "Castiglione delle Stiviere",
            codCat: "C312"
        },
        {
            name: "Cavriana",
            codCat: "C406"
        },
        {
            name: "Ceresara",
            codCat: "C502"
        },
        {
            name: "Commessaggio",
            codCat: "C930"
        },
        {
            name: "Curtatone",
            codCat: "D227"
        },
        {
            name: "Dosolo",
            codCat: "D351"
        },
        {
            name: "Gazoldo degli Ippoliti",
            codCat: "D949"
        },
        {
            name: "Gazzuolo",
            codCat: "D959"
        },
        {
            name: "Goito",
            codCat: "E078"
        },
        {
            name: "Gonzaga",
            codCat: "E089"
        },
        {
            name: "Guidizzolo",
            codCat: "E261"
        },
        {
            name: "Magnacavallo",
            codCat: "E818"
        },
        {
            name: "Mantova",
            codCat: "E897"
        },
        {
            name: "Marcaria",
            codCat: "E922"
        },
        {
            name: "Mariana Mantovana",
            codCat: "E949"
        },
        {
            name: "Marmirolo",
            codCat: "E962"
        },
        {
            name: "Medole",
            codCat: "F086"
        },
        {
            name: "Moglia",
            codCat: "F267"
        },
        {
            name: "Monzambano",
            codCat: "F705"
        },
        {
            name: "Motteggiana",
            codCat: "B012"
        },
        {
            name: "Ostiglia",
            codCat: "G186"
        },
        {
            name: "Pegognaga",
            codCat: "G417"
        },
        {
            name: "Piubega",
            codCat: "G717"
        },
        {
            name: "Poggio Rusco",
            codCat: "G753"
        },
        {
            name: "Pomponesco",
            codCat: "G816"
        },
        {
            name: "Ponti sul Mincio",
            codCat: "G862"
        },
        {
            name: "Porto Mantovano",
            codCat: "G917"
        },
        {
            name: "Quingentole",
            codCat: "H129"
        },
        {
            name: "Quistello",
            codCat: "H143"
        },
        {
            name: "Redondesco",
            codCat: "H218"
        },
        {
            name: "Rivarolo Mantovano",
            codCat: "H342"
        },
        {
            name: "Rodigo",
            codCat: "H481"
        },
        {
            name: "Roncoferraro",
            codCat: "H541"
        },
        {
            name: "Roverbella",
            codCat: "H604"
        },
        {
            name: "Sabbioneta",
            codCat: "H652"
        },
        {
            name: "San Benedetto Po",
            codCat: "H771"
        },
        {
            name: "San Giacomo delle Segnate",
            codCat: "H870"
        },
        {
            name: "San Giorgio Bigarello",
            codCat: "H883"
        },
        {
            name: "San Giovanni del Dosso",
            codCat: "H912"
        },
        {
            name: "San Martino dall'Argine",
            codCat: "I005"
        },
        {
            name: "Schivenoglia",
            codCat: "I532"
        },
        {
            name: "Sermide e Felonica",
            codCat: "I632"
        },
        {
            name: "Serravalle a Po",
            codCat: "I662"
        },
        {
            name: "Solferino",
            codCat: "I801"
        },
        {
            name: "Sustinente",
            codCat: "L015"
        },
        {
            name: "Suzzara",
            codCat: "L020"
        },
        {
            name: "Viadana",
            codCat: "L826"
        },
        {
            name: "Villimpenta",
            codCat: "M044"
        },
        {
            name: "Volta Mantovana",
            codCat: "M125"
        },
        {
            name: "Borgo Virgilio",
            codCat: "M340"
        },
        {
            name: "Borgo Mantovano",
            codCat: "M396"
        },
        {
            name: "Borgocarbonara",
            codCat: "M406"
        },
        {
            name: "Abbadia Lariana",
            codCat: "A005"
        },
        {
            name: "Airuno",
            codCat: "A112"
        },
        {
            name: "Annone di Brianza",
            codCat: "A301"
        },
        {
            name: "Ballabio",
            codCat: "A594"
        },
        {
            name: "Barzago",
            codCat: "A683"
        },
        {
            name: "Barzanò",
            codCat: "A686"
        },
        {
            name: "Barzio",
            codCat: "A687"
        },
        {
            name: "Bellano",
            codCat: "A745"
        },
        {
            name: "Bosisio Parini",
            codCat: "B081"
        },
        {
            name: "Brivio",
            codCat: "B194"
        },
        {
            name: "Bulciago",
            codCat: "B261"
        },
        {
            name: "Calco",
            codCat: "B396"
        },
        {
            name: "Calolziocorte",
            codCat: "B423"
        },
        {
            name: "Carenno",
            codCat: "B763"
        },
        {
            name: "Casargo",
            codCat: "B937"
        },
        {
            name: "Casatenovo",
            codCat: "B943"
        },
        {
            name: "Cassago Brianza",
            codCat: "B996"
        },
        {
            name: "Cassina Valsassina",
            codCat: "C024"
        },
        {
            name: "Castello di Brianza",
            codCat: "C187"
        },
        {
            name: "Cernusco Lombardone",
            codCat: "C521"
        },
        {
            name: "Cesana Brianza",
            codCat: "C563"
        },
        {
            name: "Civate",
            codCat: "C752"
        },
        {
            name: "Colico",
            codCat: "C839"
        },
        {
            name: "Colle Brianza",
            codCat: "C851"
        },
        {
            name: "Cortenova",
            codCat: "D065"
        },
        {
            name: "Costa Masnaga",
            codCat: "D112"
        },
        {
            name: "Crandola Valsassina",
            codCat: "D131"
        },
        {
            name: "Cremella",
            codCat: "D143"
        },
        {
            name: "Cremeno",
            codCat: "D145"
        },
        {
            name: "Dervio",
            codCat: "D280"
        },
        {
            name: "Dolzago",
            codCat: "D327"
        },
        {
            name: "Dorio",
            codCat: "D346"
        },
        {
            name: "Ello",
            codCat: "D398"
        },
        {
            name: "Erve",
            codCat: "D428"
        },
        {
            name: "Esino Lario",
            codCat: "D436"
        },
        {
            name: "Galbiate",
            codCat: "D865"
        },
        {
            name: "Garbagnate Monastero",
            codCat: "D913"
        },
        {
            name: "Garlate",
            codCat: "D926"
        },
        {
            name: "Imbersago",
            codCat: "E287"
        },
        {
            name: "Introbio",
            codCat: "E305"
        },
        {
            name: "Lecco",
            codCat: "E507"
        },
        {
            name: "Lierna",
            codCat: "E581"
        },
        {
            name: "Lomagna",
            codCat: "E656"
        },
        {
            name: "Malgrate",
            codCat: "E858"
        },
        {
            name: "Mandello del Lario",
            codCat: "E879"
        },
        {
            name: "Margno",
            codCat: "E947"
        },
        {
            name: "Merate",
            codCat: "F133"
        },
        {
            name: "Missaglia",
            codCat: "F248"
        },
        {
            name: "Moggio",
            codCat: "F265"
        },
        {
            name: "Molteno",
            codCat: "F304"
        },
        {
            name: "Monte Marenzo",
            codCat: "F561"
        },
        {
            name: "Montevecchia",
            codCat: "F657"
        },
        {
            name: "Monticello Brianza",
            codCat: "F674"
        },
        {
            name: "Morterone",
            codCat: "F758"
        },
        {
            name: "Nibionno",
            codCat: "F887"
        },
        {
            name: "Oggiono",
            codCat: "G009"
        },
        {
            name: "Olgiate Molgora",
            codCat: "G026"
        },
        {
            name: "Olginate",
            codCat: "G030"
        },
        {
            name: "Oliveto Lario",
            codCat: "G040"
        },
        {
            name: "Osnago",
            codCat: "G161"
        },
        {
            name: "Paderno d'Adda",
            codCat: "G218"
        },
        {
            name: "Pagnona",
            codCat: "G241"
        },
        {
            name: "Parlasco",
            codCat: "G336"
        },
        {
            name: "Pasturo",
            codCat: "G368"
        },
        {
            name: "Perledo",
            codCat: "G456"
        },
        {
            name: "Pescate",
            codCat: "G485"
        },
        {
            name: "Premana",
            codCat: "H028"
        },
        {
            name: "Primaluna",
            codCat: "H063"
        },
        {
            name: "Robbiate",
            codCat: "G223"
        },
        {
            name: "Rogeno",
            codCat: "H486"
        },
        {
            name: "Santa Maria Hoè",
            codCat: "I243"
        },
        {
            name: "Sirone",
            codCat: "I759"
        },
        {
            name: "Sirtori",
            codCat: "I761"
        },
        {
            name: "Sueglio",
            codCat: "I994"
        },
        {
            name: "Suello",
            codCat: "I996"
        },
        {
            name: "Taceno",
            codCat: "L022"
        },
        {
            name: "Valgreghentino",
            codCat: "L581"
        },
        {
            name: "Valmadrera",
            codCat: "L634"
        },
        {
            name: "Varenna",
            codCat: "L680"
        },
        {
            name: "Vercurago",
            codCat: "L751"
        },
        {
            name: "Viganò",
            codCat: "L866"
        },
        {
            name: "Verderio",
            codCat: "M337"
        },
        {
            name: "La Valletta Brianza",
            codCat: "M348"
        },
        {
            name: "Valvarrone",
            codCat: "M395"
        },
        {
            name: "Abbadia Cerreto",
            codCat: "A004"
        },
        {
            name: "Bertonico",
            codCat: "A811"
        },
        {
            name: "Boffalora d'Adda",
            codCat: "A919"
        },
        {
            name: "Borghetto Lodigiano",
            codCat: "A995"
        },
        {
            name: "Borgo San Giovanni",
            codCat: "B017"
        },
        {
            name: "Brembio",
            codCat: "B141"
        },
        {
            name: "Casaletto Lodigiano",
            codCat: "B887"
        },
        {
            name: "Casalmaiocco",
            codCat: "B899"
        },
        {
            name: "Casalpusterlengo",
            codCat: "B910"
        },
        {
            name: "Caselle Landi",
            codCat: "B961"
        },
        {
            name: "Caselle Lurani",
            codCat: "B958"
        },
        {
            name: "Castelnuovo Bocca d'Adda",
            codCat: "C228"
        },
        {
            name: "Castiglione d'Adda",
            codCat: "C304"
        },
        {
            name: "Castiraga Vidardo",
            codCat: "C329"
        },
        {
            name: "Cavenago d'Adda",
            codCat: "C394"
        },
        {
            name: "Cervignano d'Adda",
            codCat: "C555"
        },
        {
            name: "Codogno",
            codCat: "C816"
        },
        {
            name: "Comazzo",
            codCat: "C917"
        },
        {
            name: "Cornegliano Laudense",
            codCat: "D021"
        },
        {
            name: "Corno Giovine",
            codCat: "D028"
        },
        {
            name: "Cornovecchio",
            codCat: "D029"
        },
        {
            name: "Corte Palasio",
            codCat: "D068"
        },
        {
            name: "Crespiatica",
            codCat: "D159"
        },
        {
            name: "Fombio",
            codCat: "D660"
        },
        {
            name: "Galgagnano",
            codCat: "D868"
        },
        {
            name: "Graffignana",
            codCat: "E127"
        },
        {
            name: "Guardamiglio",
            codCat: "E238"
        },
        {
            name: "Livraga",
            codCat: "E627"
        },
        {
            name: "Lodi",
            codCat: "E648"
        },
        {
            name: "Lodi Vecchio",
            codCat: "E651"
        },
        {
            name: "Maccastorna",
            codCat: "E777"
        },
        {
            name: "Mairago",
            codCat: "E840"
        },
        {
            name: "Maleo",
            codCat: "E852"
        },
        {
            name: "Marudo",
            codCat: "E994"
        },
        {
            name: "Massalengo",
            codCat: "F028"
        },
        {
            name: "Meleti",
            codCat: "F102"
        },
        {
            name: "Merlino",
            codCat: "F149"
        },
        {
            name: "Montanaso Lombardo",
            codCat: "F423"
        },
        {
            name: "Mulazzano",
            codCat: "F801"
        },
        {
            name: "Orio Litta",
            codCat: "G107"
        },
        {
            name: "Ospedaletto Lodigiano",
            codCat: "G166"
        },
        {
            name: "Ossago Lodigiano",
            codCat: "G171"
        },
        {
            name: "Pieve Fissiraga",
            codCat: "G096"
        },
        {
            name: "Salerano sul Lambro",
            codCat: "H701"
        },
        {
            name: "San Fiorano",
            codCat: "H844"
        },
        {
            name: "San Martino in Strada",
            codCat: "I012"
        },
        {
            name: "San Rocco al Porto",
            codCat: "I140"
        },
        {
            name: "Sant'Angelo Lodigiano",
            codCat: "I274"
        },
        {
            name: "Santo Stefano Lodigiano",
            codCat: "I362"
        },
        {
            name: "Secugnago",
            codCat: "I561"
        },
        {
            name: "Senna Lodigiana",
            codCat: "I612"
        },
        {
            name: "Somaglia",
            codCat: "I815"
        },
        {
            name: "Sordio",
            codCat: "I848"
        },
        {
            name: "Tavazzano con Villavesco",
            codCat: "F260"
        },
        {
            name: "Terranova dei Passerini",
            codCat: "L125"
        },
        {
            name: "Turano Lodigiano",
            codCat: "L469"
        },
        {
            name: "Valera Fratta",
            codCat: "L572"
        },
        {
            name: "Villanova del Sillaro",
            codCat: "L977"
        },
        {
            name: "Zelo Buon Persico",
            codCat: "M158"
        },
        {
            name: "Castelgerundo",
            codCat: "M393"
        },
        {
            name: "Agrate Brianza",
            codCat: "A087"
        },
        {
            name: "Aicurzio",
            codCat: "A096"
        },
        {
            name: "Albiate",
            codCat: "A159"
        },
        {
            name: "Arcore",
            codCat: "A376"
        },
        {
            name: "Barlassina",
            codCat: "A668"
        },
        {
            name: "Bellusco",
            codCat: "A759"
        },
        {
            name: "Bernareggio",
            codCat: "A802"
        },
        {
            name: "Besana in Brianza",
            codCat: "A818"
        },
        {
            name: "Biassono",
            codCat: "A849"
        },
        {
            name: "Bovisio-Masciago",
            codCat: "B105"
        },
        {
            name: "Briosco",
            codCat: "B187"
        },
        {
            name: "Brugherio",
            codCat: "B212"
        },
        {
            name: "Burago di Molgora",
            codCat: "B272"
        },
        {
            name: "Camparada",
            codCat: "B501"
        },
        {
            name: "Carate Brianza",
            codCat: "B729"
        },
        {
            name: "Carnate",
            codCat: "B798"
        },
        {
            name: "Cavenago di Brianza",
            codCat: "C395"
        },
        {
            name: "Ceriano Laghetto",
            codCat: "C512"
        },
        {
            name: "Cesano Maderno",
            codCat: "C566"
        },
        {
            name: "Cogliate",
            codCat: "C820"
        },
        {
            name: "Concorezzo",
            codCat: "C952"
        },
        {
            name: "Correzzana",
            codCat: "D038"
        },
        {
            name: "Desio",
            codCat: "D286"
        },
        {
            name: "Giussano",
            codCat: "E063"
        },
        {
            name: "Lazzate",
            codCat: "E504"
        },
        {
            name: "Lesmo",
            codCat: "E550"
        },
        {
            name: "Limbiate",
            codCat: "E591"
        },
        {
            name: "Lissone",
            codCat: "E617"
        },
        {
            name: "Macherio",
            codCat: "E786"
        },
        {
            name: "Meda",
            codCat: "F078"
        },
        {
            name: "Mezzago",
            codCat: "F165"
        },
        {
            name: "Misinto",
            codCat: "F247"
        },
        {
            name: "Monza",
            codCat: "F704"
        },
        {
            name: "Muggiò",
            codCat: "F797"
        },
        {
            name: "Nova Milanese",
            codCat: "F944"
        },
        {
            name: "Ornago",
            codCat: "G116"
        },
        {
            name: "Renate",
            codCat: "H233"
        },
        {
            name: "Ronco Briantino",
            codCat: "H537"
        },
        {
            name: "Seregno",
            codCat: "I625"
        },
        {
            name: "Seveso",
            codCat: "I709"
        },
        {
            name: "Sovico",
            codCat: "I878"
        },
        {
            name: "Sulbiate",
            codCat: "I998"
        },
        {
            name: "Triuggio",
            codCat: "L434"
        },
        {
            name: "Usmate Velate",
            codCat: "L511"
        },
        {
            name: "Varedo",
            codCat: "L677"
        },
        {
            name: "Vedano al Lambro",
            codCat: "L704"
        },
        {
            name: "Veduggio con Colzano",
            codCat: "L709"
        },
        {
            name: "Verano Brianza",
            codCat: "L744"
        },
        {
            name: "Villasanta",
            codCat: "M017"
        },
        {
            name: "Vimercate",
            codCat: "M052"
        },
        {
            name: "Busnago",
            codCat: "B289"
        },
        {
            name: "Caponago",
            codCat: "B671"
        },
        {
            name: "Cornate d'Adda",
            codCat: "D019"
        },
        {
            name: "Lentate sul Seveso",
            codCat: "E530"
        },
        {
            name: "Roncello",
            codCat: "H529"
        },
        {
            name: "Aldino",
            codCat: "A179"
        },
        {
            name: "Andriano",
            codCat: "A286"
        },
        {
            name: "Anterivo",
            codCat: "A306"
        },
        {
            name: "Appiano sulla strada del vino",
            codCat: "A332"
        },
        {
            name: "Avelengo",
            codCat: "A507"
        },
        {
            name: "Badia",
            codCat: "A537"
        },
        {
            name: "Barbiano",
            codCat: "A635"
        },
        {
            name: "Bolzano",
            codCat: "A952"
        },
        {
            name: "Braies",
            codCat: "B116"
        },
        {
            name: "Brennero",
            codCat: "B145"
        },
        {
            name: "Bressanone",
            codCat: "B160"
        },
        {
            name: "Bronzolo",
            codCat: "B203"
        },
        {
            name: "Brunico",
            codCat: "B220"
        },
        {
            name: "Caines",
            codCat: "B364"
        },
        {
            name: "Caldaro sulla strada del vino",
            codCat: "B397"
        },
        {
            name: "Campo di Trens",
            codCat: "B529"
        },
        {
            name: "Campo Tures",
            codCat: "B570"
        },
        {
            name: "Castelbello-Ciardes",
            codCat: "C062"
        },
        {
            name: "Castelrotto",
            codCat: "C254"
        },
        {
            name: "Cermes",
            codCat: "A022"
        },
        {
            name: "Chienes",
            codCat: "C625"
        },
        {
            name: "Chiusa",
            codCat: "C652"
        },
        {
            name: "Cornedo all'Isarco",
            codCat: "B799"
        },
        {
            name: "Cortaccia sulla strada del vino",
            codCat: "D048"
        },
        {
            name: "Cortina sulla strada del vino",
            codCat: "D075"
        },
        {
            name: "Corvara in Badia",
            codCat: "D079"
        },
        {
            name: "Curon Venosta",
            codCat: "D222"
        },
        {
            name: "Dobbiaco",
            codCat: "D311"
        },
        {
            name: "Egna",
            codCat: "D392"
        },
        {
            name: "Falzes",
            codCat: "D484"
        },
        {
            name: "Fiè allo Sciliar",
            codCat: "D571"
        },
        {
            name: "Fortezza",
            codCat: "D731"
        },
        {
            name: "Funes",
            codCat: "D821"
        },
        {
            name: "Gais",
            codCat: "D860"
        },
        {
            name: "Gargazzone",
            codCat: "D923"
        },
        {
            name: "Glorenza",
            codCat: "E069"
        },
        {
            name: "Laces",
            codCat: "E398"
        },
        {
            name: "Lagundo",
            codCat: "E412"
        },
        {
            name: "Laion",
            codCat: "E420"
        },
        {
            name: "Laives",
            codCat: "E421"
        },
        {
            name: "Lana",
            codCat: "E434"
        },
        {
            name: "Lasa",
            codCat: "E457"
        },
        {
            name: "Lauregno",
            codCat: "E481"
        },
        {
            name: "Luson",
            codCat: "E764"
        },
        {
            name: "Magrè sulla strada del vino",
            codCat: "E829"
        },
        {
            name: "Malles Venosta",
            codCat: "E862"
        },
        {
            name: "Marebbe",
            codCat: "E938"
        },
        {
            name: "Marlengo",
            codCat: "E959"
        },
        {
            name: "Martello",
            codCat: "E981"
        },
        {
            name: "Meltina",
            codCat: "F118"
        },
        {
            name: "Merano",
            codCat: "F132"
        },
        {
            name: "Monguelfo-Tesido",
            codCat: "F371"
        },
        {
            name: "Montagna",
            codCat: "F392"
        },
        {
            name: "Moso in Passiria",
            codCat: "F766"
        },
        {
            name: "Nalles",
            codCat: "F836"
        },
        {
            name: "Naturno",
            codCat: "F849"
        },
        {
            name: "Naz-Sciaves",
            codCat: "F856"
        },
        {
            name: "Nova Levante",
            codCat: "F949"
        },
        {
            name: "Nova Ponente",
            codCat: "F950"
        },
        {
            name: "Ora",
            codCat: "G083"
        },
        {
            name: "Ortisei",
            codCat: "G140"
        },
        {
            name: "Parcines",
            codCat: "G328"
        },
        {
            name: "Perca",
            codCat: "G443"
        },
        {
            name: "Plaus",
            codCat: "G299"
        },
        {
            name: "Ponte Gardena",
            codCat: "G830"
        },
        {
            name: "Postal",
            codCat: "G936"
        },
        {
            name: "Prato allo Stelvio",
            codCat: "H004"
        },
        {
            name: "Predoi",
            codCat: "H019"
        },
        {
            name: "Proves",
            codCat: "H081"
        },
        {
            name: "Racines",
            codCat: "H152"
        },
        {
            name: "Rasun-Anterselva",
            codCat: "H189"
        },
        {
            name: "Renon",
            codCat: "H236"
        },
        {
            name: "Rifiano",
            codCat: "H284"
        },
        {
            name: "Rio di Pusteria",
            codCat: "H299"
        },
        {
            name: "Rodengo",
            codCat: "H475"
        },
        {
            name: "Salorno sulla strada del vino",
            codCat: "H719"
        },
        {
            name: "San Candido",
            codCat: "H786"
        },
        {
            name: "San Genesio Atesino",
            codCat: "H858"
        },
        {
            name: "San Leonardo in Passiria",
            codCat: "H952"
        },
        {
            name: "San Lorenzo di Sebato",
            codCat: "H956"
        },
        {
            name: "San Martino in Badia",
            codCat: "H988"
        },
        {
            name: "San Martino in Passiria",
            codCat: "H989"
        },
        {
            name: "San Pancrazio",
            codCat: "I065"
        },
        {
            name: "Santa Cristina Valgardena",
            codCat: "I173"
        },
        {
            name: "Sarentino",
            codCat: "I431"
        },
        {
            name: "Scena",
            codCat: "I519"
        },
        {
            name: "Selva dei Molini",
            codCat: "I593"
        },
        {
            name: "Selva di Val Gardena",
            codCat: "I591"
        },
        {
            name: "Senales",
            codCat: "I604"
        },
        {
            name: "Sesto",
            codCat: "I687"
        },
        {
            name: "Silandro",
            codCat: "I729"
        },
        {
            name: "Sluderno",
            codCat: "I771"
        },
        {
            name: "Stelvio",
            codCat: "I948"
        },
        {
            name: "Terento",
            codCat: "L106"
        },
        {
            name: "Terlano",
            codCat: "L108"
        },
        {
            name: "Termeno sulla strada del vino",
            codCat: "L111"
        },
        {
            name: "Tesimo",
            codCat: "L149"
        },
        {
            name: "Tires",
            codCat: "L176"
        },
        {
            name: "Tirolo",
            codCat: "L178"
        },
        {
            name: "Trodena nel parco naturale",
            codCat: "L444"
        },
        {
            name: "Tubre",
            codCat: "L455"
        },
        {
            name: "Ultimo",
            codCat: "L490"
        },
        {
            name: "Vadena",
            codCat: "L527"
        },
        {
            name: "Valdaora",
            codCat: "L552"
        },
        {
            name: "Val di Vizze",
            codCat: "L564"
        },
        {
            name: "Valle Aurina",
            codCat: "L595"
        },
        {
            name: "Valle di Casies",
            codCat: "L601"
        },
        {
            name: "Vandoies",
            codCat: "L660"
        },
        {
            name: "Varna",
            codCat: "L687"
        },
        {
            name: "Verano",
            codCat: "L745"
        },
        {
            name: "Villabassa",
            codCat: "L915"
        },
        {
            name: "Villandro",
            codCat: "L971"
        },
        {
            name: "Vipiteno",
            codCat: "M067"
        },
        {
            name: "Velturno",
            codCat: "L724"
        },
        {
            name: "La Valle",
            codCat: "E491"
        },
        {
            name: "Senale-San Felice",
            codCat: "I603"
        },
        {
            name: "Ala",
            codCat: "A116"
        },
        {
            name: "Albiano",
            codCat: "A158"
        },
        {
            name: "Aldeno",
            codCat: "A178"
        },
        {
            name: "Andalo",
            codCat: "A274"
        },
        {
            name: "Arco",
            codCat: "A372"
        },
        {
            name: "Avio",
            codCat: "A520"
        },
        {
            name: "Baselga di Pinè",
            codCat: "A694"
        },
        {
            name: "Bedollo",
            codCat: "A730"
        },
        {
            name: "Besenello",
            codCat: "A821"
        },
        {
            name: "Bieno",
            codCat: "A863"
        },
        {
            name: "Bleggio Superiore",
            codCat: "A902"
        },
        {
            name: "Bocenago",
            codCat: "A916"
        },
        {
            name: "Bondone",
            codCat: "A968"
        },
        {
            name: "Borgo Valsugana",
            codCat: "B006"
        },
        {
            name: "Brentonico",
            codCat: "B153"
        },
        {
            name: "Bresimo",
            codCat: "B158"
        },
        {
            name: "Caderzone Terme",
            codCat: "B335"
        },
        {
            name: "Calceranica al Lago",
            codCat: "B389"
        },
        {
            name: "Caldes",
            codCat: "B400"
        },
        {
            name: "Caldonazzo",
            codCat: "B404"
        },
        {
            name: "Calliano",
            codCat: "B419"
        },
        {
            name: "Campitello di Fassa",
            codCat: "B514"
        },
        {
            name: "Campodenno",
            codCat: "B525"
        },
        {
            name: "Canal San Bovo",
            codCat: "B577"
        },
        {
            name: "Canazei",
            codCat: "B579"
        },
        {
            name: "Capriana",
            codCat: "B697"
        },
        {
            name: "Carisolo",
            codCat: "B783"
        },
        {
            name: "Carzano",
            codCat: "B856"
        },
        {
            name: "Castel Condino",
            codCat: "C183"
        },
        {
            name: "Castello-Molina di Fiemme",
            codCat: "C189"
        },
        {
            name: "Castello Tesino",
            codCat: "C194"
        },
        {
            name: "Castelnuovo",
            codCat: "C216"
        },
        {
            name: "Cavalese",
            codCat: "C372"
        },
        {
            name: "Cavareno",
            codCat: "C380"
        },
        {
            name: "Cavedago",
            codCat: "C392"
        },
        {
            name: "Cavedine",
            codCat: "C393"
        },
        {
            name: "Cavizzana",
            codCat: "C400"
        },
        {
            name: "Cimone",
            codCat: "C700"
        },
        {
            name: "Cinte Tesino",
            codCat: "C712"
        },
        {
            name: "Cis",
            codCat: "C727"
        },
        {
            name: "Civezzano",
            codCat: "C756"
        },
        {
            name: "Cles",
            codCat: "C794"
        },
        {
            name: "Commezzadura",
            codCat: "C931"
        },
        {
            name: "Croviana",
            codCat: "D188"
        },
        {
            name: "Dambel",
            codCat: "D246"
        },
        {
            name: "Denno",
            codCat: "D273"
        },
        {
            name: "Drena",
            codCat: "D365"
        },
        {
            name: "Dro",
            codCat: "D371"
        },
        {
            name: "Fai della Paganella",
            codCat: "D468"
        },
        {
            name: "Fiavè",
            codCat: "D565"
        },
        {
            name: "Fierozzo",
            codCat: "D573"
        },
        {
            name: "Folgaria",
            codCat: "D651"
        },
        {
            name: "Fornace",
            codCat: "D714"
        },
        {
            name: "Frassilongo",
            codCat: "D775"
        },
        {
            name: "Garniga Terme",
            codCat: "D928"
        },
        {
            name: "Giovo",
            codCat: "E048"
        },
        {
            name: "Giustino",
            codCat: "E065"
        },
        {
            name: "Grigno",
            codCat: "E178"
        },
        {
            name: "Imer",
            codCat: "E288"
        },
        {
            name: "Isera",
            codCat: "E334"
        },
        {
            name: "Lavarone",
            codCat: "E492"
        },
        {
            name: "Lavis",
            codCat: "E500"
        },
        {
            name: "Levico Terme",
            codCat: "E565"
        },
        {
            name: "Livo",
            codCat: "E624"
        },
        {
            name: "Lona-Lases",
            codCat: "E664"
        },
        {
            name: "Luserna",
            codCat: "E757"
        },
        {
            name: "Malé",
            codCat: "E850"
        },
        {
            name: "Massimeno",
            codCat: "F045"
        },
        {
            name: "Mazzin",
            codCat: "F068"
        },
        {
            name: "Mezzana",
            codCat: "F168"
        },
        {
            name: "Mezzano",
            codCat: "F176"
        },
        {
            name: "Mezzocorona",
            codCat: "F183"
        },
        {
            name: "Mezzolombardo",
            codCat: "F187"
        },
        {
            name: "Moena",
            codCat: "F263"
        },
        {
            name: "Molveno",
            codCat: "F307"
        },
        {
            name: "Mori",
            codCat: "F728"
        },
        {
            name: "Nago-Torbole",
            codCat: "F835"
        },
        {
            name: "Nogaredo",
            codCat: "F920"
        },
        {
            name: "Nomi",
            codCat: "F929"
        },
        {
            name: "Novaledo",
            codCat: "F947"
        },
        {
            name: "Ospedaletto",
            codCat: "G168"
        },
        {
            name: "Ossana",
            codCat: "G173"
        },
        {
            name: "Palù del Fersina",
            codCat: "G296"
        },
        {
            name: "Panchià",
            codCat: "G305"
        },
        {
            name: "Ronzo-Chienis",
            codCat: "M303"
        },
        {
            name: "Peio",
            codCat: "G419"
        },
        {
            name: "Pellizzano",
            codCat: "G428"
        },
        {
            name: "Pelugo",
            codCat: "G429"
        },
        {
            name: "Pergine Valsugana",
            codCat: "G452"
        },
        {
            name: "Pieve Tesino",
            codCat: "G656"
        },
        {
            name: "Pinzolo",
            codCat: "G681"
        },
        {
            name: "Pomarolo",
            codCat: "G808"
        },
        {
            name: "Predazzo",
            codCat: "H018"
        },
        {
            name: "Rabbi",
            codCat: "H146"
        },
        {
            name: "Riva del Garda",
            codCat: "H330"
        },
        {
            name: "Romeno",
            codCat: "H517"
        },
        {
            name: "Roncegno Terme",
            codCat: "H528"
        },
        {
            name: "Ronchi Valsugana",
            codCat: "H532"
        },
        {
            name: "Ronzone",
            codCat: "H552"
        },
        {
            name: "Roverè della Luna",
            codCat: "H607"
        },
        {
            name: "Rovereto",
            codCat: "H612"
        },
        {
            name: "Ruffrè-Mendola",
            codCat: "H634"
        },
        {
            name: "Rumo",
            codCat: "H639"
        },
        {
            name: "Sagron Mis",
            codCat: "H666"
        },
        {
            name: "Samone",
            codCat: "H754"
        },
        {
            name: "San Michele all'Adige",
            codCat: "I042"
        },
        {
            name: "Sant'Orsola Terme",
            codCat: "I354"
        },
        {
            name: "Sanzeno",
            codCat: "I411"
        },
        {
            name: "Sarnonico",
            codCat: "I439"
        },
        {
            name: "Scurelle",
            codCat: "I554"
        },
        {
            name: "Segonzano",
            codCat: "I576"
        },
        {
            name: "Sfruz",
            codCat: "I714"
        },
        {
            name: "Soraga di Fassa",
            codCat: "I839"
        },
        {
            name: "Sover",
            codCat: "I871"
        },
        {
            name: "Spiazzo",
            codCat: "I899"
        },
        {
            name: "Spormaggiore",
            codCat: "I924"
        },
        {
            name: "Sporminore",
            codCat: "I925"
        },
        {
            name: "Stenico",
            codCat: "I949"
        },
        {
            name: "Storo",
            codCat: "I964"
        },
        {
            name: "Strembo",
            codCat: "I975"
        },
        {
            name: "Telve",
            codCat: "L089"
        },
        {
            name: "Telve di Sopra",
            codCat: "L090"
        },
        {
            name: "Tenna",
            codCat: "L096"
        },
        {
            name: "Tenno",
            codCat: "L097"
        },
        {
            name: "Terragnolo",
            codCat: "L121"
        },
        {
            name: "Terzolas",
            codCat: "L145"
        },
        {
            name: "Tesero",
            codCat: "L147"
        },
        {
            name: "Tione di Trento",
            codCat: "L174"
        },
        {
            name: "Ton",
            codCat: "L200"
        },
        {
            name: "Torcegno",
            codCat: "L211"
        },
        {
            name: "Trambileno",
            codCat: "L322"
        },
        {
            name: "Trento",
            codCat: "L378"
        },
        {
            name: "Valfloriana",
            codCat: "L575"
        },
        {
            name: "Vallarsa",
            codCat: "L588"
        },
        {
            name: "Vermiglio",
            codCat: "L769"
        },
        {
            name: "Vignola-Falesina",
            codCat: "L886"
        },
        {
            name: "Villa Lagarina",
            codCat: "L957"
        },
        {
            name: "Volano",
            codCat: "M113"
        },
        {
            name: "Ziano di Fiemme",
            codCat: "M173"
        },
        {
            name: "Comano Terme",
            codCat: "M314"
        },
        {
            name: "Ledro",
            codCat: "M313"
        },
        {
            name: "Predaia",
            codCat: "M344"
        },
        {
            name: "San Lorenzo Dorsino",
            codCat: "M345"
        },
        {
            name: "Valdaone",
            codCat: "M343"
        },
        {
            name: "Dimaro Folgarida",
            codCat: "M366"
        },
        {
            name: "Pieve di Bono-Prezzo",
            codCat: "M365"
        },
        {
            name: "Altavalle",
            codCat: "M349"
        },
        {
            name: "Altopiano della Vigolana",
            codCat: "M350"
        },
        {
            name: "Amblar-Don",
            codCat: "M351"
        },
        {
            name: "Borgo Chiese",
            codCat: "M352"
        },
        {
            name: "Borgo Lares",
            codCat: "M353"
        },
        {
            name: "Castel Ivano",
            codCat: "M354"
        },
        {
            name: "Cembra Lisignago",
            codCat: "M355"
        },
        {
            name: "Contà",
            codCat: "M356"
        },
        {
            name: "Madruzzo",
            codCat: "M357"
        },
        {
            name: "Porte di Rendena",
            codCat: "M358"
        },
        {
            name: "Primiero San Martino di Castrozza",
            codCat: "M359"
        },
        {
            name: "Sella Giudicarie",
            codCat: "M360"
        },
        {
            name: "Tre Ville",
            codCat: "M361"
        },
        {
            name: "Vallelaghi",
            codCat: "M362"
        },
        {
            name: "Ville d'Anaunia",
            codCat: "M363"
        },
        {
            name: "San Giovanni di Fassa",
            codCat: "M390"
        },
        {
            name: "Terre d'Adige",
            codCat: "M407"
        },
        {
            name: "Borgo d'Anaunia",
            codCat: "M429"
        },
        {
            name: "Novella",
            codCat: "M430"
        },
        {
            name: "Ville di Fiemme",
            codCat: "M431"
        },
        {
            name: "Affi",
            codCat: "A061"
        },
        {
            name: "Albaredo d'Adige",
            codCat: "A137"
        },
        {
            name: "Angiari",
            codCat: "A292"
        },
        {
            name: "Arcole",
            codCat: "A374"
        },
        {
            name: "Badia Calavena",
            codCat: "A540"
        },
        {
            name: "Bardolino",
            codCat: "A650"
        },
        {
            name: "Belfiore",
            codCat: "A737"
        },
        {
            name: "Bevilacqua",
            codCat: "A837"
        },
        {
            name: "Bonavigo",
            codCat: "A964"
        },
        {
            name: "Boschi Sant'Anna",
            codCat: "B070"
        },
        {
            name: "Bosco Chiesanuova",
            codCat: "B073"
        },
        {
            name: "Bovolone",
            codCat: "B107"
        },
        {
            name: "Brentino Belluno",
            codCat: "B152"
        },
        {
            name: "Brenzone sul Garda",
            codCat: "B154"
        },
        {
            name: "Bussolengo",
            codCat: "B296"
        },
        {
            name: "Buttapietra",
            codCat: "B304"
        },
        {
            name: "Caldiero",
            codCat: "B402"
        },
        {
            name: "Caprino Veronese",
            codCat: "B709"
        },
        {
            name: "Casaleone",
            codCat: "B886"
        },
        {
            name: "Castagnaro",
            codCat: "C041"
        },
        {
            name: "Castel d'Azzano",
            codCat: "C078"
        },
        {
            name: "Castelnuovo del Garda",
            codCat: "C225"
        },
        {
            name: "Cavaion Veronese",
            codCat: "C370"
        },
        {
            name: "Cazzano di Tramigna",
            codCat: "C412"
        },
        {
            name: "Cerea",
            codCat: "C498"
        },
        {
            name: "Cerro Veronese",
            codCat: "C538"
        },
        {
            name: "Cologna Veneta",
            codCat: "C890"
        },
        {
            name: "Colognola ai Colli",
            codCat: "C897"
        },
        {
            name: "Concamarise",
            codCat: "C943"
        },
        {
            name: "Costermano sul Garda",
            codCat: "D118"
        },
        {
            name: "Dolcè",
            codCat: "D317"
        },
        {
            name: "Erbè",
            codCat: "D419"
        },
        {
            name: "Erbezzo",
            codCat: "D420"
        },
        {
            name: "Ferrara di Monte Baldo",
            codCat: "D549"
        },
        {
            name: "Fumane",
            codCat: "D818"
        },
        {
            name: "Garda",
            codCat: "D915"
        },
        {
            name: "Gazzo Veronese",
            codCat: "D957"
        },
        {
            name: "Grezzana",
            codCat: "E171"
        },
        {
            name: "Illasi",
            codCat: "E284"
        },
        {
            name: "Isola della Scala",
            codCat: "E349"
        },
        {
            name: "Isola Rizza",
            codCat: "E358"
        },
        {
            name: "Lavagno",
            codCat: "E489"
        },
        {
            name: "Lazise",
            codCat: "E502"
        },
        {
            name: "Legnago",
            codCat: "E512"
        },
        {
            name: "Malcesine",
            codCat: "E848"
        },
        {
            name: "Marano di Valpolicella",
            codCat: "E911"
        },
        {
            name: "Mezzane di Sotto",
            codCat: "F172"
        },
        {
            name: "Minerbe",
            codCat: "F218"
        },
        {
            name: "Montecchia di Crosara",
            codCat: "F461"
        },
        {
            name: "Monteforte d'Alpone",
            codCat: "F508"
        },
        {
            name: "Mozzecane",
            codCat: "F789"
        },
        {
            name: "Negrar di Valpolicella",
            codCat: "F861"
        },
        {
            name: "Nogara",
            codCat: "F918"
        },
        {
            name: "Nogarole Rocca",
            codCat: "F921"
        },
        {
            name: "Oppeano",
            codCat: "G080"
        },
        {
            name: "Palù",
            codCat: "G297"
        },
        {
            name: "Pastrengo",
            codCat: "G365"
        },
        {
            name: "Pescantina",
            codCat: "G481"
        },
        {
            name: "Peschiera del Garda",
            codCat: "G489"
        },
        {
            name: "Povegliano Veronese",
            codCat: "G945"
        },
        {
            name: "Pressana",
            codCat: "H048"
        },
        {
            name: "Rivoli Veronese",
            codCat: "H356"
        },
        {
            name: "Roncà",
            codCat: "H522"
        },
        {
            name: "Ronco all'Adige",
            codCat: "H540"
        },
        {
            name: "Roverchiara",
            codCat: "H606"
        },
        {
            name: "Roveredo di Guà",
            codCat: "H610"
        },
        {
            name: "Roverè Veronese",
            codCat: "H608"
        },
        {
            name: "Salizzole",
            codCat: "H714"
        },
        {
            name: "San Bonifacio",
            codCat: "H783"
        },
        {
            name: "San Giovanni Ilarione",
            codCat: "H916"
        },
        {
            name: "San Giovanni Lupatoto",
            codCat: "H924"
        },
        {
            name: "Sanguinetto",
            codCat: "H944"
        },
        {
            name: "San Martino Buon Albergo",
            codCat: "I003"
        },
        {
            name: "San Mauro di Saline",
            codCat: "H712"
        },
        {
            name: "San Pietro di Morubio",
            codCat: "I105"
        },
        {
            name: "San Pietro in Cariano",
            codCat: "I109"
        },
        {
            name: "Sant'Ambrogio di Valpolicella",
            codCat: "I259"
        },
        {
            name: "Sant'Anna d'Alfaedo",
            codCat: "I292"
        },
        {
            name: "San Zeno di Montagna",
            codCat: "I414"
        },
        {
            name: "Selva di Progno",
            codCat: "I594"
        },
        {
            name: "Soave",
            codCat: "I775"
        },
        {
            name: "Sommacampagna",
            codCat: "I821"
        },
        {
            name: "Sona",
            codCat: "I826"
        },
        {
            name: "Sorgà",
            codCat: "I850"
        },
        {
            name: "Terrazzo",
            codCat: "L136"
        },
        {
            name: "Torri del Benaco",
            codCat: "L287"
        },
        {
            name: "Tregnago",
            codCat: "L364"
        },
        {
            name: "Trevenzuolo",
            codCat: "L396"
        },
        {
            name: "Valeggio sul Mincio",
            codCat: "L567"
        },
        {
            name: "Velo Veronese",
            codCat: "L722"
        },
        {
            name: "Verona",
            codCat: "L781"
        },
        {
            name: "Veronella",
            codCat: "D193"
        },
        {
            name: "Vestenanova",
            codCat: "L810"
        },
        {
            name: "Vigasio",
            codCat: "L869"
        },
        {
            name: "Villa Bartolomea",
            codCat: "L912"
        },
        {
            name: "Villafranca di Verona",
            codCat: "L949"
        },
        {
            name: "Zevio",
            codCat: "M172"
        },
        {
            name: "Zimella",
            codCat: "M178"
        },
        {
            name: "Agugliaro",
            codCat: "A093"
        },
        {
            name: "Albettone",
            codCat: "A154"
        },
        {
            name: "Alonte",
            codCat: "A220"
        },
        {
            name: "Altavilla Vicentina",
            codCat: "A231"
        },
        {
            name: "Altissimo",
            codCat: "A236"
        },
        {
            name: "Arcugnano",
            codCat: "A377"
        },
        {
            name: "Arsiero",
            codCat: "A444"
        },
        {
            name: "Arzignano",
            codCat: "A459"
        },
        {
            name: "Asiago",
            codCat: "A465"
        },
        {
            name: "Asigliano Veneto",
            codCat: "A467"
        },
        {
            name: "Bassano del Grappa",
            codCat: "A703"
        },
        {
            name: "Bolzano Vicentino",
            codCat: "A954"
        },
        {
            name: "Breganze",
            codCat: "B132"
        },
        {
            name: "Brendola",
            codCat: "B143"
        },
        {
            name: "Bressanvido",
            codCat: "B161"
        },
        {
            name: "Brogliano",
            codCat: "B196"
        },
        {
            name: "Caldogno",
            codCat: "B403"
        },
        {
            name: "Caltrano",
            codCat: "B433"
        },
        {
            name: "Calvene",
            codCat: "B441"
        },
        {
            name: "Camisano Vicentino",
            codCat: "B485"
        },
        {
            name: "Campiglia dei Berici",
            codCat: "B511"
        },
        {
            name: "Carrè",
            codCat: "B835"
        },
        {
            name: "Cartigliano",
            codCat: "B844"
        },
        {
            name: "Cassola",
            codCat: "C037"
        },
        {
            name: "Castegnero",
            codCat: "C056"
        },
        {
            name: "Castelgomberto",
            codCat: "C119"
        },
        {
            name: "Chiampo",
            codCat: "C605"
        },
        {
            name: "Chiuppano",
            codCat: "C650"
        },
        {
            name: "Cogollo del Cengio",
            codCat: "C824"
        },
        {
            name: "Cornedo Vicentino",
            codCat: "D020"
        },
        {
            name: "Costabissara",
            codCat: "D107"
        },
        {
            name: "Creazzo",
            codCat: "D136"
        },
        {
            name: "Crespadoro",
            codCat: "D156"
        },
        {
            name: "Dueville",
            codCat: "D379"
        },
        {
            name: "Enego",
            codCat: "D407"
        },
        {
            name: "Fara Vicentino",
            codCat: "D496"
        },
        {
            name: "Foza",
            codCat: "D750"
        },
        {
            name: "Gallio",
            codCat: "D882"
        },
        {
            name: "Gambellara",
            codCat: "D897"
        },
        {
            name: "Gambugliano",
            codCat: "D902"
        },
        {
            name: "Grisignano di Zocco",
            codCat: "E184"
        },
        {
            name: "Grumolo delle Abbadesse",
            codCat: "E226"
        },
        {
            name: "Isola Vicentina",
            codCat: "E354"
        },
        {
            name: "Laghi",
            codCat: "E403"
        },
        {
            name: "Lastebasse",
            codCat: "E465"
        },
        {
            name: "Longare",
            codCat: "E671"
        },
        {
            name: "Lonigo",
            codCat: "E682"
        },
        {
            name: "Lugo di Vicenza",
            codCat: "E731"
        },
        {
            name: "Malo",
            codCat: "E864"
        },
        {
            name: "Marano Vicentino",
            codCat: "E912"
        },
        {
            name: "Marostica",
            codCat: "E970"
        },
        {
            name: "Montebello Vicentino",
            codCat: "F442"
        },
        {
            name: "Montecchio Maggiore",
            codCat: "F464"
        },
        {
            name: "Montecchio Precalcino",
            codCat: "F465"
        },
        {
            name: "Monte di Malo",
            codCat: "F486"
        },
        {
            name: "Montegalda",
            codCat: "F514"
        },
        {
            name: "Montegaldella",
            codCat: "F515"
        },
        {
            name: "Monteviale",
            codCat: "F662"
        },
        {
            name: "Monticello Conte Otto",
            codCat: "F675"
        },
        {
            name: "Montorso Vicentino",
            codCat: "F696"
        },
        {
            name: "Mussolente",
            codCat: "F829"
        },
        {
            name: "Nanto",
            codCat: "F838"
        },
        {
            name: "Nogarole Vicentino",
            codCat: "F922"
        },
        {
            name: "Nove",
            codCat: "F957"
        },
        {
            name: "Noventa Vicentina",
            codCat: "F964"
        },
        {
            name: "Orgiano",
            codCat: "G095"
        },
        {
            name: "Pedemonte",
            codCat: "G406"
        },
        {
            name: "Pianezze",
            codCat: "G560"
        },
        {
            name: "Piovene Rocchette",
            codCat: "G694"
        },
        {
            name: "Pojana Maggiore",
            codCat: "G776"
        },
        {
            name: "Posina",
            codCat: "G931"
        },
        {
            name: "Pove del Grappa",
            codCat: "G943"
        },
        {
            name: "Pozzoleone",
            codCat: "G957"
        },
        {
            name: "Quinto Vicentino",
            codCat: "H134"
        },
        {
            name: "Recoaro Terme",
            codCat: "H214"
        },
        {
            name: "Roana",
            codCat: "H361"
        },
        {
            name: "Romano d'Ezzelino",
            codCat: "H512"
        },
        {
            name: "Rosà",
            codCat: "H556"
        },
        {
            name: "Rossano Veneto",
            codCat: "H580"
        },
        {
            name: "Rotzo",
            codCat: "H594"
        },
        {
            name: "Salcedo",
            codCat: "F810"
        },
        {
            name: "Sandrigo",
            codCat: "H829"
        },
        {
            name: "San Pietro Mussolino",
            codCat: "I117"
        },
        {
            name: "Santorso",
            codCat: "I353"
        },
        {
            name: "San Vito di Leguzzano",
            codCat: "I401"
        },
        {
            name: "Sarcedo",
            codCat: "I425"
        },
        {
            name: "Sarego",
            codCat: "I430"
        },
        {
            name: "Schiavon",
            codCat: "I527"
        },
        {
            name: "Schio",
            codCat: "I531"
        },
        {
            name: "Solagna",
            codCat: "I783"
        },
        {
            name: "Sossano",
            codCat: "I867"
        },
        {
            name: "Sovizzo",
            codCat: "I879"
        },
        {
            name: "Tezze sul Brenta",
            codCat: "L156"
        },
        {
            name: "Thiene",
            codCat: "L157"
        },
        {
            name: "Tonezza del Cimone",
            codCat: "D717"
        },
        {
            name: "Torrebelvicino",
            codCat: "L248"
        },
        {
            name: "Torri di Quartesolo",
            codCat: "L297"
        },
        {
            name: "Trissino",
            codCat: "L433"
        },
        {
            name: "Valdagno",
            codCat: "L551"
        },
        {
            name: "Valdastico",
            codCat: "L554"
        },
        {
            name: "Valli del Pasubio",
            codCat: "L624"
        },
        {
            name: "Velo d'Astico",
            codCat: "L723"
        },
        {
            name: "Vicenza",
            codCat: "L840"
        },
        {
            name: "Villaga",
            codCat: "L952"
        },
        {
            name: "Villaverla",
            codCat: "M032"
        },
        {
            name: "Zanè",
            codCat: "M145"
        },
        {
            name: "Zermeghedo",
            codCat: "M170"
        },
        {
            name: "Zovencedo",
            codCat: "M194"
        },
        {
            name: "Zugliano",
            codCat: "M199"
        },
        {
            name: "Val Liona",
            codCat: "M384"
        },
        {
            name: "Barbarano Mossano",
            codCat: "M401"
        },
        {
            name: "Valbrenta",
            codCat: "M423"
        },
        {
            name: "Colceresa",
            codCat: "M426"
        },
        {
            name: "Lusiana Conco",
            codCat: "M427"
        },
        {
            name: "Agordo",
            codCat: "A083"
        },
        {
            name: "Alano di Piave",
            codCat: "A121"
        },
        {
            name: "Alleghe",
            codCat: "A206"
        },
        {
            name: "Arsiè",
            codCat: "A443"
        },
        {
            name: "Auronzo di Cadore",
            codCat: "A501"
        },
        {
            name: "Belluno",
            codCat: "A757"
        },
        {
            name: "Borca di Cadore",
            codCat: "A982"
        },
        {
            name: "Calalzo di Cadore",
            codCat: "B375"
        },
        {
            name: "Cencenighe Agordino",
            codCat: "C458"
        },
        {
            name: "Cesiomaggiore",
            codCat: "C577"
        },
        {
            name: "Chies d'Alpago",
            codCat: "C630"
        },
        {
            name: "Cibiana di Cadore",
            codCat: "C672"
        },
        {
            name: "Colle Santa Lucia",
            codCat: "C872"
        },
        {
            name: "Comelico Superiore",
            codCat: "C920"
        },
        {
            name: "Cortina d'Ampezzo",
            codCat: "A266"
        },
        {
            name: "Danta di Cadore",
            codCat: "D247"
        },
        {
            name: "Domegge di Cadore",
            codCat: "D330"
        },
        {
            name: "Falcade",
            codCat: "D470"
        },
        {
            name: "Feltre",
            codCat: "D530"
        },
        {
            name: "Fonzaso",
            codCat: "D686"
        },
        {
            name: "Canale d'Agordo",
            codCat: "B574"
        },
        {
            name: "Gosaldo",
            codCat: "E113"
        },
        {
            name: "Lamon",
            codCat: "E429"
        },
        {
            name: "La Valle Agordina",
            codCat: "E490"
        },
        {
            name: "Limana",
            codCat: "E588"
        },
        {
            name: "Livinallongo del Col di Lana",
            codCat: "E622"
        },
        {
            name: "Lorenzago di Cadore",
            codCat: "E687"
        },
        {
            name: "Lozzo di Cadore",
            codCat: "E708"
        },
        {
            name: "Ospitale di Cadore",
            codCat: "G169"
        },
        {
            name: "Pedavena",
            codCat: "G404"
        },
        {
            name: "Perarolo di Cadore",
            codCat: "G442"
        },
        {
            name: "Pieve di Cadore",
            codCat: "G642"
        },
        {
            name: "Ponte nelle Alpi",
            codCat: "B662"
        },
        {
            name: "Rivamonte Agordino",
            codCat: "H327"
        },
        {
            name: "Rocca Pietore",
            codCat: "H379"
        },
        {
            name: "San Gregorio nelle Alpi",
            codCat: "H938"
        },
        {
            name: "San Nicolò di Comelico",
            codCat: "I063"
        },
        {
            name: "San Pietro di Cadore",
            codCat: "I088"
        },
        {
            name: "Santa Giustina",
            codCat: "I206"
        },
        {
            name: "San Tomaso Agordino",
            codCat: "I347"
        },
        {
            name: "Santo Stefano di Cadore",
            codCat: "C919"
        },
        {
            name: "San Vito di Cadore",
            codCat: "I392"
        },
        {
            name: "Sedico",
            codCat: "I563"
        },
        {
            name: "Selva di Cadore",
            codCat: "I592"
        },
        {
            name: "Seren del Grappa",
            codCat: "I626"
        },
        {
            name: "Sospirolo",
            codCat: "I866"
        },
        {
            name: "Soverzene",
            codCat: "I876"
        },
        {
            name: "Sovramonte",
            codCat: "I673"
        },
        {
            name: "Taibon Agordino",
            codCat: "L030"
        },
        {
            name: "Tambre",
            codCat: "L040"
        },
        {
            name: "Vallada Agordina",
            codCat: "L584"
        },
        {
            name: "Valle di Cadore",
            codCat: "L590"
        },
        {
            name: "Vigo di Cadore",
            codCat: "L890"
        },
        {
            name: "Vodo Cadore",
            codCat: "M108"
        },
        {
            name: "Voltago Agordino",
            codCat: "M124"
        },
        {
            name: "Zoppè di Cadore",
            codCat: "M189"
        },
        {
            name: "Quero Vas",
            codCat: "M332"
        },
        {
            name: "Longarone",
            codCat: "M342"
        },
        {
            name: "Alpago",
            codCat: "M375"
        },
        {
            name: "Val di Zoldo",
            codCat: "M374"
        },
        {
            name: "Borgo Valbelluna",
            codCat: "M421"
        },
        {
            name: "Altivole",
            codCat: "A237"
        },
        {
            name: "Arcade",
            codCat: "A360"
        },
        {
            name: "Asolo",
            codCat: "A471"
        },
        {
            name: "Borso del Grappa",
            codCat: "B061"
        },
        {
            name: "Breda di Piave",
            codCat: "B128"
        },
        {
            name: "Caerano di San Marco",
            codCat: "B349"
        },
        {
            name: "Cappella Maggiore",
            codCat: "B678"
        },
        {
            name: "Carbonera",
            codCat: "B744"
        },
        {
            name: "Casale sul Sile",
            codCat: "B879"
        },
        {
            name: "Casier",
            codCat: "B965"
        },
        {
            name: "Castelcucco",
            codCat: "C073"
        },
        {
            name: "Castelfranco Veneto",
            codCat: "C111"
        },
        {
            name: "Castello di Godego",
            codCat: "C190"
        },
        {
            name: "Cavaso del Tomba",
            codCat: "C384"
        },
        {
            name: "Cessalto",
            codCat: "C580"
        },
        {
            name: "Chiarano",
            codCat: "C614"
        },
        {
            name: "Cimadolmo",
            codCat: "C689"
        },
        {
            name: "Cison di Valmarino",
            codCat: "C735"
        },
        {
            name: "Codognè",
            codCat: "C815"
        },
        {
            name: "Colle Umberto",
            codCat: "C848"
        },
        {
            name: "Conegliano",
            codCat: "C957"
        },
        {
            name: "Cordignano",
            codCat: "C992"
        },
        {
            name: "Cornuda",
            codCat: "D030"
        },
        {
            name: "Crocetta del Montello",
            codCat: "C670"
        },
        {
            name: "Farra di Soligo",
            codCat: "D505"
        },
        {
            name: "Follina",
            codCat: "D654"
        },
        {
            name: "Fontanelle",
            codCat: "D674"
        },
        {
            name: "Fonte",
            codCat: "D680"
        },
        {
            name: "Fregona",
            codCat: "D794"
        },
        {
            name: "Gaiarine",
            codCat: "D854"
        },
        {
            name: "Giavera del Montello",
            codCat: "E021"
        },
        {
            name: "Godega di Sant'Urbano",
            codCat: "E071"
        },
        {
            name: "Gorgo al Monticano",
            codCat: "E092"
        },
        {
            name: "Istrana",
            codCat: "E373"
        },
        {
            name: "Loria",
            codCat: "E692"
        },
        {
            name: "Mansuè",
            codCat: "E893"
        },
        {
            name: "Mareno di Piave",
            codCat: "E940"
        },
        {
            name: "Maser",
            codCat: "F009"
        },
        {
            name: "Maserada sul Piave",
            codCat: "F012"
        },
        {
            name: "Meduna di Livenza",
            codCat: "F088"
        },
        {
            name: "Miane",
            codCat: "F190"
        },
        {
            name: "Mogliano Veneto",
            codCat: "F269"
        },
        {
            name: "Monastier di Treviso",
            codCat: "F332"
        },
        {
            name: "Monfumo",
            codCat: "F360"
        },
        {
            name: "Montebelluna",
            codCat: "F443"
        },
        {
            name: "Morgano",
            codCat: "F725"
        },
        {
            name: "Moriago della Battaglia",
            codCat: "F729"
        },
        {
            name: "Motta di Livenza",
            codCat: "F770"
        },
        {
            name: "Nervesa della Battaglia",
            codCat: "F872"
        },
        {
            name: "Oderzo",
            codCat: "F999"
        },
        {
            name: "Ormelle",
            codCat: "G115"
        },
        {
            name: "Orsago",
            codCat: "G123"
        },
        {
            name: "Paese",
            codCat: "G229"
        },
        {
            name: "Pederobba",
            codCat: "G408"
        },
        {
            name: "Pieve di Soligo",
            codCat: "G645"
        },
        {
            name: "Ponte di Piave",
            codCat: "G846"
        },
        {
            name: "Ponzano Veneto",
            codCat: "G875"
        },
        {
            name: "Portobuffolè",
            codCat: "G909"
        },
        {
            name: "Possagno",
            codCat: "G933"
        },
        {
            name: "Povegliano",
            codCat: "G944"
        },
        {
            name: "Preganziol",
            codCat: "H022"
        },
        {
            name: "Quinto di Treviso",
            codCat: "H131"
        },
        {
            name: "Refrontolo",
            codCat: "H220"
        },
        {
            name: "Resana",
            codCat: "H238"
        },
        {
            name: "Revine Lago",
            codCat: "H253"
        },
        {
            name: "Riese Pio X",
            codCat: "H280"
        },
        {
            name: "Roncade",
            codCat: "H523"
        },
        {
            name: "Salgareda",
            codCat: "H706"
        },
        {
            name: "San Biagio di Callalta",
            codCat: "H781"
        },
        {
            name: "San Fior",
            codCat: "H843"
        },
        {
            name: "San Pietro di Feletto",
            codCat: "I103"
        },
        {
            name: "San Polo di Piave",
            codCat: "I124"
        },
        {
            name: "Santa Lucia di Piave",
            codCat: "I221"
        },
        {
            name: "San Vendemiano",
            codCat: "I382"
        },
        {
            name: "San Zenone degli Ezzelini",
            codCat: "I417"
        },
        {
            name: "Sarmede",
            codCat: "I435"
        },
        {
            name: "Segusino",
            codCat: "I578"
        },
        {
            name: "Sernaglia della Battaglia",
            codCat: "I635"
        },
        {
            name: "Silea",
            codCat: "F116"
        },
        {
            name: "Spresiano",
            codCat: "I927"
        },
        {
            name: "Susegana",
            codCat: "L014"
        },
        {
            name: "Tarzo",
            codCat: "L058"
        },
        {
            name: "Trevignano",
            codCat: "L402"
        },
        {
            name: "Treviso",
            codCat: "L407"
        },
        {
            name: "Valdobbiadene",
            codCat: "L565"
        },
        {
            name: "Vazzola",
            codCat: "L700"
        },
        {
            name: "Vedelago",
            codCat: "L706"
        },
        {
            name: "Vidor",
            codCat: "L856"
        },
        {
            name: "Villorba",
            codCat: "M048"
        },
        {
            name: "Vittorio Veneto",
            codCat: "M089"
        },
        {
            name: "Volpago del Montello",
            codCat: "M118"
        },
        {
            name: "Zenson di Piave",
            codCat: "M163"
        },
        {
            name: "Zero Branco",
            codCat: "M171"
        },
        {
            name: "Pieve del Grappa",
            codCat: "M422"
        },
        {
            name: "Annone Veneto",
            codCat: "A302"
        },
        {
            name: "Campagna Lupia",
            codCat: "B493"
        },
        {
            name: "Campolongo Maggiore",
            codCat: "B546"
        },
        {
            name: "Camponogara",
            codCat: "B554"
        },
        {
            name: "Caorle",
            codCat: "B642"
        },
        {
            name: "Cavarzere",
            codCat: "C383"
        },
        {
            name: "Ceggia",
            codCat: "C422"
        },
        {
            name: "Chioggia",
            codCat: "C638"
        },
        {
            name: "Cinto Caomaggiore",
            codCat: "C714"
        },
        {
            name: "Cona",
            codCat: "C938"
        },
        {
            name: "Concordia Sagittaria",
            codCat: "C950"
        },
        {
            name: "Dolo",
            codCat: "D325"
        },
        {
            name: "Eraclea",
            codCat: "D415"
        },
        {
            name: "Fiesso d'Artico",
            codCat: "D578"
        },
        {
            name: "Fossalta di Piave",
            codCat: "D740"
        },
        {
            name: "Fossalta di Portogruaro",
            codCat: "D741"
        },
        {
            name: "Fossò",
            codCat: "D748"
        },
        {
            name: "Gruaro",
            codCat: "E215"
        },
        {
            name: "Jesolo",
            codCat: "C388"
        },
        {
            name: "Marcon",
            codCat: "E936"
        },
        {
            name: "Martellago",
            codCat: "E980"
        },
        {
            name: "Meolo",
            codCat: "F130"
        },
        {
            name: "Mira",
            codCat: "F229"
        },
        {
            name: "Mirano",
            codCat: "F241"
        },
        {
            name: "Musile di Piave",
            codCat: "F826"
        },
        {
            name: "Noale",
            codCat: "F904"
        },
        {
            name: "Noventa di Piave",
            codCat: "F963"
        },
        {
            name: "Pianiga",
            codCat: "G565"
        },
        {
            name: "Portogruaro",
            codCat: "G914"
        },
        {
            name: "Pramaggiore",
            codCat: "G981"
        },
        {
            name: "Quarto d'Altino",
            codCat: "H117"
        },
        {
            name: "Salzano",
            codCat: "H735"
        },
        {
            name: "San Donà di Piave",
            codCat: "H823"
        },
        {
            name: "San Michele al Tagliamento",
            codCat: "I040"
        },
        {
            name: "Santa Maria di Sala",
            codCat: "I242"
        },
        {
            name: "San Stino di Livenza",
            codCat: "I373"
        },
        {
            name: "Scorzè",
            codCat: "I551"
        },
        {
            name: "Spinea",
            codCat: "I908"
        },
        {
            name: "Stra",
            codCat: "I965"
        },
        {
            name: "Teglio Veneto",
            codCat: "L085"
        },
        {
            name: "Torre di Mosto",
            codCat: "L267"
        },
        {
            name: "Venezia",
            codCat: "L736"
        },
        {
            name: "Vigonovo",
            codCat: "L899"
        },
        {
            name: "Cavallino-Treporti",
            codCat: "M308"
        },
        {
            name: "Abano Terme",
            codCat: "A001"
        },
        {
            name: "Agna",
            codCat: "A075"
        },
        {
            name: "Albignasego",
            codCat: "A161"
        },
        {
            name: "Anguillara Veneta",
            codCat: "A296"
        },
        {
            name: "Arquà Petrarca",
            codCat: "A434"
        },
        {
            name: "Arre",
            codCat: "A438"
        },
        {
            name: "Arzergrande",
            codCat: "A458"
        },
        {
            name: "Bagnoli di Sopra",
            codCat: "A568"
        },
        {
            name: "Baone",
            codCat: "A613"
        },
        {
            name: "Barbona",
            codCat: "A637"
        },
        {
            name: "Battaglia Terme",
            codCat: "A714"
        },
        {
            name: "Boara Pisani",
            codCat: "A906"
        },
        {
            name: "Borgoricco",
            codCat: "B031"
        },
        {
            name: "Bovolenta",
            codCat: "B106"
        },
        {
            name: "Brugine",
            codCat: "B213"
        },
        {
            name: "Cadoneghe",
            codCat: "B345"
        },
        {
            name: "Campodarsego",
            codCat: "B524"
        },
        {
            name: "Campodoro",
            codCat: "B531"
        },
        {
            name: "Camposampiero",
            codCat: "B563"
        },
        {
            name: "Campo San Martino",
            codCat: "B564"
        },
        {
            name: "Candiana",
            codCat: "B589"
        },
        {
            name: "Carceri",
            codCat: "B749"
        },
        {
            name: "Carmignano di Brenta",
            codCat: "B795"
        },
        {
            name: "Cartura",
            codCat: "B848"
        },
        {
            name: "Casale di Scodosia",
            codCat: "B877"
        },
        {
            name: "Casalserugo",
            codCat: "B912"
        },
        {
            name: "Castelbaldo",
            codCat: "C057"
        },
        {
            name: "Cervarese Santa Croce",
            codCat: "C544"
        },
        {
            name: "Cinto Euganeo",
            codCat: "C713"
        },
        {
            name: "Cittadella",
            codCat: "C743"
        },
        {
            name: "Codevigo",
            codCat: "C812"
        },
        {
            name: "Conselve",
            codCat: "C964"
        },
        {
            name: "Correzzola",
            codCat: "D040"
        },
        {
            name: "Curtarolo",
            codCat: "D226"
        },
        {
            name: "Este",
            codCat: "D442"
        },
        {
            name: "Fontaniva",
            codCat: "D679"
        },
        {
            name: "Galliera Veneta",
            codCat: "D879"
        },
        {
            name: "Galzignano Terme",
            codCat: "D889"
        },
        {
            name: "Gazzo",
            codCat: "D956"
        },
        {
            name: "Grantorto",
            codCat: "E145"
        },
        {
            name: "Granze",
            codCat: "E146"
        },
        {
            name: "Legnaro",
            codCat: "E515"
        },
        {
            name: "Limena",
            codCat: "E592"
        },
        {
            name: "Loreggia",
            codCat: "E684"
        },
        {
            name: "Lozzo Atestino",
            codCat: "E709"
        },
        {
            name: "Maserà di Padova",
            codCat: "F011"
        },
        {
            name: "Masi",
            codCat: "F013"
        },
        {
            name: "Massanzago",
            codCat: "F033"
        },
        {
            name: "Megliadino San Vitale",
            codCat: "F092"
        },
        {
            name: "Merlara",
            codCat: "F148"
        },
        {
            name: "Mestrino",
            codCat: "F161"
        },
        {
            name: "Monselice",
            codCat: "F382"
        },
        {
            name: "Montagnana",
            codCat: "F394"
        },
        {
            name: "Montegrotto Terme",
            codCat: "F529"
        },
        {
            name: "Noventa Padovana",
            codCat: "F962"
        },
        {
            name: "Ospedaletto Euganeo",
            codCat: "G167"
        },
        {
            name: "Padova",
            codCat: "G224"
        },
        {
            name: "Pernumia",
            codCat: "G461"
        },
        {
            name: "Piacenza d'Adige",
            codCat: "G534"
        },
        {
            name: "Piazzola sul Brenta",
            codCat: "G587"
        },
        {
            name: "Piombino Dese",
            codCat: "G688"
        },
        {
            name: "Piove di Sacco",
            codCat: "G693"
        },
        {
            name: "Polverara",
            codCat: "G802"
        },
        {
            name: "Ponso",
            codCat: "G823"
        },
        {
            name: "Pontelongo",
            codCat: "G850"
        },
        {
            name: "Ponte San Nicolò",
            codCat: "G855"
        },
        {
            name: "Pozzonovo",
            codCat: "G963"
        },
        {
            name: "Rovolon",
            codCat: "H622"
        },
        {
            name: "Rubano",
            codCat: "H625"
        },
        {
            name: "Saccolongo",
            codCat: "H655"
        },
        {
            name: "San Giorgio delle Pertiche",
            codCat: "H893"
        },
        {
            name: "San Giorgio in Bosco",
            codCat: "H897"
        },
        {
            name: "San Martino di Lupari",
            codCat: "I008"
        },
        {
            name: "San Pietro in Gu",
            codCat: "I107"
        },
        {
            name: "San Pietro Viminario",
            codCat: "I120"
        },
        {
            name: "Santa Giustina in Colle",
            codCat: "I207"
        },
        {
            name: "Sant'Angelo di Piove di Sacco",
            codCat: "I275"
        },
        {
            name: "Sant'Elena",
            codCat: "I319"
        },
        {
            name: "Sant'Urbano",
            codCat: "I375"
        },
        {
            name: "Saonara",
            codCat: "I418"
        },
        {
            name: "Selvazzano Dentro",
            codCat: "I595"
        },
        {
            name: "Solesino",
            codCat: "I799"
        },
        {
            name: "Stanghella",
            codCat: "I938"
        },
        {
            name: "Teolo",
            codCat: "L100"
        },
        {
            name: "Terrassa Padovana",
            codCat: "L132"
        },
        {
            name: "Tombolo",
            codCat: "L199"
        },
        {
            name: "Torreglia",
            codCat: "L270"
        },
        {
            name: "Trebaseleghe",
            codCat: "L349"
        },
        {
            name: "Tribano",
            codCat: "L414"
        },
        {
            name: "Urbana",
            codCat: "L497"
        },
        {
            name: "Veggiano",
            codCat: "L710"
        },
        {
            name: "Vescovana",
            codCat: "L805"
        },
        {
            name: "Vighizzolo d'Este",
            codCat: "L878"
        },
        {
            name: "Vigodarzere",
            codCat: "L892"
        },
        {
            name: "Vigonza",
            codCat: "L900"
        },
        {
            name: "Villa del Conte",
            codCat: "L934"
        },
        {
            name: "Villa Estense",
            codCat: "L937"
        },
        {
            name: "Villafranca Padovana",
            codCat: "L947"
        },
        {
            name: "Villanova di Camposampiero",
            codCat: "L979"
        },
        {
            name: "Vo'",
            codCat: "M103"
        },
        {
            name: "Due Carrare",
            codCat: "M300"
        },
        {
            name: "Borgo Veneto",
            codCat: "M402"
        },
        {
            name: "Adria",
            codCat: "A059"
        },
        {
            name: "Ariano nel Polesine",
            codCat: "A400"
        },
        {
            name: "Arquà Polesine",
            codCat: "A435"
        },
        {
            name: "Badia Polesine",
            codCat: "A539"
        },
        {
            name: "Bagnolo di Po",
            codCat: "A574"
        },
        {
            name: "Bergantino",
            codCat: "A795"
        },
        {
            name: "Bosaro",
            codCat: "B069"
        },
        {
            name: "Calto",
            codCat: "B432"
        },
        {
            name: "Canaro",
            codCat: "B578"
        },
        {
            name: "Canda",
            codCat: "B582"
        },
        {
            name: "Castelguglielmo",
            codCat: "C122"
        },
        {
            name: "Castelmassa",
            codCat: "C207"
        },
        {
            name: "Castelnovo Bariano",
            codCat: "C215"
        },
        {
            name: "Ceneselli",
            codCat: "C461"
        },
        {
            name: "Ceregnano",
            codCat: "C500"
        },
        {
            name: "Corbola",
            codCat: "C987"
        },
        {
            name: "Costa di Rovigo",
            codCat: "D105"
        },
        {
            name: "Crespino",
            codCat: "D161"
        },
        {
            name: "Ficarolo",
            codCat: "D568"
        },
        {
            name: "Fiesso Umbertiano",
            codCat: "D577"
        },
        {
            name: "Frassinelle Polesine",
            codCat: "D776"
        },
        {
            name: "Fratta Polesine",
            codCat: "D788"
        },
        {
            name: "Gaiba",
            codCat: "D855"
        },
        {
            name: "Gavello",
            codCat: "D942"
        },
        {
            name: "Giacciano con Baruchella",
            codCat: "E008"
        },
        {
            name: "Guarda Veneta",
            codCat: "E240"
        },
        {
            name: "Lendinara",
            codCat: "E522"
        },
        {
            name: "Loreo",
            codCat: "E689"
        },
        {
            name: "Lusia",
            codCat: "E761"
        },
        {
            name: "Melara",
            codCat: "F095"
        },
        {
            name: "Occhiobello",
            codCat: "F994"
        },
        {
            name: "Papozze",
            codCat: "G323"
        },
        {
            name: "Pettorazza Grimani",
            codCat: "G525"
        },
        {
            name: "Pincara",
            codCat: "G673"
        },
        {
            name: "Polesella",
            codCat: "G782"
        },
        {
            name: "Pontecchio Polesine",
            codCat: "G836"
        },
        {
            name: "Porto Tolle",
            codCat: "G923"
        },
        {
            name: "Rosolina",
            codCat: "H573"
        },
        {
            name: "Rovigo",
            codCat: "H620"
        },
        {
            name: "Salara",
            codCat: "H689"
        },
        {
            name: "San Bellino",
            codCat: "H768"
        },
        {
            name: "San Martino di Venezze",
            codCat: "H996"
        },
        {
            name: "Stienta",
            codCat: "I953"
        },
        {
            name: "Taglio di Po",
            codCat: "L026"
        },
        {
            name: "Trecenta",
            codCat: "L359"
        },
        {
            name: "Villadose",
            codCat: "L939"
        },
        {
            name: "Villamarzana",
            codCat: "L967"
        },
        {
            name: "Villanova del Ghebbo",
            codCat: "L985"
        },
        {
            name: "Villanova Marchesana",
            codCat: "L988"
        },
        {
            name: "Porto Viro",
            codCat: "G926"
        },
        {
            name: "Aiello del Friuli",
            codCat: "A103"
        },
        {
            name: "Amaro",
            codCat: "A254"
        },
        {
            name: "Ampezzo",
            codCat: "A267"
        },
        {
            name: "Aquileia",
            codCat: "A346"
        },
        {
            name: "Arta Terme",
            codCat: "A447"
        },
        {
            name: "Artegna",
            codCat: "A448"
        },
        {
            name: "Attimis",
            codCat: "A491"
        },
        {
            name: "Bagnaria Arsa",
            codCat: "A553"
        },
        {
            name: "Basiliano",
            codCat: "A700"
        },
        {
            name: "Bertiolo",
            codCat: "A810"
        },
        {
            name: "Bicinicco",
            codCat: "A855"
        },
        {
            name: "Bordano",
            codCat: "A983"
        },
        {
            name: "Buja",
            codCat: "B259"
        },
        {
            name: "Buttrio",
            codCat: "B309"
        },
        {
            name: "Camino al Tagliamento",
            codCat: "B483"
        },
        {
            name: "Campoformido",
            codCat: "B536"
        },
        {
            name: "Carlino",
            codCat: "B788"
        },
        {
            name: "Cassacco",
            codCat: "B994"
        },
        {
            name: "Castions di Strada",
            codCat: "C327"
        },
        {
            name: "Cavazzo Carnico",
            codCat: "C389"
        },
        {
            name: "Cercivento",
            codCat: "C494"
        },
        {
            name: "Cervignano del Friuli",
            codCat: "C556"
        },
        {
            name: "Chiopris-Viscone",
            codCat: "C641"
        },
        {
            name: "Chiusaforte",
            codCat: "C656"
        },
        {
            name: "Cividale del Friuli",
            codCat: "C758"
        },
        {
            name: "Codroipo",
            codCat: "C817"
        },
        {
            name: "Colloredo di Monte Albano",
            codCat: "C885"
        },
        {
            name: "Comeglians",
            codCat: "C918"
        },
        {
            name: "Corno di Rosazzo",
            codCat: "D027"
        },
        {
            name: "Coseano",
            codCat: "D085"
        },
        {
            name: "Dignano",
            codCat: "D300"
        },
        {
            name: "Dogna",
            codCat: "D316"
        },
        {
            name: "Drenchia",
            codCat: "D366"
        },
        {
            name: "Enemonzo",
            codCat: "D408"
        },
        {
            name: "Faedis",
            codCat: "D455"
        },
        {
            name: "Fagagna",
            codCat: "D461"
        },
        {
            name: "Flaibano",
            codCat: "D630"
        },
        {
            name: "Forni Avoltri",
            codCat: "D718"
        },
        {
            name: "Forni di Sopra",
            codCat: "D719"
        },
        {
            name: "Forni di Sotto",
            codCat: "D720"
        },
        {
            name: "Gemona del Friuli",
            codCat: "D962"
        },
        {
            name: "Gonars",
            codCat: "E083"
        },
        {
            name: "Grimacco",
            codCat: "E179"
        },
        {
            name: "Latisana",
            codCat: "E473"
        },
        {
            name: "Lauco",
            codCat: "E476"
        },
        {
            name: "Lestizza",
            codCat: "E553"
        },
        {
            name: "Lignano Sabbiadoro",
            codCat: "E584"
        },
        {
            name: "Lusevera",
            codCat: "E760"
        },
        {
            name: "Magnano in Riviera",
            codCat: "E820"
        },
        {
            name: "Majano",
            codCat: "E833"
        },
        {
            name: "Malborghetto Valbruna",
            codCat: "E847"
        },
        {
            name: "Manzano",
            codCat: "E899"
        },
        {
            name: "Marano Lagunare",
            codCat: "E910"
        },
        {
            name: "Martignacco",
            codCat: "E982"
        },
        {
            name: "Mereto di Tomba",
            codCat: "F144"
        },
        {
            name: "Moggio Udinese",
            codCat: "F266"
        },
        {
            name: "Moimacco",
            codCat: "F275"
        },
        {
            name: "Montenars",
            codCat: "F574"
        },
        {
            name: "Mortegliano",
            codCat: "F756"
        },
        {
            name: "Moruzzo",
            codCat: "F760"
        },
        {
            name: "Muzzana del Turgnano",
            codCat: "F832"
        },
        {
            name: "Nimis",
            codCat: "F898"
        },
        {
            name: "Osoppo",
            codCat: "G163"
        },
        {
            name: "Ovaro",
            codCat: "G198"
        },
        {
            name: "Pagnacco",
            codCat: "G238"
        },
        {
            name: "Palazzolo dello Stella",
            codCat: "G268"
        },
        {
            name: "Palmanova",
            codCat: "G284"
        },
        {
            name: "Paluzza",
            codCat: "G300"
        },
        {
            name: "Pasian di Prato",
            codCat: "G352"
        },
        {
            name: "Paularo",
            codCat: "G381"
        },
        {
            name: "Pavia di Udine",
            codCat: "G389"
        },
        {
            name: "Pocenia",
            codCat: "G743"
        },
        {
            name: "Pontebba",
            codCat: "G831"
        },
        {
            name: "Porpetto",
            codCat: "G891"
        },
        {
            name: "Povoletto",
            codCat: "G949"
        },
        {
            name: "Pozzuolo del Friuli",
            codCat: "G966"
        },
        {
            name: "Pradamano",
            codCat: "G969"
        },
        {
            name: "Prato Carnico",
            codCat: "H002"
        },
        {
            name: "Precenicco",
            codCat: "H014"
        },
        {
            name: "Premariacco",
            codCat: "H029"
        },
        {
            name: "Preone",
            codCat: "H038"
        },
        {
            name: "Prepotto",
            codCat: "H040"
        },
        {
            name: "Pulfero",
            codCat: "H089"
        },
        {
            name: "Ragogna",
            codCat: "H161"
        },
        {
            name: "Ravascletto",
            codCat: "H196"
        },
        {
            name: "Raveo",
            codCat: "H200"
        },
        {
            name: "Reana del Rojale",
            codCat: "H206"
        },
        {
            name: "Remanzacco",
            codCat: "H229"
        },
        {
            name: "Resia",
            codCat: "H242"
        },
        {
            name: "Resiutta",
            codCat: "H244"
        },
        {
            name: "Rigolato",
            codCat: "H289"
        },
        {
            name: "Rive d'Arcano",
            codCat: "H347"
        },
        {
            name: "Ronchis",
            codCat: "H533"
        },
        {
            name: "Ruda",
            codCat: "H629"
        },
        {
            name: "San Daniele del Friuli",
            codCat: "H816"
        },
        {
            name: "San Giorgio di Nogaro",
            codCat: "H895"
        },
        {
            name: "San Giovanni al Natisone",
            codCat: "H906"
        },
        {
            name: "San Leonardo",
            codCat: "H951"
        },
        {
            name: "San Pietro al Natisone",
            codCat: "I092"
        },
        {
            name: "Santa Maria la Longa",
            codCat: "I248"
        },
        {
            name: "San Vito al Torre",
            codCat: "I404"
        },
        {
            name: "San Vito di Fagagna",
            codCat: "I405"
        },
        {
            name: "Sauris",
            codCat: "I464"
        },
        {
            name: "Savogna",
            codCat: "I478"
        },
        {
            name: "Sedegliano",
            codCat: "I562"
        },
        {
            name: "Socchieve",
            codCat: "I777"
        },
        {
            name: "Stregna",
            codCat: "I974"
        },
        {
            name: "Sutrio",
            codCat: "L018"
        },
        {
            name: "Taipana",
            codCat: "G736"
        },
        {
            name: "Talmassons",
            codCat: "L039"
        },
        {
            name: "Tarcento",
            codCat: "L050"
        },
        {
            name: "Tarvisio",
            codCat: "L057"
        },
        {
            name: "Tavagnacco",
            codCat: "L065"
        },
        {
            name: "Terzo d'Aquileia",
            codCat: "L144"
        },
        {
            name: "Tolmezzo",
            codCat: "L195"
        },
        {
            name: "Torreano",
            codCat: "L246"
        },
        {
            name: "Torviscosa",
            codCat: "L309"
        },
        {
            name: "Trasaghis",
            codCat: "L335"
        },
        {
            name: "Treppo Grande",
            codCat: "L382"
        },
        {
            name: "Tricesimo",
            codCat: "L421"
        },
        {
            name: "Trivignano Udinese",
            codCat: "L438"
        },
        {
            name: "Udine",
            codCat: "L483"
        },
        {
            name: "Varmo",
            codCat: "L686"
        },
        {
            name: "Venzone",
            codCat: "L743"
        },
        {
            name: "Verzegnis",
            codCat: "L801"
        },
        {
            name: "Villa Santina",
            codCat: "L909"
        },
        {
            name: "Visco",
            codCat: "M073"
        },
        {
            name: "Zuglio",
            codCat: "M200"
        },
        {
            name: "Forgaria nel Friuli",
            codCat: "D700"
        },
        {
            name: "Campolongo Tapogliano",
            codCat: "M311"
        },
        {
            name: "Rivignano Teor",
            codCat: "M317"
        },
        {
            name: "Sappada",
            codCat: "I421"
        },
        {
            name: "Fiumicello Villa Vicentina",
            codCat: "M400"
        },
        {
            name: "Treppo Ligosullo",
            codCat: "M399"
        },
        {
            name: "Capriva del Friuli",
            codCat: "B712"
        },
        {
            name: "Cormons",
            codCat: "D014"
        },
        {
            name: "Doberdò del Lago",
            codCat: "D312"
        },
        {
            name: "Dolegna del Collio",
            codCat: "D321"
        },
        {
            name: "Farra d'Isonzo",
            codCat: "D504"
        },
        {
            name: "Fogliano Redipuglia",
            codCat: "D645"
        },
        {
            name: "Gorizia",
            codCat: "E098"
        },
        {
            name: "Gradisca d'Isonzo",
            codCat: "E124"
        },
        {
            name: "Grado",
            codCat: "E125"
        },
        {
            name: "Mariano del Friuli",
            codCat: "E952"
        },
        {
            name: "Medea",
            codCat: "F081"
        },
        {
            name: "Monfalcone",
            codCat: "F356"
        },
        {
            name: "Moraro",
            codCat: "F710"
        },
        {
            name: "Mossa",
            codCat: "F767"
        },
        {
            name: "Romans d'Isonzo",
            codCat: "H514"
        },
        {
            name: "Ronchi dei Legionari",
            codCat: "H531"
        },
        {
            name: "Sagrado",
            codCat: "H665"
        },
        {
            name: "San Canzian d'Isonzo",
            codCat: "H787"
        },
        {
            name: "San Floriano del Collio",
            codCat: "H845"
        },
        {
            name: "San Lorenzo Isontino",
            codCat: "H964"
        },
        {
            name: "San Pier d'Isonzo",
            codCat: "I082"
        },
        {
            name: "Savogna d'Isonzo",
            codCat: "I479"
        },
        {
            name: "Staranzano",
            codCat: "I939"
        },
        {
            name: "Turriaco",
            codCat: "L474"
        },
        {
            name: "Villesse",
            codCat: "M043"
        },
        {
            name: "Duino Aurisina",
            codCat: "D383"
        },
        {
            name: "Monrupino",
            codCat: "F378"
        },
        {
            name: "Muggia",
            codCat: "F795"
        },
        {
            name: "San Dorligo della Valle",
            codCat: "D324"
        },
        {
            name: "Sgonico",
            codCat: "I715"
        },
        {
            name: "Trieste",
            codCat: "L424"
        },
        {
            name: "Andreis",
            codCat: "A283"
        },
        {
            name: "Arba",
            codCat: "A354"
        },
        {
            name: "Aviano",
            codCat: "A516"
        },
        {
            name: "Azzano Decimo",
            codCat: "A530"
        },
        {
            name: "Barcis",
            codCat: "A640"
        },
        {
            name: "Brugnera",
            codCat: "B215"
        },
        {
            name: "Budoia",
            codCat: "B247"
        },
        {
            name: "Caneva",
            codCat: "B598"
        },
        {
            name: "Casarsa della Delizia",
            codCat: "B940"
        },
        {
            name: "Castelnovo del Friuli",
            codCat: "C217"
        },
        {
            name: "Cavasso Nuovo",
            codCat: "C385"
        },
        {
            name: "Chions",
            codCat: "C640"
        },
        {
            name: "Cimolais",
            codCat: "C699"
        },
        {
            name: "Claut",
            codCat: "C790"
        },
        {
            name: "Clauzetto",
            codCat: "C791"
        },
        {
            name: "Cordenons",
            codCat: "C991"
        },
        {
            name: "Cordovado",
            codCat: "C993"
        },
        {
            name: "Erto e Casso",
            codCat: "D426"
        },
        {
            name: "Fanna",
            codCat: "D487"
        },
        {
            name: "Fiume Veneto",
            codCat: "D621"
        },
        {
            name: "Fontanafredda",
            codCat: "D670"
        },
        {
            name: "Frisanco",
            codCat: "D804"
        },
        {
            name: "Maniago",
            codCat: "E889"
        },
        {
            name: "Meduno",
            codCat: "F089"
        },
        {
            name: "Montereale Valcellina",
            codCat: "F596"
        },
        {
            name: "Morsano al Tagliamento",
            codCat: "F750"
        },
        {
            name: "Pasiano di Pordenone",
            codCat: "G353"
        },
        {
            name: "Pinzano al Tagliamento",
            codCat: "G680"
        },
        {
            name: "Polcenigo",
            codCat: "G780"
        },
        {
            name: "Porcia",
            codCat: "G886"
        },
        {
            name: "Pordenone",
            codCat: "G888"
        },
        {
            name: "Prata di Pordenone",
            codCat: "G994"
        },
        {
            name: "Pravisdomini",
            codCat: "H010"
        },
        {
            name: "Roveredo in Piano",
            codCat: "H609"
        },
        {
            name: "Sacile",
            codCat: "H657"
        },
        {
            name: "San Giorgio della Richinvelda",
            codCat: "H891"
        },
        {
            name: "San Martino al Tagliamento",
            codCat: "H999"
        },
        {
            name: "San Quirino",
            codCat: "I136"
        },
        {
            name: "San Vito al Tagliamento",
            codCat: "I403"
        },
        {
            name: "Sequals",
            codCat: "I621"
        },
        {
            name: "Sesto al Reghena",
            codCat: "I686"
        },
        {
            name: "Spilimbergo",
            codCat: "I904"
        },
        {
            name: "Tramonti di Sopra",
            codCat: "L324"
        },
        {
            name: "Tramonti di Sotto",
            codCat: "L325"
        },
        {
            name: "Travesio",
            codCat: "L347"
        },
        {
            name: "Vito d'Asio",
            codCat: "M085"
        },
        {
            name: "Vivaro",
            codCat: "M096"
        },
        {
            name: "Zoppola",
            codCat: "M190"
        },
        {
            name: "Vajont",
            codCat: "M265"
        },
        {
            name: "Valvasone Arzene",
            codCat: "M346"
        },
        {
            name: "Airole",
            codCat: "A111"
        },
        {
            name: "Apricale",
            codCat: "A338"
        },
        {
            name: "Aquila d'Arroscia",
            codCat: "A344"
        },
        {
            name: "Armo",
            codCat: "A418"
        },
        {
            name: "Aurigo",
            codCat: "A499"
        },
        {
            name: "Badalucco",
            codCat: "A536"
        },
        {
            name: "Bajardo",
            codCat: "A581"
        },
        {
            name: "Bordighera",
            codCat: "A984"
        },
        {
            name: "Borghetto d'Arroscia",
            codCat: "A993"
        },
        {
            name: "Borgomaro",
            codCat: "B020"
        },
        {
            name: "Camporosso",
            codCat: "B559"
        },
        {
            name: "Caravonica",
            codCat: "B734"
        },
        {
            name: "Castellaro",
            codCat: "C143"
        },
        {
            name: "Castel Vittorio",
            codCat: "C110"
        },
        {
            name: "Ceriana",
            codCat: "C511"
        },
        {
            name: "Cervo",
            codCat: "C559"
        },
        {
            name: "Cesio",
            codCat: "C578"
        },
        {
            name: "Chiusanico",
            codCat: "C657"
        },
        {
            name: "Chiusavecchia",
            codCat: "C660"
        },
        {
            name: "Cipressa",
            codCat: "C718"
        },
        {
            name: "Civezza",
            codCat: "C755"
        },
        {
            name: "Cosio d'Arroscia",
            codCat: "D087"
        },
        {
            name: "Costarainera",
            codCat: "D114"
        },
        {
            name: "Diano Arentino",
            codCat: "D293"
        },
        {
            name: "Diano Castello",
            codCat: "D296"
        },
        {
            name: "Diano Marina",
            codCat: "D297"
        },
        {
            name: "Diano San Pietro",
            codCat: "D298"
        },
        {
            name: "Dolceacqua",
            codCat: "D318"
        },
        {
            name: "Dolcedo",
            codCat: "D319"
        },
        {
            name: "Imperia",
            codCat: "E290"
        },
        {
            name: "Isolabona",
            codCat: "E346"
        },
        {
            name: "Lucinasco",
            codCat: "E719"
        },
        {
            name: "Mendatica",
            codCat: "F123"
        },
        {
            name: "Molini di Triora",
            codCat: "F290"
        },
        {
            name: "Montegrosso Pian Latte",
            codCat: "F528"
        },
        {
            name: "Olivetta San Michele",
            codCat: "G041"
        },
        {
            name: "Ospedaletti",
            codCat: "G164"
        },
        {
            name: "Perinaldo",
            codCat: "G454"
        },
        {
            name: "Pietrabruna",
            codCat: "G607"
        },
        {
            name: "Pieve di Teco",
            codCat: "G632"
        },
        {
            name: "Pigna",
            codCat: "G660"
        },
        {
            name: "Pompeiana",
            codCat: "G814"
        },
        {
            name: "Pontedassio",
            codCat: "G840"
        },
        {
            name: "Pornassio",
            codCat: "G890"
        },
        {
            name: "Prelà",
            codCat: "H027"
        },
        {
            name: "Ranzo",
            codCat: "H180"
        },
        {
            name: "Rezzo",
            codCat: "H257"
        },
        {
            name: "Riva Ligure",
            codCat: "H328"
        },
        {
            name: "Rocchetta Nervina",
            codCat: "H460"
        },
        {
            name: "San Bartolomeo al Mare",
            codCat: "H763"
        },
        {
            name: "San Biagio della Cima",
            codCat: "H780"
        },
        {
            name: "San Lorenzo al Mare",
            codCat: "H957"
        },
        {
            name: "Sanremo",
            codCat: "I138"
        },
        {
            name: "Santo Stefano al Mare",
            codCat: "I365"
        },
        {
            name: "Seborga",
            codCat: "I556"
        },
        {
            name: "Soldano",
            codCat: "I796"
        },
        {
            name: "Taggia",
            codCat: "L024"
        },
        {
            name: "Terzorio",
            codCat: "L146"
        },
        {
            name: "Triora",
            codCat: "L430"
        },
        {
            name: "Vallebona",
            codCat: "L596"
        },
        {
            name: "Vallecrosia",
            codCat: "L599"
        },
        {
            name: "Vasia",
            codCat: "L693"
        },
        {
            name: "Ventimiglia",
            codCat: "L741"
        },
        {
            name: "Vessalico",
            codCat: "L809"
        },
        {
            name: "Villa Faraldi",
            codCat: "L943"
        },
        {
            name: "Montalto Carpasio",
            codCat: "M387"
        },
        {
            name: "Alassio",
            codCat: "A122"
        },
        {
            name: "Albenga",
            codCat: "A145"
        },
        {
            name: "Albissola Marina",
            codCat: "A165"
        },
        {
            name: "Albisola Superiore",
            codCat: "A166"
        },
        {
            name: "Altare",
            codCat: "A226"
        },
        {
            name: "Andora",
            codCat: "A278"
        },
        {
            name: "Arnasco",
            codCat: "A422"
        },
        {
            name: "Balestrino",
            codCat: "A593"
        },
        {
            name: "Bardineto",
            codCat: "A647"
        },
        {
            name: "Bergeggi",
            codCat: "A796"
        },
        {
            name: "Boissano",
            codCat: "A931"
        },
        {
            name: "Borghetto Santo Spirito",
            codCat: "A999"
        },
        {
            name: "Borgio Verezzi",
            codCat: "B005"
        },
        {
            name: "Bormida",
            codCat: "B048"
        },
        {
            name: "Cairo Montenotte",
            codCat: "B369"
        },
        {
            name: "Calice Ligure",
            codCat: "B409"
        },
        {
            name: "Calizzano",
            codCat: "B416"
        },
        {
            name: "Carcare",
            codCat: "B748"
        },
        {
            name: "Casanova Lerrone",
            codCat: "B927"
        },
        {
            name: "Castelbianco",
            codCat: "C063"
        },
        {
            name: "Castelvecchio di Rocca Barbena",
            codCat: "C276"
        },
        {
            name: "Celle Ligure",
            codCat: "C443"
        },
        {
            name: "Cengio",
            codCat: "C463"
        },
        {
            name: "Ceriale",
            codCat: "C510"
        },
        {
            name: "Cisano sul Neva",
            codCat: "C729"
        },
        {
            name: "Cosseria",
            codCat: "D095"
        },
        {
            name: "Dego",
            codCat: "D264"
        },
        {
            name: "Erli",
            codCat: "D424"
        },
        {
            name: "Finale Ligure",
            codCat: "D600"
        },
        {
            name: "Garlenda",
            codCat: "D927"
        },
        {
            name: "Giustenice",
            codCat: "E064"
        },
        {
            name: "Giusvalla",
            codCat: "E066"
        },
        {
            name: "Laigueglia",
            codCat: "E414"
        },
        {
            name: "Loano",
            codCat: "E632"
        },
        {
            name: "Magliolo",
            codCat: "E816"
        },
        {
            name: "Mallare",
            codCat: "E860"
        },
        {
            name: "Massimino",
            codCat: "F046"
        },
        {
            name: "Millesimo",
            codCat: "F213"
        },
        {
            name: "Mioglia",
            codCat: "F226"
        },
        {
            name: "Murialdo",
            codCat: "F813"
        },
        {
            name: "Nasino",
            codCat: "F847"
        },
        {
            name: "Noli",
            codCat: "F926"
        },
        {
            name: "Onzo",
            codCat: "G076"
        },
        {
            name: "Orco Feglino",
            codCat: "D522"
        },
        {
            name: "Ortovero",
            codCat: "G144"
        },
        {
            name: "Osiglia",
            codCat: "G155"
        },
        {
            name: "Pallare",
            codCat: "G281"
        },
        {
            name: "Piana Crixia",
            codCat: "G542"
        },
        {
            name: "Pietra Ligure",
            codCat: "G605"
        },
        {
            name: "Plodio",
            codCat: "G741"
        },
        {
            name: "Pontinvrea",
            codCat: "G866"
        },
        {
            name: "Quiliano",
            codCat: "H126"
        },
        {
            name: "Rialto",
            codCat: "H266"
        },
        {
            name: "Roccavignale",
            codCat: "H452"
        },
        {
            name: "Sassello",
            codCat: "I453"
        },
        {
            name: "Savona",
            codCat: "I480"
        },
        {
            name: "Spotorno",
            codCat: "I926"
        },
        {
            name: "Stella",
            codCat: "I946"
        },
        {
            name: "Stellanello",
            codCat: "I947"
        },
        {
            name: "Testico",
            codCat: "L152"
        },
        {
            name: "Toirano",
            codCat: "L190"
        },
        {
            name: "Tovo San Giacomo",
            codCat: "L315"
        },
        {
            name: "Urbe",
            codCat: "L499"
        },
        {
            name: "Vado Ligure",
            codCat: "L528"
        },
        {
            name: "Varazze",
            codCat: "L675"
        },
        {
            name: "Vendone",
            codCat: "L730"
        },
        {
            name: "Vezzi Portio",
            codCat: "L823"
        },
        {
            name: "Villanova d'Albenga",
            codCat: "L975"
        },
        {
            name: "Zuccarello",
            codCat: "M197"
        },
        {
            name: "Arenzano",
            codCat: "A388"
        },
        {
            name: "Avegno",
            codCat: "A506"
        },
        {
            name: "Bargagli",
            codCat: "A658"
        },
        {
            name: "Bogliasco",
            codCat: "A922"
        },
        {
            name: "Borzonasca",
            codCat: "B067"
        },
        {
            name: "Busalla",
            codCat: "B282"
        },
        {
            name: "Camogli",
            codCat: "B490"
        },
        {
            name: "Campo Ligure",
            codCat: "B538"
        },
        {
            name: "Campomorone",
            codCat: "B551"
        },
        {
            name: "Carasco",
            codCat: "B726"
        },
        {
            name: "Casarza Ligure",
            codCat: "B939"
        },
        {
            name: "Casella",
            codCat: "B956"
        },
        {
            name: "Castiglione Chiavarese",
            codCat: "C302"
        },
        {
            name: "Ceranesi",
            codCat: "C481"
        },
        {
            name: "Chiavari",
            codCat: "C621"
        },
        {
            name: "Cicagna",
            codCat: "C673"
        },
        {
            name: "Cogoleto",
            codCat: "C823"
        },
        {
            name: "Cogorno",
            codCat: "C826"
        },
        {
            name: "Coreglia Ligure",
            codCat: "C995"
        },
        {
            name: "Crocefieschi",
            codCat: "D175"
        },
        {
            name: "Davagna",
            codCat: "D255"
        },
        {
            name: "Fascia",
            codCat: "D509"
        },
        {
            name: "Favale di Malvaro",
            codCat: "D512"
        },
        {
            name: "Fontanigorda",
            codCat: "D677"
        },
        {
            name: "Genova",
            codCat: "D969"
        },
        {
            name: "Gorreto",
            codCat: "E109"
        },
        {
            name: "Isola del Cantone",
            codCat: "E341"
        },
        {
            name: "Lavagna",
            codCat: "E488"
        },
        {
            name: "Leivi",
            codCat: "E519"
        },
        {
            name: "Lorsica",
            codCat: "E695"
        },
        {
            name: "Lumarzo",
            codCat: "E737"
        },
        {
            name: "Masone",
            codCat: "F020"
        },
        {
            name: "Mele",
            codCat: "F098"
        },
        {
            name: "Mezzanego",
            codCat: "F173"
        },
        {
            name: "Mignanego",
            codCat: "F202"
        },
        {
            name: "Moconesi",
            codCat: "F256"
        },
        {
            name: "Moneglia",
            codCat: "F354"
        },
        {
            name: "Montebruno",
            codCat: "F445"
        },
        {
            name: "Montoggio",
            codCat: "F682"
        },
        {
            name: "Ne",
            codCat: "F858"
        },
        {
            name: "Neirone",
            codCat: "F862"
        },
        {
            name: "Orero",
            codCat: "G093"
        },
        {
            name: "Pieve Ligure",
            codCat: "G646"
        },
        {
            name: "Portofino",
            codCat: "G913"
        },
        {
            name: "Propata",
            codCat: "H073"
        },
        {
            name: "Rapallo",
            codCat: "H183"
        },
        {
            name: "Recco",
            codCat: "H212"
        },
        {
            name: "Rezzoaglio",
            codCat: "H258"
        },
        {
            name: "Ronco Scrivia",
            codCat: "H536"
        },
        {
            name: "Rondanina",
            codCat: "H546"
        },
        {
            name: "Rossiglione",
            codCat: "H581"
        },
        {
            name: "Rovegno",
            codCat: "H599"
        },
        {
            name: "San Colombano Certenoli",
            codCat: "H802"
        },
        {
            name: "Santa Margherita Ligure",
            codCat: "I225"
        },
        {
            name: "Sant'Olcese",
            codCat: "I346"
        },
        {
            name: "Santo Stefano d'Aveto",
            codCat: "I368"
        },
        {
            name: "Savignone",
            codCat: "I475"
        },
        {
            name: "Serra Riccò",
            codCat: "I640"
        },
        {
            name: "Sestri Levante",
            codCat: "I693"
        },
        {
            name: "Sori",
            codCat: "I852"
        },
        {
            name: "Tiglieto",
            codCat: "L167"
        },
        {
            name: "Torriglia",
            codCat: "L298"
        },
        {
            name: "Tribogna",
            codCat: "L416"
        },
        {
            name: "Uscio",
            codCat: "L507"
        },
        {
            name: "Valbrevenna",
            codCat: "L546"
        },
        {
            name: "Vobbia",
            codCat: "M105"
        },
        {
            name: "Zoagli",
            codCat: "M182"
        },
        {
            name: "Ameglia",
            codCat: "A261"
        },
        {
            name: "Arcola",
            codCat: "A373"
        },
        {
            name: "Beverino",
            codCat: "A836"
        },
        {
            name: "Bolano",
            codCat: "A932"
        },
        {
            name: "Bonassola",
            codCat: "A961"
        },
        {
            name: "Borghetto di Vara",
            codCat: "A992"
        },
        {
            name: "Brugnato",
            codCat: "B214"
        },
        {
            name: "Calice al Cornoviglio",
            codCat: "B410"
        },
        {
            name: "Carro",
            codCat: "B838"
        },
        {
            name: "Carrodano",
            codCat: "B839"
        },
        {
            name: "Castelnuovo Magra",
            codCat: "C240"
        },
        {
            name: "Deiva Marina",
            codCat: "D265"
        },
        {
            name: "Follo",
            codCat: "D655"
        },
        {
            name: "Framura",
            codCat: "D758"
        },
        {
            name: "La Spezia",
            codCat: "E463"
        },
        {
            name: "Lerici",
            codCat: "E542"
        },
        {
            name: "Levanto",
            codCat: "E560"
        },
        {
            name: "Maissana",
            codCat: "E842"
        },
        {
            name: "Monterosso al Mare",
            codCat: "F609"
        },
        {
            name: "Luni",
            codCat: "G143"
        },
        {
            name: "Pignone",
            codCat: "G664"
        },
        {
            name: "Portovenere",
            codCat: "G925"
        },
        {
            name: "Riccò del Golfo di Spezia",
            codCat: "H275"
        },
        {
            name: "Riomaggiore",
            codCat: "H304"
        },
        {
            name: "Rocchetta di Vara",
            codCat: "H461"
        },
        {
            name: "Santo Stefano di Magra",
            codCat: "I363"
        },
        {
            name: "Sarzana",
            codCat: "I449"
        },
        {
            name: "Sesta Godano",
            codCat: "E070"
        },
        {
            name: "Varese Ligure",
            codCat: "L681"
        },
        {
            name: "Vernazza",
            codCat: "L774"
        },
        {
            name: "Vezzano Ligure",
            codCat: "L819"
        },
        {
            name: "Zignago",
            codCat: "M177"
        },
        {
            name: "Agazzano",
            codCat: "A067"
        },
        {
            name: "Alseno",
            codCat: "A223"
        },
        {
            name: "Besenzone",
            codCat: "A823"
        },
        {
            name: "Bettola",
            codCat: "A831"
        },
        {
            name: "Bobbio",
            codCat: "A909"
        },
        {
            name: "Borgonovo Val Tidone",
            codCat: "B025"
        },
        {
            name: "Cadeo",
            codCat: "B332"
        },
        {
            name: "Calendasco",
            codCat: "B405"
        },
        {
            name: "Caorso",
            codCat: "B643"
        },
        {
            name: "Carpaneto Piacentino",
            codCat: "B812"
        },
        {
            name: "Castell'Arquato",
            codCat: "C145"
        },
        {
            name: "Castel San Giovanni",
            codCat: "C261"
        },
        {
            name: "Castelvetro Piacentino",
            codCat: "C288"
        },
        {
            name: "Cerignale",
            codCat: "C513"
        },
        {
            name: "Coli",
            codCat: "C838"
        },
        {
            name: "Corte Brugnatella",
            codCat: "D054"
        },
        {
            name: "Cortemaggiore",
            codCat: "D061"
        },
        {
            name: "Farini",
            codCat: "D502"
        },
        {
            name: "Ferriere",
            codCat: "D555"
        },
        {
            name: "Fiorenzuola d'Arda",
            codCat: "D611"
        },
        {
            name: "Gazzola",
            codCat: "D958"
        },
        {
            name: "Gossolengo",
            codCat: "E114"
        },
        {
            name: "Gragnano Trebbiense",
            codCat: "E132"
        },
        {
            name: "Gropparello",
            codCat: "E196"
        },
        {
            name: "Lugagnano Val d'Arda",
            codCat: "E726"
        },
        {
            name: "Monticelli d'Ongina",
            codCat: "F671"
        },
        {
            name: "Morfasso",
            codCat: "F724"
        },
        {
            name: "Ottone",
            codCat: "G195"
        },
        {
            name: "Piacenza",
            codCat: "G535"
        },
        {
            name: "Pianello Val Tidone",
            codCat: "G557"
        },
        {
            name: "Piozzano",
            codCat: "G696"
        },
        {
            name: "Podenzano",
            codCat: "G747"
        },
        {
            name: "Ponte dell'Olio",
            codCat: "G842"
        },
        {
            name: "Pontenure",
            codCat: "G852"
        },
        {
            name: "Rivergaro",
            codCat: "H350"
        },
        {
            name: "Rottofreno",
            codCat: "H593"
        },
        {
            name: "San Giorgio Piacentino",
            codCat: "H887"
        },
        {
            name: "San Pietro in Cerro",
            codCat: "G788"
        },
        {
            name: "Sarmato",
            codCat: "I434"
        },
        {
            name: "Travo",
            codCat: "L348"
        },
        {
            name: "Vernasca",
            codCat: "L772"
        },
        {
            name: "Vigolzone",
            codCat: "L897"
        },
        {
            name: "Villanova sull'Arda",
            codCat: "L980"
        },
        {
            name: "Zerba",
            codCat: "M165"
        },
        {
            name: "Ziano Piacentino",
            codCat: "L848"
        },
        {
            name: "Alta Val Tidone",
            codCat: "M386"
        },
        {
            name: "Albareto",
            codCat: "A138"
        },
        {
            name: "Bardi",
            codCat: "A646"
        },
        {
            name: "Bedonia",
            codCat: "A731"
        },
        {
            name: "Berceto",
            codCat: "A788"
        },
        {
            name: "Bore",
            codCat: "A987"
        },
        {
            name: "Borgo Val di Taro",
            codCat: "B042"
        },
        {
            name: "Busseto",
            codCat: "B293"
        },
        {
            name: "Calestano",
            codCat: "B408"
        },
        {
            name: "Collecchio",
            codCat: "C852"
        },
        {
            name: "Colorno",
            codCat: "C904"
        },
        {
            name: "Compiano",
            codCat: "C934"
        },
        {
            name: "Corniglio",
            codCat: "D026"
        },
        {
            name: "Felino",
            codCat: "D526"
        },
        {
            name: "Fidenza",
            codCat: "B034"
        },
        {
            name: "Fontanellato",
            codCat: "D673"
        },
        {
            name: "Fontevivo",
            codCat: "D685"
        },
        {
            name: "Fornovo di Taro",
            codCat: "D728"
        },
        {
            name: "Langhirano",
            codCat: "E438"
        },
        {
            name: "Lesignano de' Bagni",
            codCat: "E547"
        },
        {
            name: "Medesano",
            codCat: "F082"
        },
        {
            name: "Monchio delle Corti",
            codCat: "F340"
        },
        {
            name: "Montechiarugolo",
            codCat: "F473"
        },
        {
            name: "Neviano degli Arduini",
            codCat: "F882"
        },
        {
            name: "Noceto",
            codCat: "F914"
        },
        {
            name: "Palanzano",
            codCat: "G255"
        },
        {
            name: "Parma",
            codCat: "G337"
        },
        {
            name: "Pellegrino Parmense",
            codCat: "G424"
        },
        {
            name: "Roccabianca",
            codCat: "H384"
        },
        {
            name: "Sala Baganza",
            codCat: "H682"
        },
        {
            name: "Salsomaggiore Terme",
            codCat: "H720"
        },
        {
            name: "San Secondo Parmense",
            codCat: "I153"
        },
        {
            name: "Solignano",
            codCat: "I803"
        },
        {
            name: "Soragna",
            codCat: "I840"
        },
        {
            name: "Terenzo",
            codCat: "E548"
        },
        {
            name: "Tizzano Val Parma",
            codCat: "L183"
        },
        {
            name: "Tornolo",
            codCat: "L229"
        },
        {
            name: "Torrile",
            codCat: "L299"
        },
        {
            name: "Traversetolo",
            codCat: "L346"
        },
        {
            name: "Valmozzola",
            codCat: "L641"
        },
        {
            name: "Varano de' Melegari",
            codCat: "L672"
        },
        {
            name: "Varsi",
            codCat: "L689"
        },
        {
            name: "Sissa Trecasali",
            codCat: "M325"
        },
        {
            name: "Polesine Zibello",
            codCat: "M367"
        },
        {
            name: "Sorbolo Mezzani",
            codCat: "M411"
        },
        {
            name: "Albinea",
            codCat: "A162"
        },
        {
            name: "Bagnolo in Piano",
            codCat: "A573"
        },
        {
            name: "Baiso",
            codCat: "A586"
        },
        {
            name: "Bibbiano",
            codCat: "A850"
        },
        {
            name: "Boretto",
            codCat: "A988"
        },
        {
            name: "Brescello",
            codCat: "B156"
        },
        {
            name: "Cadelbosco di Sopra",
            codCat: "B328"
        },
        {
            name: "Campagnola Emilia",
            codCat: "B499"
        },
        {
            name: "Campegine",
            codCat: "B502"
        },
        {
            name: "Carpineti",
            codCat: "B825"
        },
        {
            name: "Casalgrande",
            codCat: "B893"
        },
        {
            name: "Casina",
            codCat: "B967"
        },
        {
            name: "Castellarano",
            codCat: "C141"
        },
        {
            name: "Castelnovo di Sotto",
            codCat: "C218"
        },
        {
            name: "Castelnovo ne' Monti",
            codCat: "C219"
        },
        {
            name: "Cavriago",
            codCat: "C405"
        },
        {
            name: "Canossa",
            codCat: "C669"
        },
        {
            name: "Correggio",
            codCat: "D037"
        },
        {
            name: "Fabbrico",
            codCat: "D450"
        },
        {
            name: "Gattatico",
            codCat: "D934"
        },
        {
            name: "Gualtieri",
            codCat: "E232"
        },
        {
            name: "Guastalla",
            codCat: "E253"
        },
        {
            name: "Luzzara",
            codCat: "E772"
        },
        {
            name: "Montecchio Emilia",
            codCat: "F463"
        },
        {
            name: "Novellara",
            codCat: "F960"
        },
        {
            name: "Poviglio",
            codCat: "G947"
        },
        {
            name: "Quattro Castella",
            codCat: "H122"
        },
        {
            name: "Reggiolo",
            codCat: "H225"
        },
        {
            name: "Reggio nell'Emilia",
            codCat: "H223"
        },
        {
            name: "Rio Saliceto",
            codCat: "H298"
        },
        {
            name: "Rolo",
            codCat: "H500"
        },
        {
            name: "Rubiera",
            codCat: "H628"
        },
        {
            name: "San Martino in Rio",
            codCat: "I011"
        },
        {
            name: "San Polo d'Enza",
            codCat: "I123"
        },
        {
            name: "Sant'Ilario d'Enza",
            codCat: "I342"
        },
        {
            name: "Scandiano",
            codCat: "I496"
        },
        {
            name: "Toano",
            codCat: "L184"
        },
        {
            name: "Vetto",
            codCat: "L815"
        },
        {
            name: "Vezzano sul Crostolo",
            codCat: "L820"
        },
        {
            name: "Viano",
            codCat: "L831"
        },
        {
            name: "Villa Minozzo",
            codCat: "L969"
        },
        {
            name: "Ventasso",
            codCat: "M364"
        },
        {
            name: "Bastiglia",
            codCat: "A713"
        },
        {
            name: "Bomporto",
            codCat: "A959"
        },
        {
            name: "Campogalliano",
            codCat: "B539"
        },
        {
            name: "Camposanto",
            codCat: "B566"
        },
        {
            name: "Carpi",
            codCat: "B819"
        },
        {
            name: "Castelfranco Emilia",
            codCat: "C107"
        },
        {
            name: "Castelnuovo Rangone",
            codCat: "C242"
        },
        {
            name: "Castelvetro di Modena",
            codCat: "C287"
        },
        {
            name: "Cavezzo",
            codCat: "C398"
        },
        {
            name: "Concordia sulla Secchia",
            codCat: "C951"
        },
        {
            name: "Fanano",
            codCat: "D486"
        },
        {
            name: "Finale Emilia",
            codCat: "D599"
        },
        {
            name: "Fiorano Modenese",
            codCat: "D607"
        },
        {
            name: "Fiumalbo",
            codCat: "D617"
        },
        {
            name: "Formigine",
            codCat: "D711"
        },
        {
            name: "Frassinoro",
            codCat: "D783"
        },
        {
            name: "Guiglia",
            codCat: "E264"
        },
        {
            name: "Lama Mocogno",
            codCat: "E426"
        },
        {
            name: "Maranello",
            codCat: "E904"
        },
        {
            name: "Marano sul Panaro",
            codCat: "E905"
        },
        {
            name: "Medolla",
            codCat: "F087"
        },
        {
            name: "Mirandola",
            codCat: "F240"
        },
        {
            name: "Modena",
            codCat: "F257"
        },
        {
            name: "Montecreto",
            codCat: "F484"
        },
        {
            name: "Montefiorino",
            codCat: "F503"
        },
        {
            name: "Montese",
            codCat: "F642"
        },
        {
            name: "Nonantola",
            codCat: "F930"
        },
        {
            name: "Novi di Modena",
            codCat: "F966"
        },
        {
            name: "Palagano",
            codCat: "G250"
        },
        {
            name: "Pavullo nel Frignano",
            codCat: "G393"
        },
        {
            name: "Pievepelago",
            codCat: "G649"
        },
        {
            name: "Polinago",
            codCat: "G789"
        },
        {
            name: "Prignano sulla Secchia",
            codCat: "H061"
        },
        {
            name: "Ravarino",
            codCat: "H195"
        },
        {
            name: "Riolunato",
            codCat: "H303"
        },
        {
            name: "San Cesario sul Panaro",
            codCat: "H794"
        },
        {
            name: "San Felice sul Panaro",
            codCat: "H835"
        },
        {
            name: "San Possidonio",
            codCat: "I128"
        },
        {
            name: "San Prospero",
            codCat: "I133"
        },
        {
            name: "Sassuolo",
            codCat: "I462"
        },
        {
            name: "Savignano sul Panaro",
            codCat: "I473"
        },
        {
            name: "Serramazzoni",
            codCat: "F357"
        },
        {
            name: "Sestola",
            codCat: "I689"
        },
        {
            name: "Soliera",
            codCat: "I802"
        },
        {
            name: "Spilamberto",
            codCat: "I903"
        },
        {
            name: "Vignola",
            codCat: "L885"
        },
        {
            name: "Zocca",
            codCat: "M183"
        },
        {
            name: "Anzola dell'Emilia",
            codCat: "A324"
        },
        {
            name: "Argelato",
            codCat: "A392"
        },
        {
            name: "Baricella",
            codCat: "A665"
        },
        {
            name: "Bentivoglio",
            codCat: "A785"
        },
        {
            name: "Bologna",
            codCat: "A944"
        },
        {
            name: "Borgo Tossignano",
            codCat: "B044"
        },
        {
            name: "Budrio",
            codCat: "B249"
        },
        {
            name: "Calderara di Reno",
            codCat: "B399"
        },
        {
            name: "Camugnano",
            codCat: "B572"
        },
        {
            name: "Casalecchio di Reno",
            codCat: "B880"
        },
        {
            name: "Casalfiumanese",
            codCat: "B892"
        },
        {
            name: "Castel d'Aiano",
            codCat: "C075"
        },
        {
            name: "Castel del Rio",
            codCat: "C086"
        },
        {
            name: "Castel di Casio",
            codCat: "B969"
        },
        {
            name: "Castel Guelfo di Bologna",
            codCat: "C121"
        },
        {
            name: "Castello d'Argile",
            codCat: "C185"
        },
        {
            name: "Castel Maggiore",
            codCat: "C204"
        },
        {
            name: "Castel San Pietro Terme",
            codCat: "C265"
        },
        {
            name: "Castenaso",
            codCat: "C292"
        },
        {
            name: "Castiglione dei Pepoli",
            codCat: "C296"
        },
        {
            name: "Crevalcore",
            codCat: "D166"
        },
        {
            name: "Dozza",
            codCat: "D360"
        },
        {
            name: "Fontanelice",
            codCat: "D668"
        },
        {
            name: "Gaggio Montano",
            codCat: "D847"
        },
        {
            name: "Galliera",
            codCat: "D878"
        },
        {
            name: "Granarolo dell'Emilia",
            codCat: "E136"
        },
        {
            name: "Grizzana Morandi",
            codCat: "E187"
        },
        {
            name: "Imola",
            codCat: "E289"
        },
        {
            name: "Lizzano in Belvedere",
            codCat: "A771"
        },
        {
            name: "Loiano",
            codCat: "E655"
        },
        {
            name: "Malalbergo",
            codCat: "E844"
        },
        {
            name: "Marzabotto",
            codCat: "B689"
        },
        {
            name: "Medicina",
            codCat: "F083"
        },
        {
            name: "Minerbio",
            codCat: "F219"
        },
        {
            name: "Molinella",
            codCat: "F288"
        },
        {
            name: "Monghidoro",
            codCat: "F363"
        },
        {
            name: "Monterenzio",
            codCat: "F597"
        },
        {
            name: "Monte San Pietro",
            codCat: "F627"
        },
        {
            name: "Monzuno",
            codCat: "F706"
        },
        {
            name: "Mordano",
            codCat: "F718"
        },
        {
            name: "Ozzano dell'Emilia",
            codCat: "G205"
        },
        {
            name: "Pianoro",
            codCat: "G570"
        },
        {
            name: "Pieve di Cento",
            codCat: "G643"
        },
        {
            name: "Sala Bolognese",
            codCat: "H678"
        },
        {
            name: "San Benedetto Val di Sambro",
            codCat: "G566"
        },
        {
            name: "San Giorgio di Piano",
            codCat: "H896"
        },
        {
            name: "San Giovanni in Persiceto",
            codCat: "G467"
        },
        {
            name: "San Lazzaro di Savena",
            codCat: "H945"
        },
        {
            name: "San Pietro in Casale",
            codCat: "I110"
        },
        {
            name: "Sant'Agata Bolognese",
            codCat: "I191"
        },
        {
            name: "Sasso Marconi",
            codCat: "G972"
        },
        {
            name: "Vergato",
            codCat: "L762"
        },
        {
            name: "Zola Predosa",
            codCat: "M185"
        },
        {
            name: "Valsamoggia",
            codCat: "M320"
        },
        {
            name: "Alto Reno Terme",
            codCat: "M369"
        },
        {
            name: "Argenta",
            codCat: "A393"
        },
        {
            name: "Bondeno",
            codCat: "A965"
        },
        {
            name: "Cento",
            codCat: "C469"
        },
        {
            name: "Codigoro",
            codCat: "C814"
        },
        {
            name: "Comacchio",
            codCat: "C912"
        },
        {
            name: "Copparo",
            codCat: "C980"
        },
        {
            name: "Ferrara",
            codCat: "D548"
        },
        {
            name: "Jolanda di Savoia",
            codCat: "E320"
        },
        {
            name: "Lagosanto",
            codCat: "E410"
        },
        {
            name: "Masi Torello",
            codCat: "F016"
        },
        {
            name: "Mesola",
            codCat: "F156"
        },
        {
            name: "Ostellato",
            codCat: "G184"
        },
        {
            name: "Poggio Renatico",
            codCat: "G768"
        },
        {
            name: "Portomaggiore",
            codCat: "G916"
        },
        {
            name: "Vigarano Mainarda",
            codCat: "L868"
        },
        {
            name: "Voghiera",
            codCat: "M110"
        },
        {
            name: "Goro",
            codCat: "E107"
        },
        {
            name: "Fiscaglia",
            codCat: "M323"
        },
        {
            name: "Terre del Reno",
            codCat: "M381"
        },
        {
            name: "Riva del Po",
            codCat: "M410"
        },
        {
            name: "Tresignana",
            codCat: "M409"
        },
        {
            name: "Alfonsine",
            codCat: "A191"
        },
        {
            name: "Bagnacavallo",
            codCat: "A547"
        },
        {
            name: "Bagnara di Romagna",
            codCat: "A551"
        },
        {
            name: "Brisighella",
            codCat: "B188"
        },
        {
            name: "Casola Valsenio",
            codCat: "B982"
        },
        {
            name: "Castel Bolognese",
            codCat: "C065"
        },
        {
            name: "Cervia",
            codCat: "C553"
        },
        {
            name: "Conselice",
            codCat: "C963"
        },
        {
            name: "Cotignola",
            codCat: "D121"
        },
        {
            name: "Faenza",
            codCat: "D458"
        },
        {
            name: "Fusignano",
            codCat: "D829"
        },
        {
            name: "Lugo",
            codCat: "E730"
        },
        {
            name: "Massa Lombarda",
            codCat: "F029"
        },
        {
            name: "Ravenna",
            codCat: "H199"
        },
        {
            name: "Riolo Terme",
            codCat: "H302"
        },
        {
            name: "Russi",
            codCat: "H642"
        },
        {
            name: "Sant'Agata sul Santerno",
            codCat: "I196"
        },
        {
            name: "Solarolo",
            codCat: "I787"
        },
        {
            name: "Bagno di Romagna",
            codCat: "A565"
        },
        {
            name: "Bertinoro",
            codCat: "A809"
        },
        {
            name: "Borghi",
            codCat: "B001"
        },
        {
            name: "Castrocaro Terme e Terra del Sole",
            codCat: "C339"
        },
        {
            name: "Cesena",
            codCat: "C573"
        },
        {
            name: "Cesenatico",
            codCat: "C574"
        },
        {
            name: "Civitella di Romagna",
            codCat: "C777"
        },
        {
            name: "Dovadola",
            codCat: "D357"
        },
        {
            name: "Forlì",
            codCat: "D704"
        },
        {
            name: "Forlimpopoli",
            codCat: "D705"
        },
        {
            name: "Galeata",
            codCat: "D867"
        },
        {
            name: "Gambettola",
            codCat: "D899"
        },
        {
            name: "Gatteo",
            codCat: "D935"
        },
        {
            name: "Longiano",
            codCat: "E675"
        },
        {
            name: "Meldola",
            codCat: "F097"
        },
        {
            name: "Mercato Saraceno",
            codCat: "F139"
        },
        {
            name: "Modigliana",
            codCat: "F259"
        },
        {
            name: "Montiano",
            codCat: "F668"
        },
        {
            name: "Portico e San Benedetto",
            codCat: "G904"
        },
        {
            name: "Predappio",
            codCat: "H017"
        },
        {
            name: "Premilcuore",
            codCat: "H034"
        },
        {
            name: "Rocca San Casciano",
            codCat: "H437"
        },
        {
            name: "Roncofreddo",
            codCat: "H542"
        },
        {
            name: "San Mauro Pascoli",
            codCat: "I027"
        },
        {
            name: "Santa Sofia",
            codCat: "I310"
        },
        {
            name: "Sarsina",
            codCat: "I444"
        },
        {
            name: "Savignano sul Rubicone",
            codCat: "I472"
        },
        {
            name: "Sogliano al Rubicone",
            codCat: "I779"
        },
        {
            name: "Tredozio",
            codCat: "L361"
        },
        {
            name: "Verghereto",
            codCat: "L764"
        },
        {
            name: "Bellaria-Igea Marina",
            codCat: "A747"
        },
        {
            name: "Cattolica",
            codCat: "C357"
        },
        {
            name: "Coriano",
            codCat: "D004"
        },
        {
            name: "Gemmano",
            codCat: "D961"
        },
        {
            name: "Misano Adriatico",
            codCat: "F244"
        },
        {
            name: "Mondaino",
            codCat: "F346"
        },
        {
            name: "Montefiore Conca",
            codCat: "F502"
        },
        {
            name: "Montegridolfo",
            codCat: "F523"
        },
        {
            name: "Morciano di Romagna",
            codCat: "F715"
        },
        {
            name: "Riccione",
            codCat: "H274"
        },
        {
            name: "Rimini",
            codCat: "H294"
        },
        {
            name: "Saludecio",
            codCat: "H724"
        },
        {
            name: "San Clemente",
            codCat: "H801"
        },
        {
            name: "San Giovanni in Marignano",
            codCat: "H921"
        },
        {
            name: "Santarcangelo di Romagna",
            codCat: "I304"
        },
        {
            name: "Verucchio",
            codCat: "L797"
        },
        {
            name: "Casteldelci",
            codCat: "C080"
        },
        {
            name: "Maiolo",
            codCat: "E838"
        },
        {
            name: "Novafeltria",
            codCat: "F137"
        },
        {
            name: "Pennabilli",
            codCat: "G433"
        },
        {
            name: "San Leo",
            codCat: "H949"
        },
        {
            name: "Sant'Agata Feltria",
            codCat: "I201"
        },
        {
            name: "Talamello",
            codCat: "L034"
        },
        {
            name: "Poggio Torriana",
            codCat: "M324"
        },
        {
            name: "Montescudo-Monte Colombo",
            codCat: "M368"
        },
        {
            name: "Montecopiolo",
            codCat: "F478"
        },
        {
            name: "Sassofeltrio",
            codCat: "I460"
        },
        {
            name: "Aulla",
            codCat: "A496"
        },
        {
            name: "Bagnone",
            codCat: "A576"
        },
        {
            name: "Carrara",
            codCat: "B832"
        },
        {
            name: "Casola in Lunigiana",
            codCat: "B979"
        },
        {
            name: "Comano",
            codCat: "C914"
        },
        {
            name: "Filattiera",
            codCat: "D590"
        },
        {
            name: "Fivizzano",
            codCat: "D629"
        },
        {
            name: "Fosdinovo",
            codCat: "D735"
        },
        {
            name: "Licciana Nardi",
            codCat: "E574"
        },
        {
            name: "Massa",
            codCat: "F023"
        },
        {
            name: "Montignoso",
            codCat: "F679"
        },
        {
            name: "Mulazzo",
            codCat: "F802"
        },
        {
            name: "Podenzana",
            codCat: "G746"
        },
        {
            name: "Pontremoli",
            codCat: "G870"
        },
        {
            name: "Tresana",
            codCat: "L386"
        },
        {
            name: "Villafranca in Lunigiana",
            codCat: "L946"
        },
        {
            name: "Zeri",
            codCat: "M169"
        },
        {
            name: "Altopascio",
            codCat: "A241"
        },
        {
            name: "Bagni di Lucca",
            codCat: "A560"
        },
        {
            name: "Barga",
            codCat: "A657"
        },
        {
            name: "Borgo a Mozzano",
            codCat: "B007"
        },
        {
            name: "Camaiore",
            codCat: "B455"
        },
        {
            name: "Camporgiano",
            codCat: "B557"
        },
        {
            name: "Capannori",
            codCat: "B648"
        },
        {
            name: "Careggine",
            codCat: "B760"
        },
        {
            name: "Castelnuovo di Garfagnana",
            codCat: "C236"
        },
        {
            name: "Castiglione di Garfagnana",
            codCat: "C303"
        },
        {
            name: "Coreglia Antelminelli",
            codCat: "C996"
        },
        {
            name: "Forte dei Marmi",
            codCat: "D730"
        },
        {
            name: "Fosciandora",
            codCat: "D734"
        },
        {
            name: "Gallicano",
            codCat: "D874"
        },
        {
            name: "Lucca",
            codCat: "E715"
        },
        {
            name: "Massarosa",
            codCat: "F035"
        },
        {
            name: "Minucciano",
            codCat: "F225"
        },
        {
            name: "Molazzana",
            codCat: "F283"
        },
        {
            name: "Montecarlo",
            codCat: "F452"
        },
        {
            name: "Pescaglia",
            codCat: "G480"
        },
        {
            name: "Piazza al Serchio",
            codCat: "G582"
        },
        {
            name: "Pietrasanta",
            codCat: "G628"
        },
        {
            name: "Pieve Fosciana",
            codCat: "G648"
        },
        {
            name: "Porcari",
            codCat: "G882"
        },
        {
            name: "San Romano in Garfagnana",
            codCat: "I142"
        },
        {
            name: "Seravezza",
            codCat: "I622"
        },
        {
            name: "Stazzema",
            codCat: "I942"
        },
        {
            name: "Vagli Sotto",
            codCat: "L533"
        },
        {
            name: "Viareggio",
            codCat: "L833"
        },
        {
            name: "Villa Basilica",
            codCat: "L913"
        },
        {
            name: "Villa Collemandina",
            codCat: "L926"
        },
        {
            name: "Fabbriche di Vergemoli",
            codCat: "M319"
        },
        {
            name: "Sillano Giuncugnano",
            codCat: "M347"
        },
        {
            name: "Agliana",
            codCat: "A071"
        },
        {
            name: "Buggiano",
            codCat: "B251"
        },
        {
            name: "Lamporecchio",
            codCat: "E432"
        },
        {
            name: "Larciano",
            codCat: "E451"
        },
        {
            name: "Marliana",
            codCat: "E960"
        },
        {
            name: "Massa e Cozzile",
            codCat: "F025"
        },
        {
            name: "Monsummano Terme",
            codCat: "F384"
        },
        {
            name: "Montale",
            codCat: "F410"
        },
        {
            name: "Montecatini-Terme",
            codCat: "A561"
        },
        {
            name: "Pescia",
            codCat: "G491"
        },
        {
            name: "Pieve a Nievole",
            codCat: "G636"
        },
        {
            name: "Pistoia",
            codCat: "G713"
        },
        {
            name: "Ponte Buggianese",
            codCat: "G833"
        },
        {
            name: "Quarrata",
            codCat: "H109"
        },
        {
            name: "Sambuca Pistoiese",
            codCat: "H744"
        },
        {
            name: "Serravalle Pistoiese",
            codCat: "I660"
        },
        {
            name: "Uzzano",
            codCat: "L522"
        },
        {
            name: "Chiesina Uzzanese",
            codCat: "C631"
        },
        {
            name: "Abetone Cutigliano",
            codCat: "M376"
        },
        {
            name: "San Marcello Piteglio",
            codCat: "M377"
        },
        {
            name: "Bagno a Ripoli",
            codCat: "A564"
        },
        {
            name: "Barberino di Mugello",
            codCat: "A632"
        },
        {
            name: "Borgo San Lorenzo",
            codCat: "B036"
        },
        {
            name: "Calenzano",
            codCat: "B406"
        },
        {
            name: "Campi Bisenzio",
            codCat: "B507"
        },
        {
            name: "Capraia e Limite",
            codCat: "B684"
        },
        {
            name: "Castelfiorentino",
            codCat: "C101"
        },
        {
            name: "Cerreto Guidi",
            codCat: "C529"
        },
        {
            name: "Certaldo",
            codCat: "C540"
        },
        {
            name: "Dicomano",
            codCat: "D299"
        },
        {
            name: "Empoli",
            codCat: "D403"
        },
        {
            name: "Fiesole",
            codCat: "D575"
        },
        {
            name: "Firenze",
            codCat: "D612"
        },
        {
            name: "Firenzuola",
            codCat: "D613"
        },
        {
            name: "Fucecchio",
            codCat: "D815"
        },
        {
            name: "Gambassi Terme",
            codCat: "D895"
        },
        {
            name: "Greve in Chianti",
            codCat: "E169"
        },
        {
            name: "Impruneta",
            codCat: "E291"
        },
        {
            name: "Lastra a Signa",
            codCat: "E466"
        },
        {
            name: "Londa",
            codCat: "E668"
        },
        {
            name: "Marradi",
            codCat: "E971"
        },
        {
            name: "Montaione",
            codCat: "F398"
        },
        {
            name: "Montelupo Fiorentino",
            codCat: "F551"
        },
        {
            name: "Montespertoli",
            codCat: "F648"
        },
        {
            name: "Palazzuolo sul Senio",
            codCat: "G270"
        },
        {
            name: "Pelago",
            codCat: "G420"
        },
        {
            name: "Pontassieve",
            codCat: "G825"
        },
        {
            name: "Reggello",
            codCat: "H222"
        },
        {
            name: "Rignano sull'Arno",
            codCat: "H286"
        },
        {
            name: "Rufina",
            codCat: "H635"
        },
        {
            name: "San Casciano in Val di Pesa",
            codCat: "H791"
        },
        {
            name: "San Godenzo",
            codCat: "H937"
        },
        {
            name: "Scandicci",
            codCat: "B962"
        },
        {
            name: "Sesto Fiorentino",
            codCat: "I684"
        },
        {
            name: "Signa",
            codCat: "I728"
        },
        {
            name: "Vaglia",
            codCat: "L529"
        },
        {
            name: "Vicchio",
            codCat: "L838"
        },
        {
            name: "Vinci",
            codCat: "M059"
        },
        {
            name: "Figline e Incisa Valdarno",
            codCat: "M321"
        },
        {
            name: "Scarperia e San Piero",
            codCat: "M326"
        },
        {
            name: "Barberino Tavarnelle",
            codCat: "M408"
        },
        {
            name: "Bibbona",
            codCat: "A852"
        },
        {
            name: "Campiglia Marittima",
            codCat: "B509"
        },
        {
            name: "Campo nell'Elba",
            codCat: "B553"
        },
        {
            name: "Capoliveri",
            codCat: "B669"
        },
        {
            name: "Capraia Isola",
            codCat: "B685"
        },
        {
            name: "Castagneto Carducci",
            codCat: "C044"
        },
        {
            name: "Cecina",
            codCat: "C415"
        },
        {
            name: "Collesalvetti",
            codCat: "C869"
        },
        {
            name: "Livorno",
            codCat: "E625"
        },
        {
            name: "Marciana",
            codCat: "E930"
        },
        {
            name: "Marciana Marina",
            codCat: "E931"
        },
        {
            name: "Piombino",
            codCat: "G687"
        },
        {
            name: "Porto Azzurro",
            codCat: "E680"
        },
        {
            name: "Portoferraio",
            codCat: "G912"
        },
        {
            name: "Rosignano Marittimo",
            codCat: "H570"
        },
        {
            name: "San Vincenzo",
            codCat: "I390"
        },
        {
            name: "Sassetta",
            codCat: "I454"
        },
        {
            name: "Suvereto",
            codCat: "L019"
        },
        {
            name: "Rio",
            codCat: "M391"
        },
        {
            name: "Bientina",
            codCat: "A864"
        },
        {
            name: "Buti",
            codCat: "B303"
        },
        {
            name: "Calci",
            codCat: "B390"
        },
        {
            name: "Calcinaia",
            codCat: "B392"
        },
        {
            name: "Capannoli",
            codCat: "B647"
        },
        {
            name: "Casale Marittimo",
            codCat: "B878"
        },
        {
            name: "Cascina",
            codCat: "B950"
        },
        {
            name: "Castelfranco di Sotto",
            codCat: "C113"
        },
        {
            name: "Castellina Marittima",
            codCat: "C174"
        },
        {
            name: "Castelnuovo di Val di Cecina",
            codCat: "C244"
        },
        {
            name: "Chianni",
            codCat: "C609"
        },
        {
            name: "Fauglia",
            codCat: "D510"
        },
        {
            name: "Guardistallo",
            codCat: "E250"
        },
        {
            name: "Lajatico",
            codCat: "E413"
        },
        {
            name: "Montecatini Val di Cecina",
            codCat: "F458"
        },
        {
            name: "Montescudaio",
            codCat: "F640"
        },
        {
            name: "Monteverdi Marittimo",
            codCat: "F661"
        },
        {
            name: "Montopoli in Val d'Arno",
            codCat: "F686"
        },
        {
            name: "Orciano Pisano",
            codCat: "G090"
        },
        {
            name: "Palaia",
            codCat: "G254"
        },
        {
            name: "Peccioli",
            codCat: "G395"
        },
        {
            name: "Pisa",
            codCat: "G702"
        },
        {
            name: "Pomarance",
            codCat: "G804"
        },
        {
            name: "Ponsacco",
            codCat: "G822"
        },
        {
            name: "Pontedera",
            codCat: "G843"
        },
        {
            name: "Riparbella",
            codCat: "H319"
        },
        {
            name: "San Giuliano Terme",
            codCat: "A562"
        },
        {
            name: "San Miniato",
            codCat: "I046"
        },
        {
            name: "Santa Croce sull'Arno",
            codCat: "I177"
        },
        {
            name: "Santa Luce",
            codCat: "I217"
        },
        {
            name: "Santa Maria a Monte",
            codCat: "I232"
        },
        {
            name: "Terricciola",
            codCat: "L138"
        },
        {
            name: "Vecchiano",
            codCat: "L702"
        },
        {
            name: "Vicopisano",
            codCat: "L850"
        },
        {
            name: "Volterra",
            codCat: "M126"
        },
        {
            name: "Casciana Terme Lari",
            codCat: "M327"
        },
        {
            name: "Crespina Lorenzana",
            codCat: "M328"
        },
        {
            name: "Anghiari",
            codCat: "A291"
        },
        {
            name: "Arezzo",
            codCat: "A390"
        },
        {
            name: "Badia Tedalda",
            codCat: "A541"
        },
        {
            name: "Bibbiena",
            codCat: "A851"
        },
        {
            name: "Bucine",
            codCat: "B243"
        },
        {
            name: "Capolona",
            codCat: "B670"
        },
        {
            name: "Caprese Michelangelo",
            codCat: "B693"
        },
        {
            name: "Castel Focognano",
            codCat: "C102"
        },
        {
            name: "Castel San Niccolò",
            codCat: "C263"
        },
        {
            name: "Castiglion Fibocchi",
            codCat: "C318"
        },
        {
            name: "Castiglion Fiorentino",
            codCat: "C319"
        },
        {
            name: "Cavriglia",
            codCat: "C407"
        },
        {
            name: "Chitignano",
            codCat: "C648"
        },
        {
            name: "Chiusi della Verna",
            codCat: "C663"
        },
        {
            name: "Civitella in Val di Chiana",
            codCat: "C774"
        },
        {
            name: "Cortona",
            codCat: "D077"
        },
        {
            name: "Foiano della Chiana",
            codCat: "D649"
        },
        {
            name: "Loro Ciuffenna",
            codCat: "E693"
        },
        {
            name: "Lucignano",
            codCat: "E718"
        },
        {
            name: "Marciano della Chiana",
            codCat: "E933"
        },
        {
            name: "Montemignaio",
            codCat: "F565"
        },
        {
            name: "Monterchi",
            codCat: "F594"
        },
        {
            name: "Monte San Savino",
            codCat: "F628"
        },
        {
            name: "Montevarchi",
            codCat: "F656"
        },
        {
            name: "Ortignano Raggiolo",
            codCat: "G139"
        },
        {
            name: "Pieve Santo Stefano",
            codCat: "G653"
        },
        {
            name: "Poppi",
            codCat: "G879"
        },
        {
            name: "San Giovanni Valdarno",
            codCat: "H901"
        },
        {
            name: "Sansepolcro",
            codCat: "I155"
        },
        {
            name: "Sestino",
            codCat: "I681"
        },
        {
            name: "Subbiano",
            codCat: "I991"
        },
        {
            name: "Talla",
            codCat: "L038"
        },
        {
            name: "Terranuova Bracciolini",
            codCat: "L123"
        },
        {
            name: "Castelfranco Piandiscò",
            codCat: "M322"
        },
        {
            name: "Pratovecchio Stia",
            codCat: "M329"
        },
        {
            name: "Laterina Pergine Valdarno",
            codCat: "M392"
        },
        {
            name: "Abbadia San Salvatore",
            codCat: "A006"
        },
        {
            name: "Asciano",
            codCat: "A461"
        },
        {
            name: "Buonconvento",
            codCat: "B269"
        },
        {
            name: "Casole d'Elsa",
            codCat: "B984"
        },
        {
            name: "Castellina in Chianti",
            codCat: "C172"
        },
        {
            name: "Castelnuovo Berardenga",
            codCat: "C227"
        },
        {
            name: "Castiglione d'Orcia",
            codCat: "C313"
        },
        {
            name: "Cetona",
            codCat: "C587"
        },
        {
            name: "Chianciano Terme",
            codCat: "C608"
        },
        {
            name: "Chiusdino",
            codCat: "C661"
        },
        {
            name: "Chiusi",
            codCat: "C662"
        },
        {
            name: "Colle di Val d'Elsa",
            codCat: "C847"
        },
        {
            name: "Gaiole in Chianti",
            codCat: "D858"
        },
        {
            name: "Montepulciano",
            codCat: "F592"
        },
        {
            name: "Monteriggioni",
            codCat: "F598"
        },
        {
            name: "Monteroni d'Arbia",
            codCat: "F605"
        },
        {
            name: "Monticiano",
            codCat: "F676"
        },
        {
            name: "Murlo",
            codCat: "F815"
        },
        {
            name: "Piancastagnaio",
            codCat: "G547"
        },
        {
            name: "Pienza",
            codCat: "G602"
        },
        {
            name: "Poggibonsi",
            codCat: "G752"
        },
        {
            name: "Radda in Chianti",
            codCat: "H153"
        },
        {
            name: "Radicofani",
            codCat: "H156"
        },
        {
            name: "Radicondoli",
            codCat: "H157"
        },
        {
            name: "Rapolano Terme",
            codCat: "H185"
        },
        {
            name: "San Casciano dei Bagni",
            codCat: "H790"
        },
        {
            name: "San Gimignano",
            codCat: "H875"
        },
        {
            name: "San Quirico d'Orcia",
            codCat: "I135"
        },
        {
            name: "Sarteano",
            codCat: "I445"
        },
        {
            name: "Siena",
            codCat: "I726"
        },
        {
            name: "Sinalunga",
            codCat: "A468"
        },
        {
            name: "Sovicille",
            codCat: "I877"
        },
        {
            name: "Torrita di Siena",
            codCat: "L303"
        },
        {
            name: "Trequanda",
            codCat: "L384"
        },
        {
            name: "Montalcino",
            codCat: "M378"
        },
        {
            name: "Arcidosso",
            codCat: "A369"
        },
        {
            name: "Campagnatico",
            codCat: "B497"
        },
        {
            name: "Capalbio",
            codCat: "B646"
        },
        {
            name: "Castel del Piano",
            codCat: "C085"
        },
        {
            name: "Castell'Azzara",
            codCat: "C147"
        },
        {
            name: "Castiglione della Pescaia",
            codCat: "C310"
        },
        {
            name: "Cinigiano",
            codCat: "C705"
        },
        {
            name: "Civitella Paganico",
            codCat: "C782"
        },
        {
            name: "Follonica",
            codCat: "D656"
        },
        {
            name: "Gavorrano",
            codCat: "D948"
        },
        {
            name: "Grosseto",
            codCat: "E202"
        },
        {
            name: "Isola del Giglio",
            codCat: "E348"
        },
        {
            name: "Magliano in Toscana",
            codCat: "E810"
        },
        {
            name: "Manciano",
            codCat: "E875"
        },
        {
            name: "Massa Marittima",
            codCat: "F032"
        },
        {
            name: "Monte Argentario",
            codCat: "F437"
        },
        {
            name: "Montieri",
            codCat: "F677"
        },
        {
            name: "Orbetello",
            codCat: "G088"
        },
        {
            name: "Pitigliano",
            codCat: "G716"
        },
        {
            name: "Roccalbegna",
            codCat: "H417"
        },
        {
            name: "Roccastrada",
            codCat: "H449"
        },
        {
            name: "Santa Fiora",
            codCat: "I187"
        },
        {
            name: "Scansano",
            codCat: "I504"
        },
        {
            name: "Scarlino",
            codCat: "I510"
        },
        {
            name: "Seggiano",
            codCat: "I571"
        },
        {
            name: "Sorano",
            codCat: "I841"
        },
        {
            name: "Monterotondo Marittimo",
            codCat: "F612"
        },
        {
            name: "Semproniano",
            codCat: "I601"
        },
        {
            name: "Cantagallo",
            codCat: "B626"
        },
        {
            name: "Carmignano",
            codCat: "B794"
        },
        {
            name: "Montemurlo",
            codCat: "F572"
        },
        {
            name: "Poggio a Caiano",
            codCat: "G754"
        },
        {
            name: "Prato",
            codCat: "G999"
        },
        {
            name: "Vaiano",
            codCat: "L537"
        },
        {
            name: "Vernio",
            codCat: "L775"
        },
        {
            name: "Assisi",
            codCat: "A475"
        },
        {
            name: "Bastia Umbra",
            codCat: "A710"
        },
        {
            name: "Bettona",
            codCat: "A832"
        },
        {
            name: "Bevagna",
            codCat: "A835"
        },
        {
            name: "Campello sul Clitunno",
            codCat: "B504"
        },
        {
            name: "Cannara",
            codCat: "B609"
        },
        {
            name: "Cascia",
            codCat: "B948"
        },
        {
            name: "Castel Ritaldi",
            codCat: "C252"
        },
        {
            name: "Castiglione del Lago",
            codCat: "C309"
        },
        {
            name: "Cerreto di Spoleto",
            codCat: "C527"
        },
        {
            name: "Citerna",
            codCat: "C742"
        },
        {
            name: "Città della Pieve",
            codCat: "C744"
        },
        {
            name: "Città di Castello",
            codCat: "C745"
        },
        {
            name: "Collazzone",
            codCat: "C845"
        },
        {
            name: "Corciano",
            codCat: "C990"
        },
        {
            name: "Costacciaro",
            codCat: "D108"
        },
        {
            name: "Deruta",
            codCat: "D279"
        },
        {
            name: "Foligno",
            codCat: "D653"
        },
        {
            name: "Fossato di Vico",
            codCat: "D745"
        },
        {
            name: "Fratta Todina",
            codCat: "D787"
        },
        {
            name: "Giano dell'Umbria",
            codCat: "E012"
        },
        {
            name: "Gualdo Cattaneo",
            codCat: "E229"
        },
        {
            name: "Gualdo Tadino",
            codCat: "E230"
        },
        {
            name: "Gubbio",
            codCat: "E256"
        },
        {
            name: "Lisciano Niccone",
            codCat: "E613"
        },
        {
            name: "Magione",
            codCat: "E805"
        },
        {
            name: "Marsciano",
            codCat: "E975"
        },
        {
            name: "Massa Martana",
            codCat: "F024"
        },
        {
            name: "Monte Castello di Vibio",
            codCat: "F456"
        },
        {
            name: "Montefalco",
            codCat: "F492"
        },
        {
            name: "Monteleone di Spoleto",
            codCat: "F540"
        },
        {
            name: "Monte Santa Maria Tiberina",
            codCat: "F629"
        },
        {
            name: "Montone",
            codCat: "F685"
        },
        {
            name: "Nocera Umbra",
            codCat: "F911"
        },
        {
            name: "Norcia",
            codCat: "F935"
        },
        {
            name: "Paciano",
            codCat: "G212"
        },
        {
            name: "Panicale",
            codCat: "G308"
        },
        {
            name: "Passignano sul Trasimeno",
            codCat: "G359"
        },
        {
            name: "Perugia",
            codCat: "G478"
        },
        {
            name: "Piegaro",
            codCat: "G601"
        },
        {
            name: "Pietralunga",
            codCat: "G618"
        },
        {
            name: "Poggiodomo",
            codCat: "G758"
        },
        {
            name: "Preci",
            codCat: "H015"
        },
        {
            name: "San Giustino",
            codCat: "H935"
        },
        {
            name: "Sant'Anatolia di Narco",
            codCat: "I263"
        },
        {
            name: "Scheggia e Pascelupo",
            codCat: "I522"
        },
        {
            name: "Scheggino",
            codCat: "I523"
        },
        {
            name: "Sellano",
            codCat: "I585"
        },
        {
            name: "Sigillo",
            codCat: "I727"
        },
        {
            name: "Spello",
            codCat: "I888"
        },
        {
            name: "Spoleto",
            codCat: "I921"
        },
        {
            name: "Todi",
            codCat: "L188"
        },
        {
            name: "Torgiano",
            codCat: "L216"
        },
        {
            name: "Trevi",
            codCat: "L397"
        },
        {
            name: "Tuoro sul Trasimeno",
            codCat: "L466"
        },
        {
            name: "Umbertide",
            codCat: "D786"
        },
        {
            name: "Valfabbrica",
            codCat: "L573"
        },
        {
            name: "Vallo di Nera",
            codCat: "L627"
        },
        {
            name: "Valtopina",
            codCat: "L653"
        },
        {
            name: "Acquasparta",
            codCat: "A045"
        },
        {
            name: "Allerona",
            codCat: "A207"
        },
        {
            name: "Alviano",
            codCat: "A242"
        },
        {
            name: "Amelia",
            codCat: "A262"
        },
        {
            name: "Arrone",
            codCat: "A439"
        },
        {
            name: "Attigliano",
            codCat: "A490"
        },
        {
            name: "Baschi",
            codCat: "A691"
        },
        {
            name: "Calvi dell'Umbria",
            codCat: "B446"
        },
        {
            name: "Castel Giorgio",
            codCat: "C117"
        },
        {
            name: "Castel Viscardo",
            codCat: "C289"
        },
        {
            name: "Fabro",
            codCat: "D454"
        },
        {
            name: "Ferentillo",
            codCat: "D538"
        },
        {
            name: "Ficulle",
            codCat: "D570"
        },
        {
            name: "Giove",
            codCat: "E045"
        },
        {
            name: "Guardea",
            codCat: "E241"
        },
        {
            name: "Lugnano in Teverina",
            codCat: "E729"
        },
        {
            name: "Montecastrilli",
            codCat: "F457"
        },
        {
            name: "Montecchio",
            codCat: "F462"
        },
        {
            name: "Montefranco",
            codCat: "F510"
        },
        {
            name: "Montegabbione",
            codCat: "F513"
        },
        {
            name: "Monteleone d'Orvieto",
            codCat: "F543"
        },
        {
            name: "Narni",
            codCat: "F844"
        },
        {
            name: "Orvieto",
            codCat: "G148"
        },
        {
            name: "Otricoli",
            codCat: "G189"
        },
        {
            name: "Parrano",
            codCat: "G344"
        },
        {
            name: "Penna in Teverina",
            codCat: "G432"
        },
        {
            name: "Polino",
            codCat: "G790"
        },
        {
            name: "Porano",
            codCat: "G881"
        },
        {
            name: "San Gemini",
            codCat: "H857"
        },
        {
            name: "San Venanzo",
            codCat: "I381"
        },
        {
            name: "Stroncone",
            codCat: "I981"
        },
        {
            name: "Terni",
            codCat: "L117"
        },
        {
            name: "Avigliano Umbro",
            codCat: "M258"
        },
        {
            name: "Acqualagna",
            codCat: "A035"
        },
        {
            name: "Apecchio",
            codCat: "A327"
        },
        {
            name: "Belforte all'Isauro",
            codCat: "A740"
        },
        {
            name: "Borgo Pace",
            codCat: "B026"
        },
        {
            name: "Cagli",
            codCat: "B352"
        },
        {
            name: "Cantiano",
            codCat: "B636"
        },
        {
            name: "Carpegna",
            codCat: "B816"
        },
        {
            name: "Cartoceto",
            codCat: "B846"
        },
        {
            name: "Fano",
            codCat: "D488"
        },
        {
            name: "Fermignano",
            codCat: "D541"
        },
        {
            name: "Fossombrone",
            codCat: "D749"
        },
        {
            name: "Fratte Rosa",
            codCat: "D791"
        },
        {
            name: "Frontino",
            codCat: "D807"
        },
        {
            name: "Frontone",
            codCat: "D808"
        },
        {
            name: "Gabicce Mare",
            codCat: "D836"
        },
        {
            name: "Gradara",
            codCat: "E122"
        },
        {
            name: "Isola del Piano",
            codCat: "E351"
        },
        {
            name: "Lunano",
            codCat: "E743"
        },
        {
            name: "Macerata Feltria",
            codCat: "E785"
        },
        {
            name: "Mercatello sul Metauro",
            codCat: "F135"
        },
        {
            name: "Mercatino Conca",
            codCat: "F136"
        },
        {
            name: "Mombaroccio",
            codCat: "F310"
        },
        {
            name: "Mondavio",
            codCat: "F347"
        },
        {
            name: "Mondolfo",
            codCat: "F348"
        },
        {
            name: "Montecalvo in Foglia",
            codCat: "F450"
        },
        {
            name: "Monte Cerignone",
            codCat: "F467"
        },
        {
            name: "Montefelcino",
            codCat: "F497"
        },
        {
            name: "Monte Grimano Terme",
            codCat: "F524"
        },
        {
            name: "Montelabbate",
            codCat: "F533"
        },
        {
            name: "Monte Porzio",
            codCat: "F589"
        },
        {
            name: "Peglio",
            codCat: "G416"
        },
        {
            name: "Pergola",
            codCat: "G453"
        },
        {
            name: "Pesaro",
            codCat: "G479"
        },
        {
            name: "Petriano",
            codCat: "G514"
        },
        {
            name: "Piandimeleto",
            codCat: "G551"
        },
        {
            name: "Pietrarubbia",
            codCat: "G627"
        },
        {
            name: "Piobbico",
            codCat: "G682"
        },
        {
            name: "San Costanzo",
            codCat: "H809"
        },
        {
            name: "San Lorenzo in Campo",
            codCat: "H958"
        },
        {
            name: "Sant'Angelo in Vado",
            codCat: "I287"
        },
        {
            name: "Sant'Ippolito",
            codCat: "I344"
        },
        {
            name: "Serra Sant'Abbondio",
            codCat: "I654"
        },
        {
            name: "Tavoleto",
            codCat: "L078"
        },
        {
            name: "Tavullia",
            codCat: "L081"
        },
        {
            name: "Urbania",
            codCat: "L498"
        },
        {
            name: "Urbino",
            codCat: "L500"
        },
        {
            name: "Vallefoglia",
            codCat: "M331"
        },
        {
            name: "Colli al Metauro",
            codCat: "M380"
        },
        {
            name: "Terre Roveresche",
            codCat: "M379"
        },
        {
            name: "Sassocorvaro Auditore",
            codCat: "M413"
        },
        {
            name: "Agugliano",
            codCat: "A092"
        },
        {
            name: "Ancona",
            codCat: "A271"
        },
        {
            name: "Arcevia",
            codCat: "A366"
        },
        {
            name: "Barbara",
            codCat: "A626"
        },
        {
            name: "Belvedere Ostrense",
            codCat: "A769"
        },
        {
            name: "Camerano",
            codCat: "B468"
        },
        {
            name: "Camerata Picena",
            codCat: "B470"
        },
        {
            name: "Castelbellino",
            codCat: "C060"
        },
        {
            name: "Castelfidardo",
            codCat: "C100"
        },
        {
            name: "Castelleone di Suasa",
            codCat: "C152"
        },
        {
            name: "Castelplanio",
            codCat: "C248"
        },
        {
            name: "Cerreto d'Esi",
            codCat: "C524"
        },
        {
            name: "Chiaravalle",
            codCat: "C615"
        },
        {
            name: "Corinaldo",
            codCat: "D007"
        },
        {
            name: "Cupramontana",
            codCat: "D211"
        },
        {
            name: "Fabriano",
            codCat: "D451"
        },
        {
            name: "Falconara Marittima",
            codCat: "D472"
        },
        {
            name: "Filottrano",
            codCat: "D597"
        },
        {
            name: "Genga",
            codCat: "D965"
        },
        {
            name: "Jesi",
            codCat: "E388"
        },
        {
            name: "Loreto",
            codCat: "E690"
        },
        {
            name: "Maiolati Spontini",
            codCat: "E837"
        },
        {
            name: "Mergo",
            codCat: "F145"
        },
        {
            name: "Monsano",
            codCat: "F381"
        },
        {
            name: "Montecarotto",
            codCat: "F453"
        },
        {
            name: "Montemarciano",
            codCat: "F560"
        },
        {
            name: "Monte Roberto",
            codCat: "F600"
        },
        {
            name: "Monte San Vito",
            codCat: "F634"
        },
        {
            name: "Morro d'Alba",
            codCat: "F745"
        },
        {
            name: "Numana",
            codCat: "F978"
        },
        {
            name: "Offagna",
            codCat: "G003"
        },
        {
            name: "Osimo",
            codCat: "G157"
        },
        {
            name: "Ostra",
            codCat: "F401"
        },
        {
            name: "Ostra Vetere",
            codCat: "F581"
        },
        {
            name: "Poggio San Marcello",
            codCat: "G771"
        },
        {
            name: "Polverigi",
            codCat: "G803"
        },
        {
            name: "Rosora",
            codCat: "H575"
        },
        {
            name: "San Marcello",
            codCat: "H979"
        },
        {
            name: "San Paolo di Jesi",
            codCat: "I071"
        },
        {
            name: "Santa Maria Nuova",
            codCat: "I251"
        },
        {
            name: "Sassoferrato",
            codCat: "I461"
        },
        {
            name: "Senigallia",
            codCat: "I608"
        },
        {
            name: "Serra de' Conti",
            codCat: "I643"
        },
        {
            name: "Serra San Quirico",
            codCat: "I653"
        },
        {
            name: "Sirolo",
            codCat: "I758"
        },
        {
            name: "Staffolo",
            codCat: "I932"
        },
        {
            name: "Trecastelli",
            codCat: "M318"
        },
        {
            name: "Apiro",
            codCat: "A329"
        },
        {
            name: "Appignano",
            codCat: "A334"
        },
        {
            name: "Belforte del Chienti",
            codCat: "A739"
        },
        {
            name: "Bolognola",
            codCat: "A947"
        },
        {
            name: "Caldarola",
            codCat: "B398"
        },
        {
            name: "Camerino",
            codCat: "B474"
        },
        {
            name: "Camporotondo di Fiastrone",
            codCat: "B562"
        },
        {
            name: "Castelraimondo",
            codCat: "C251"
        },
        {
            name: "Castelsantangelo sul Nera",
            codCat: "C267"
        },
        {
            name: "Cessapalombo",
            codCat: "C582"
        },
        {
            name: "Cingoli",
            codCat: "C704"
        },
        {
            name: "Civitanova Marche",
            codCat: "C770"
        },
        {
            name: "Colmurano",
            codCat: "C886"
        },
        {
            name: "Corridonia",
            codCat: "D042"
        },
        {
            name: "Esanatoglia",
            codCat: "D429"
        },
        {
            name: "Fiastra",
            codCat: "D564"
        },
        {
            name: "Fiuminata",
            codCat: "D628"
        },
        {
            name: "Gagliole",
            codCat: "D853"
        },
        {
            name: "Gualdo",
            codCat: "E228"
        },
        {
            name: "Loro Piceno",
            codCat: "E694"
        },
        {
            name: "Macerata",
            codCat: "E783"
        },
        {
            name: "Matelica",
            codCat: "F051"
        },
        {
            name: "Mogliano",
            codCat: "F268"
        },
        {
            name: "Montecassiano",
            codCat: "F454"
        },
        {
            name: "Monte Cavallo",
            codCat: "F460"
        },
        {
            name: "Montecosaro",
            codCat: "F482"
        },
        {
            name: "Montefano",
            codCat: "F496"
        },
        {
            name: "Montelupone",
            codCat: "F552"
        },
        {
            name: "Monte San Giusto",
            codCat: "F621"
        },
        {
            name: "Monte San Martino",
            codCat: "F622"
        },
        {
            name: "Morrovalle",
            codCat: "F749"
        },
        {
            name: "Muccia",
            codCat: "F793"
        },
        {
            name: "Penna San Giovanni",
            codCat: "G436"
        },
        {
            name: "Petriolo",
            codCat: "G515"
        },
        {
            name: "Pieve Torina",
            codCat: "G657"
        },
        {
            name: "Pioraco",
            codCat: "G690"
        },
        {
            name: "Poggio San Vicino",
            codCat: "D566"
        },
        {
            name: "Pollenza",
            codCat: "F567"
        },
        {
            name: "Porto Recanati",
            codCat: "G919"
        },
        {
            name: "Potenza Picena",
            codCat: "F632"
        },
        {
            name: "Recanati",
            codCat: "H211"
        },
        {
            name: "Ripe San Ginesio",
            codCat: "H323"
        },
        {
            name: "San Ginesio",
            codCat: "H876"
        },
        {
            name: "San Severino Marche",
            codCat: "I156"
        },
        {
            name: "Sant'Angelo in Pontano",
            codCat: "I286"
        },
        {
            name: "Sarnano",
            codCat: "I436"
        },
        {
            name: "Sefro",
            codCat: "I569"
        },
        {
            name: "Serrapetrona",
            codCat: "I651"
        },
        {
            name: "Serravalle di Chienti",
            codCat: "I661"
        },
        {
            name: "Tolentino",
            codCat: "L191"
        },
        {
            name: "Treia",
            codCat: "L366"
        },
        {
            name: "Urbisaglia",
            codCat: "L501"
        },
        {
            name: "Ussita",
            codCat: "L517"
        },
        {
            name: "Visso",
            codCat: "M078"
        },
        {
            name: "Valfornace",
            codCat: "M382"
        },
        {
            name: "Acquasanta Terme",
            codCat: "A044"
        },
        {
            name: "Acquaviva Picena",
            codCat: "A047"
        },
        {
            name: "Appignano del Tronto",
            codCat: "A335"
        },
        {
            name: "Arquata del Tronto",
            codCat: "A437"
        },
        {
            name: "Ascoli Piceno",
            codCat: "A462"
        },
        {
            name: "Carassai",
            codCat: "B727"
        },
        {
            name: "Castel di Lama",
            codCat: "C093"
        },
        {
            name: "Castignano",
            codCat: "C321"
        },
        {
            name: "Castorano",
            codCat: "C331"
        },
        {
            name: "Colli del Tronto",
            codCat: "C877"
        },
        {
            name: "Comunanza",
            codCat: "C935"
        },
        {
            name: "Cossignano",
            codCat: "D096"
        },
        {
            name: "Cupra Marittima",
            codCat: "D210"
        },
        {
            name: "Folignano",
            codCat: "D652"
        },
        {
            name: "Force",
            codCat: "D691"
        },
        {
            name: "Grottammare",
            codCat: "E207"
        },
        {
            name: "Maltignano",
            codCat: "E868"
        },
        {
            name: "Massignano",
            codCat: "F044"
        },
        {
            name: "Monsampolo del Tronto",
            codCat: "F380"
        },
        {
            name: "Montalto delle Marche",
            codCat: "F415"
        },
        {
            name: "Montedinove",
            codCat: "F487"
        },
        {
            name: "Montefiore dell'Aso",
            codCat: "F501"
        },
        {
            name: "Montegallo",
            codCat: "F516"
        },
        {
            name: "Montemonaco",
            codCat: "F570"
        },
        {
            name: "Monteprandone",
            codCat: "F591"
        },
        {
            name: "Offida",
            codCat: "G005"
        },
        {
            name: "Palmiano",
            codCat: "G289"
        },
        {
            name: "Ripatransone",
            codCat: "H321"
        },
        {
            name: "Roccafluvione",
            codCat: "H390"
        },
        {
            name: "Rotella",
            codCat: "H588"
        },
        {
            name: "San Benedetto del Tronto",
            codCat: "H769"
        },
        {
            name: "Spinetoli",
            codCat: "I912"
        },
        {
            name: "Venarotta",
            codCat: "L728"
        },
        {
            name: "Altidona",
            codCat: "A233"
        },
        {
            name: "Amandola",
            codCat: "A252"
        },
        {
            name: "Belmonte Piceno",
            codCat: "A760"
        },
        {
            name: "Campofilone",
            codCat: "B534"
        },
        {
            name: "Falerone",
            codCat: "D477"
        },
        {
            name: "Fermo",
            codCat: "D542"
        },
        {
            name: "Francavilla d'Ete",
            codCat: "D760"
        },
        {
            name: "Grottazzolina",
            codCat: "E208"
        },
        {
            name: "Lapedona",
            codCat: "E447"
        },
        {
            name: "Magliano di Tenna",
            codCat: "E807"
        },
        {
            name: "Massa Fermana",
            codCat: "F021"
        },
        {
            name: "Monsampietro Morico",
            codCat: "F379"
        },
        {
            name: "Montappone",
            codCat: "F428"
        },
        {
            name: "Montefalcone Appennino",
            codCat: "F493"
        },
        {
            name: "Montefortino",
            codCat: "F509"
        },
        {
            name: "Monte Giberto",
            codCat: "F517"
        },
        {
            name: "Montegiorgio",
            codCat: "F520"
        },
        {
            name: "Montegranaro",
            codCat: "F522"
        },
        {
            name: "Monteleone di Fermo",
            codCat: "F536"
        },
        {
            name: "Montelparo",
            codCat: "F549"
        },
        {
            name: "Monte Rinaldo",
            codCat: "F599"
        },
        {
            name: "Monterubbiano",
            codCat: "F614"
        },
        {
            name: "Monte San Pietrangeli",
            codCat: "F626"
        },
        {
            name: "Monte Urano",
            codCat: "F653"
        },
        {
            name: "Monte Vidon Combatte",
            codCat: "F664"
        },
        {
            name: "Monte Vidon Corrado",
            codCat: "F665"
        },
        {
            name: "Montottone",
            codCat: "F697"
        },
        {
            name: "Moresco",
            codCat: "F722"
        },
        {
            name: "Ortezzano",
            codCat: "G137"
        },
        {
            name: "Pedaso",
            codCat: "G403"
        },
        {
            name: "Petritoli",
            codCat: "G516"
        },
        {
            name: "Ponzano di Fermo",
            codCat: "G873"
        },
        {
            name: "Porto San Giorgio",
            codCat: "G920"
        },
        {
            name: "Porto Sant'Elpidio",
            codCat: "G921"
        },
        {
            name: "Rapagnano",
            codCat: "H182"
        },
        {
            name: "Santa Vittoria in Matenano",
            codCat: "I315"
        },
        {
            name: "Sant'Elpidio a Mare",
            codCat: "I324"
        },
        {
            name: "Servigliano",
            codCat: "C070"
        },
        {
            name: "Smerillo",
            codCat: "I774"
        },
        {
            name: "Torre San Patrizio",
            codCat: "L279"
        },
        {
            name: "Acquapendente",
            codCat: "A040"
        },
        {
            name: "Arlena di Castro",
            codCat: "A412"
        },
        {
            name: "Bagnoregio",
            codCat: "A577"
        },
        {
            name: "Barbarano Romano",
            codCat: "A628"
        },
        {
            name: "Bassano Romano",
            codCat: "A704"
        },
        {
            name: "Bassano in Teverina",
            codCat: "A706"
        },
        {
            name: "Blera",
            codCat: "A857"
        },
        {
            name: "Bolsena",
            codCat: "A949"
        },
        {
            name: "Bomarzo",
            codCat: "A955"
        },
        {
            name: "Calcata",
            codCat: "B388"
        },
        {
            name: "Canepina",
            codCat: "B597"
        },
        {
            name: "Canino",
            codCat: "B604"
        },
        {
            name: "Capodimonte",
            codCat: "B663"
        },
        {
            name: "Capranica",
            codCat: "B688"
        },
        {
            name: "Caprarola",
            codCat: "B691"
        },
        {
            name: "Carbognano",
            codCat: "B735"
        },
        {
            name: "Castel Sant'Elia",
            codCat: "C269"
        },
        {
            name: "Castiglione in Teverina",
            codCat: "C315"
        },
        {
            name: "Celleno",
            codCat: "C446"
        },
        {
            name: "Cellere",
            codCat: "C447"
        },
        {
            name: "Civita Castellana",
            codCat: "C765"
        },
        {
            name: "Civitella d'Agliano",
            codCat: "C780"
        },
        {
            name: "Corchiano",
            codCat: "C988"
        },
        {
            name: "Fabrica di Roma",
            codCat: "D452"
        },
        {
            name: "Faleria",
            codCat: "D475"
        },
        {
            name: "Farnese",
            codCat: "D503"
        },
        {
            name: "Gallese",
            codCat: "D870"
        },
        {
            name: "Gradoli",
            codCat: "E126"
        },
        {
            name: "Graffignano",
            codCat: "E128"
        },
        {
            name: "Grotte di Castro",
            codCat: "E210"
        },
        {
            name: "Ischia di Castro",
            codCat: "E330"
        },
        {
            name: "Latera",
            codCat: "E467"
        },
        {
            name: "Lubriano",
            codCat: "E713"
        },
        {
            name: "Marta",
            codCat: "E978"
        },
        {
            name: "Montalto di Castro",
            codCat: "F419"
        },
        {
            name: "Montefiascone",
            codCat: "F499"
        },
        {
            name: "Monte Romano",
            codCat: "F603"
        },
        {
            name: "Monterosi",
            codCat: "F606"
        },
        {
            name: "Nepi",
            codCat: "F868"
        },
        {
            name: "Onano",
            codCat: "G065"
        },
        {
            name: "Oriolo Romano",
            codCat: "G111"
        },
        {
            name: "Orte",
            codCat: "G135"
        },
        {
            name: "Piansano",
            codCat: "G571"
        },
        {
            name: "Proceno",
            codCat: "H071"
        },
        {
            name: "Ronciglione",
            codCat: "H534"
        },
        {
            name: "Villa San Giovanni in Tuscia",
            codCat: "H913"
        },
        {
            name: "San Lorenzo Nuovo",
            codCat: "H969"
        },
        {
            name: "Soriano nel Cimino",
            codCat: "I855"
        },
        {
            name: "Sutri",
            codCat: "L017"
        },
        {
            name: "Tarquinia",
            codCat: "D024"
        },
        {
            name: "Tessennano",
            codCat: "L150"
        },
        {
            name: "Tuscania",
            codCat: "L310"
        },
        {
            name: "Valentano",
            codCat: "L569"
        },
        {
            name: "Vallerano",
            codCat: "L612"
        },
        {
            name: "Vasanello",
            codCat: "A701"
        },
        {
            name: "Vejano",
            codCat: "L713"
        },
        {
            name: "Vetralla",
            codCat: "L814"
        },
        {
            name: "Vignanello",
            codCat: "L882"
        },
        {
            name: "Viterbo",
            codCat: "M082"
        },
        {
            name: "Vitorchiano",
            codCat: "M086"
        },
        {
            name: "Accumoli",
            codCat: "A019"
        },
        {
            name: "Amatrice",
            codCat: "A258"
        },
        {
            name: "Antrodoco",
            codCat: "A315"
        },
        {
            name: "Ascrea",
            codCat: "A464"
        },
        {
            name: "Belmonte in Sabina",
            codCat: "A765"
        },
        {
            name: "Borbona",
            codCat: "A981"
        },
        {
            name: "Borgorose",
            codCat: "B008"
        },
        {
            name: "Borgo Velino",
            codCat: "A996"
        },
        {
            name: "Cantalice",
            codCat: "B627"
        },
        {
            name: "Cantalupo in Sabina",
            codCat: "B631"
        },
        {
            name: "Casaprota",
            codCat: "B934"
        },
        {
            name: "Casperia",
            codCat: "A472"
        },
        {
            name: "Castel di Tora",
            codCat: "C098"
        },
        {
            name: "Castelnuovo di Farfa",
            codCat: "C224"
        },
        {
            name: "Castel Sant'Angelo",
            codCat: "C268"
        },
        {
            name: "Cittaducale",
            codCat: "C746"
        },
        {
            name: "Cittareale",
            codCat: "C749"
        },
        {
            name: "Collalto Sabino",
            codCat: "C841"
        },
        {
            name: "Colle di Tora",
            codCat: "C857"
        },
        {
            name: "Collegiove",
            codCat: "C859"
        },
        {
            name: "Collevecchio",
            codCat: "C876"
        },
        {
            name: "Colli sul Velino",
            codCat: "C880"
        },
        {
            name: "Concerviano",
            codCat: "C946"
        },
        {
            name: "Configni",
            codCat: "C959"
        },
        {
            name: "Contigliano",
            codCat: "C969"
        },
        {
            name: "Cottanello",
            codCat: "D124"
        },
        {
            name: "Fara in Sabina",
            codCat: "D493"
        },
        {
            name: "Fiamignano",
            codCat: "D560"
        },
        {
            name: "Forano",
            codCat: "D689"
        },
        {
            name: "Frasso Sabino",
            codCat: "D785"
        },
        {
            name: "Greccio",
            codCat: "E160"
        },
        {
            name: "Labro",
            codCat: "E393"
        },
        {
            name: "Leonessa",
            codCat: "E535"
        },
        {
            name: "Longone Sabino",
            codCat: "E681"
        },
        {
            name: "Magliano Sabina",
            codCat: "E812"
        },
        {
            name: "Marcetelli",
            codCat: "E927"
        },
        {
            name: "Micigliano",
            codCat: "F193"
        },
        {
            name: "Mompeo",
            codCat: "F319"
        },
        {
            name: "Montasola",
            codCat: "F430"
        },
        {
            name: "Montebuono",
            codCat: "F446"
        },
        {
            name: "Monteleone Sabino",
            codCat: "F541"
        },
        {
            name: "Montenero Sabino",
            codCat: "F579"
        },
        {
            name: "Monte San Giovanni in Sabina",
            codCat: "F619"
        },
        {
            name: "Montopoli di Sabina",
            codCat: "F687"
        },
        {
            name: "Morro Reatino",
            codCat: "F746"
        },
        {
            name: "Nespolo",
            codCat: "F876"
        },
        {
            name: "Orvinio",
            codCat: "B595"
        },
        {
            name: "Paganico Sabino",
            codCat: "G232"
        },
        {
            name: "Pescorocchiano",
            codCat: "G498"
        },
        {
            name: "Petrella Salto",
            codCat: "G513"
        },
        {
            name: "Poggio Bustone",
            codCat: "G756"
        },
        {
            name: "Poggio Catino",
            codCat: "G757"
        },
        {
            name: "Poggio Mirteto",
            codCat: "G763"
        },
        {
            name: "Poggio Moiano",
            codCat: "G764"
        },
        {
            name: "Poggio Nativo",
            codCat: "G765"
        },
        {
            name: "Poggio San Lorenzo",
            codCat: "G770"
        },
        {
            name: "Posta",
            codCat: "G934"
        },
        {
            name: "Pozzaglia Sabina",
            codCat: "G951"
        },
        {
            name: "Rieti",
            codCat: "H282"
        },
        {
            name: "Rivodutri",
            codCat: "H354"
        },
        {
            name: "Roccantica",
            codCat: "H427"
        },
        {
            name: "Rocca Sinibalda",
            codCat: "H446"
        },
        {
            name: "Salisano",
            codCat: "H713"
        },
        {
            name: "Scandriglia",
            codCat: "I499"
        },
        {
            name: "Selci",
            codCat: "I581"
        },
        {
            name: "Stimigliano",
            codCat: "I959"
        },
        {
            name: "Tarano",
            codCat: "L046"
        },
        {
            name: "Toffia",
            codCat: "L189"
        },
        {
            name: "Torricella in Sabina",
            codCat: "L293"
        },
        {
            name: "Torri in Sabina",
            codCat: "L286"
        },
        {
            name: "Turania",
            codCat: "G507"
        },
        {
            name: "Vacone",
            codCat: "L525"
        },
        {
            name: "Varco Sabino",
            codCat: "L676"
        },
        {
            name: "Affile",
            codCat: "A062"
        },
        {
            name: "Agosta",
            codCat: "A084"
        },
        {
            name: "Albano Laziale",
            codCat: "A132"
        },
        {
            name: "Allumiere",
            codCat: "A210"
        },
        {
            name: "Anguillara Sabazia",
            codCat: "A297"
        },
        {
            name: "Anticoli Corrado",
            codCat: "A309"
        },
        {
            name: "Anzio",
            codCat: "A323"
        },
        {
            name: "Arcinazzo Romano",
            codCat: "A370"
        },
        {
            name: "Ariccia",
            codCat: "A401"
        },
        {
            name: "Arsoli",
            codCat: "A446"
        },
        {
            name: "Artena",
            codCat: "A449"
        },
        {
            name: "Bellegra",
            codCat: "A749"
        },
        {
            name: "Bracciano",
            codCat: "B114"
        },
        {
            name: "Camerata Nuova",
            codCat: "B472"
        },
        {
            name: "Campagnano di Roma",
            codCat: "B496"
        },
        {
            name: "Canale Monterano",
            codCat: "B576"
        },
        {
            name: "Canterano",
            codCat: "B635"
        },
        {
            name: "Capena",
            codCat: "B649"
        },
        {
            name: "Capranica Prenestina",
            codCat: "B687"
        },
        {
            name: "Carpineto Romano",
            codCat: "B828"
        },
        {
            name: "Casape",
            codCat: "B932"
        },
        {
            name: "Castel Gandolfo",
            codCat: "C116"
        },
        {
            name: "Castel Madama",
            codCat: "C203"
        },
        {
            name: "Castelnuovo di Porto",
            codCat: "C237"
        },
        {
            name: "Castel San Pietro Romano",
            codCat: "C266"
        },
        {
            name: "Cave",
            codCat: "C390"
        },
        {
            name: "Cerreto Laziale",
            codCat: "C518"
        },
        {
            name: "Cervara di Roma",
            codCat: "C543"
        },
        {
            name: "Cerveteri",
            codCat: "C552"
        },
        {
            name: "Ciciliano",
            codCat: "C677"
        },
        {
            name: "Cineto Romano",
            codCat: "C702"
        },
        {
            name: "Civitavecchia",
            codCat: "C773"
        },
        {
            name: "Civitella San Paolo",
            codCat: "C784"
        },
        {
            name: "Colleferro",
            codCat: "C858"
        },
        {
            name: "Colonna",
            codCat: "C900"
        },
        {
            name: "Fiano Romano",
            codCat: "D561"
        },
        {
            name: "Filacciano",
            codCat: "D586"
        },
        {
            name: "Formello",
            codCat: "D707"
        },
        {
            name: "Frascati",
            codCat: "D773"
        },
        {
            name: "Gallicano nel Lazio",
            codCat: "D875"
        },
        {
            name: "Gavignano",
            codCat: "D945"
        },
        {
            name: "Genazzano",
            codCat: "D964"
        },
        {
            name: "Genzano di Roma",
            codCat: "D972"
        },
        {
            name: "Gerano",
            codCat: "D978"
        },
        {
            name: "Gorga",
            codCat: "E091"
        },
        {
            name: "Grottaferrata",
            codCat: "E204"
        },
        {
            name: "Guidonia Montecelio",
            codCat: "E263"
        },
        {
            name: "Jenne",
            codCat: "E382"
        },
        {
            name: "Labico",
            codCat: "E392"
        },
        {
            name: "Lanuvio",
            codCat: "C767"
        },
        {
            name: "Licenza",
            codCat: "E576"
        },
        {
            name: "Magliano Romano",
            codCat: "E813"
        },
        {
            name: "Mandela",
            codCat: "B632"
        },
        {
            name: "Manziana",
            codCat: "E900"
        },
        {
            name: "Marano Equo",
            codCat: "E908"
        },
        {
            name: "Marcellina",
            codCat: "E924"
        },
        {
            name: "Marino",
            codCat: "E958"
        },
        {
            name: "Mazzano Romano",
            codCat: "F064"
        },
        {
            name: "Mentana",
            codCat: "F127"
        },
        {
            name: "Monte Compatri",
            codCat: "F477"
        },
        {
            name: "Monteflavio",
            codCat: "F504"
        },
        {
            name: "Montelanico",
            codCat: "F534"
        },
        {
            name: "Montelibretti",
            codCat: "F545"
        },
        {
            name: "Monte Porzio Catone",
            codCat: "F590"
        },
        {
            name: "Monterotondo",
            codCat: "F611"
        },
        {
            name: "Montorio Romano",
            codCat: "F692"
        },
        {
            name: "Moricone",
            codCat: "F730"
        },
        {
            name: "Morlupo",
            codCat: "F734"
        },
        {
            name: "Nazzano",
            codCat: "F857"
        },
        {
            name: "Nemi",
            codCat: "F865"
        },
        {
            name: "Nerola",
            codCat: "F871"
        },
        {
            name: "Nettuno",
            codCat: "F880"
        },
        {
            name: "Olevano Romano",
            codCat: "G022"
        },
        {
            name: "Palestrina",
            codCat: "G274"
        },
        {
            name: "Palombara Sabina",
            codCat: "G293"
        },
        {
            name: "Percile",
            codCat: "G444"
        },
        {
            name: "Pisoniano",
            codCat: "G704"
        },
        {
            name: "Poli",
            codCat: "G784"
        },
        {
            name: "Pomezia",
            codCat: "G811"
        },
        {
            name: "Ponzano Romano",
            codCat: "G874"
        },
        {
            name: "Riano",
            codCat: "H267"
        },
        {
            name: "Rignano Flaminio",
            codCat: "H288"
        },
        {
            name: "Riofreddo",
            codCat: "H300"
        },
        {
            name: "Rocca Canterano",
            codCat: "H387"
        },
        {
            name: "Rocca di Cave",
            codCat: "H401"
        },
        {
            name: "Rocca di Papa",
            codCat: "H404"
        },
        {
            name: "Roccagiovine",
            codCat: "H411"
        },
        {
            name: "Rocca Priora",
            codCat: "H432"
        },
        {
            name: "Rocca Santo Stefano",
            codCat: "H441"
        },
        {
            name: "Roiate",
            codCat: "H494"
        },
        {
            name: "Roma",
            codCat: "H501"
        },
        {
            name: "Roviano",
            codCat: "H618"
        },
        {
            name: "Sacrofano",
            codCat: "H658"
        },
        {
            name: "Sambuci",
            codCat: "H745"
        },
        {
            name: "San Gregorio da Sassola",
            codCat: "H942"
        },
        {
            name: "San Polo dei Cavalieri",
            codCat: "I125"
        },
        {
            name: "Santa Marinella",
            codCat: "I255"
        },
        {
            name: "Sant'Angelo Romano",
            codCat: "I284"
        },
        {
            name: "Sant'Oreste",
            codCat: "I352"
        },
        {
            name: "San Vito Romano",
            codCat: "I400"
        },
        {
            name: "Saracinesco",
            codCat: "I424"
        },
        {
            name: "Segni",
            codCat: "I573"
        },
        {
            name: "Subiaco",
            codCat: "I992"
        },
        {
            name: "Tivoli",
            codCat: "L182"
        },
        {
            name: "Tolfa",
            codCat: "L192"
        },
        {
            name: "Torrita Tiberina",
            codCat: "L302"
        },
        {
            name: "Trevignano Romano",
            codCat: "L401"
        },
        {
            name: "Vallepietra",
            codCat: "L611"
        },
        {
            name: "Vallinfreda",
            codCat: "L625"
        },
        {
            name: "Valmontone",
            codCat: "L639"
        },
        {
            name: "Velletri",
            codCat: "L719"
        },
        {
            name: "Vicovaro",
            codCat: "L851"
        },
        {
            name: "Vivaro Romano",
            codCat: "M095"
        },
        {
            name: "Zagarolo",
            codCat: "M141"
        },
        {
            name: "Lariano",
            codCat: "M207"
        },
        {
            name: "Ladispoli",
            codCat: "M212"
        },
        {
            name: "Ardea",
            codCat: "M213"
        },
        {
            name: "Ciampino",
            codCat: "M272"
        },
        {
            name: "San Cesareo",
            codCat: "M295"
        },
        {
            name: "Fiumicino",
            codCat: "M297"
        },
        {
            name: "Fonte Nuova",
            codCat: "M309"
        },
        {
            name: "Aprilia",
            codCat: "A341"
        },
        {
            name: "Bassiano",
            codCat: "A707"
        },
        {
            name: "Campodimele",
            codCat: "B527"
        },
        {
            name: "Castelforte",
            codCat: "C104"
        },
        {
            name: "Cisterna di Latina",
            codCat: "C740"
        },
        {
            name: "Cori",
            codCat: "D003"
        },
        {
            name: "Fondi",
            codCat: "D662"
        },
        {
            name: "Formia",
            codCat: "D708"
        },
        {
            name: "Gaeta",
            codCat: "D843"
        },
        {
            name: "Itri",
            codCat: "E375"
        },
        {
            name: "Latina",
            codCat: "E472"
        },
        {
            name: "Lenola",
            codCat: "E527"
        },
        {
            name: "Maenza",
            codCat: "E798"
        },
        {
            name: "Minturno",
            codCat: "F224"
        },
        {
            name: "Monte San Biagio",
            codCat: "F616"
        },
        {
            name: "Norma",
            codCat: "F937"
        },
        {
            name: "Pontinia",
            codCat: "G865"
        },
        {
            name: "Ponza",
            codCat: "G871"
        },
        {
            name: "Priverno",
            codCat: "G698"
        },
        {
            name: "Prossedi",
            codCat: "H076"
        },
        {
            name: "Roccagorga",
            codCat: "H413"
        },
        {
            name: "Rocca Massima",
            codCat: "H421"
        },
        {
            name: "Roccasecca dei Volsci",
            codCat: "H444"
        },
        {
            name: "Sabaudia",
            codCat: "H647"
        },
        {
            name: "San Felice Circeo",
            codCat: "H836"
        },
        {
            name: "Santi Cosma e Damiano",
            codCat: "I339"
        },
        {
            name: "Sermoneta",
            codCat: "I634"
        },
        {
            name: "Sezze",
            codCat: "I712"
        },
        {
            name: "Sonnino",
            codCat: "I832"
        },
        {
            name: "Sperlonga",
            codCat: "I892"
        },
        {
            name: "Spigno Saturnia",
            codCat: "I902"
        },
        {
            name: "Terracina",
            codCat: "L120"
        },
        {
            name: "Ventotene",
            codCat: "L742"
        },
        {
            name: "Acquafondata",
            codCat: "A032"
        },
        {
            name: "Acuto",
            codCat: "A054"
        },
        {
            name: "Alatri",
            codCat: "A123"
        },
        {
            name: "Alvito",
            codCat: "A244"
        },
        {
            name: "Amaseno",
            codCat: "A256"
        },
        {
            name: "Anagni",
            codCat: "A269"
        },
        {
            name: "Aquino",
            codCat: "A348"
        },
        {
            name: "Arce",
            codCat: "A363"
        },
        {
            name: "Arnara",
            codCat: "A421"
        },
        {
            name: "Arpino",
            codCat: "A433"
        },
        {
            name: "Atina",
            codCat: "A486"
        },
        {
            name: "Ausonia",
            codCat: "A502"
        },
        {
            name: "Belmonte Castello",
            codCat: "A763"
        },
        {
            name: "Boville Ernica",
            codCat: "A720"
        },
        {
            name: "Broccostella",
            codCat: "B195"
        },
        {
            name: "Campoli Appennino",
            codCat: "B543"
        },
        {
            name: "Casalattico",
            codCat: "B862"
        },
        {
            name: "Casalvieri",
            codCat: "B919"
        },
        {
            name: "Cassino",
            codCat: "C034"
        },
        {
            name: "Castelliri",
            codCat: "C177"
        },
        {
            name: "Castelnuovo Parano",
            codCat: "C223"
        },
        {
            name: "Castrocielo",
            codCat: "C340"
        },
        {
            name: "Castro dei Volsci",
            codCat: "C338"
        },
        {
            name: "Ceccano",
            codCat: "C413"
        },
        {
            name: "Ceprano",
            codCat: "C479"
        },
        {
            name: "Cervaro",
            codCat: "C545"
        },
        {
            name: "Colfelice",
            codCat: "C836"
        },
        {
            name: "Collepardo",
            codCat: "C864"
        },
        {
            name: "Colle San Magno",
            codCat: "C870"
        },
        {
            name: "Coreno Ausonio",
            codCat: "C998"
        },
        {
            name: "Esperia",
            codCat: "D440"
        },
        {
            name: "Falvaterra",
            codCat: "D483"
        },
        {
            name: "Ferentino",
            codCat: "D539"
        },
        {
            name: "Filettino",
            codCat: "D591"
        },
        {
            name: "Fiuggi",
            codCat: "A310"
        },
        {
            name: "Fontana Liri",
            codCat: "D667"
        },
        {
            name: "Fontechiari",
            codCat: "D682"
        },
        {
            name: "Frosinone",
            codCat: "D810"
        },
        {
            name: "Fumone",
            codCat: "D819"
        },
        {
            name: "Gallinaro",
            codCat: "D881"
        },
        {
            name: "Giuliano di Roma",
            codCat: "E057"
        },
        {
            name: "Guarcino",
            codCat: "E236"
        },
        {
            name: "Isola del Liri",
            codCat: "E340"
        },
        {
            name: "Monte San Giovanni Campano",
            codCat: "F620"
        },
        {
            name: "Morolo",
            codCat: "F740"
        },
        {
            name: "Paliano",
            codCat: "G276"
        },
        {
            name: "Pastena",
            codCat: "G362"
        },
        {
            name: "Patrica",
            codCat: "G374"
        },
        {
            name: "Pescosolido",
            codCat: "G500"
        },
        {
            name: "Picinisco",
            codCat: "G591"
        },
        {
            name: "Pico",
            codCat: "G592"
        },
        {
            name: "Piedimonte San Germano",
            codCat: "G598"
        },
        {
            name: "Piglio",
            codCat: "G659"
        },
        {
            name: "Pignataro Interamna",
            codCat: "G662"
        },
        {
            name: "Pofi",
            codCat: "G749"
        },
        {
            name: "Pontecorvo",
            codCat: "G838"
        },
        {
            name: "Posta Fibreno",
            codCat: "G935"
        },
        {
            name: "Ripi",
            codCat: "H324"
        },
        {
            name: "Rocca d'Arce",
            codCat: "H393"
        },
        {
            name: "Roccasecca",
            codCat: "H443"
        },
        {
            name: "San Biagio Saracinisco",
            codCat: "H779"
        },
        {
            name: "San Donato Val di Comino",
            codCat: "H824"
        },
        {
            name: "San Giorgio a Liri",
            codCat: "H880"
        },
        {
            name: "San Giovanni Incarico",
            codCat: "H917"
        },
        {
            name: "Sant'Ambrogio sul Garigliano",
            codCat: "I256"
        },
        {
            name: "Sant'Andrea del Garigliano",
            codCat: "I265"
        },
        {
            name: "Sant'Apollinare",
            codCat: "I302"
        },
        {
            name: "Sant'Elia Fiumerapido",
            codCat: "I321"
        },
        {
            name: "Santopadre",
            codCat: "I351"
        },
        {
            name: "San Vittore del Lazio",
            codCat: "I408"
        },
        {
            name: "Serrone",
            codCat: "I669"
        },
        {
            name: "Settefrati",
            codCat: "I697"
        },
        {
            name: "Sgurgola",
            codCat: "I716"
        },
        {
            name: "Sora",
            codCat: "I838"
        },
        {
            name: "Strangolagalli",
            codCat: "I973"
        },
        {
            name: "Supino",
            codCat: "L009"
        },
        {
            name: "Terelle",
            codCat: "L105"
        },
        {
            name: "Torre Cajetani",
            codCat: "L243"
        },
        {
            name: "Torrice",
            codCat: "L290"
        },
        {
            name: "Trevi nel Lazio",
            codCat: "L398"
        },
        {
            name: "Trivigliano",
            codCat: "L437"
        },
        {
            name: "Vallecorsa",
            codCat: "L598"
        },
        {
            name: "Vallemaio",
            codCat: "L605"
        },
        {
            name: "Vallerotonda",
            codCat: "L614"
        },
        {
            name: "Veroli",
            codCat: "L780"
        },
        {
            name: "Vicalvi",
            codCat: "L836"
        },
        {
            name: "Vico nel Lazio",
            codCat: "L843"
        },
        {
            name: "Villa Latina",
            codCat: "A081"
        },
        {
            name: "Villa Santa Lucia",
            codCat: "L905"
        },
        {
            name: "Villa Santo Stefano",
            codCat: "I364"
        },
        {
            name: "Viticuso",
            codCat: "M083"
        },
        {
            name: "Acciano",
            codCat: "A018"
        },
        {
            name: "Aielli",
            codCat: "A100"
        },
        {
            name: "Alfedena",
            codCat: "A187"
        },
        {
            name: "Anversa degli Abruzzi",
            codCat: "A318"
        },
        {
            name: "Ateleta",
            codCat: "A481"
        },
        {
            name: "Avezzano",
            codCat: "A515"
        },
        {
            name: "Balsorano",
            codCat: "A603"
        },
        {
            name: "Barete",
            codCat: "A656"
        },
        {
            name: "Barisciano",
            codCat: "A667"
        },
        {
            name: "Barrea",
            codCat: "A678"
        },
        {
            name: "Bisegna",
            codCat: "A884"
        },
        {
            name: "Bugnara",
            codCat: "B256"
        },
        {
            name: "Cagnano Amiterno",
            codCat: "B358"
        },
        {
            name: "Calascio",
            codCat: "B382"
        },
        {
            name: "Campo di Giove",
            codCat: "B526"
        },
        {
            name: "Campotosto",
            codCat: "B569"
        },
        {
            name: "Canistro",
            codCat: "B606"
        },
        {
            name: "Cansano",
            codCat: "B624"
        },
        {
            name: "Capestrano",
            codCat: "B651"
        },
        {
            name: "Capistrello",
            codCat: "B656"
        },
        {
            name: "Capitignano",
            codCat: "B658"
        },
        {
            name: "Caporciano",
            codCat: "B672"
        },
        {
            name: "Cappadocia",
            codCat: "B677"
        },
        {
            name: "Carapelle Calvisio",
            codCat: "B725"
        },
        {
            name: "Carsoli",
            codCat: "B842"
        },
        {
            name: "Castel del Monte",
            codCat: "C083"
        },
        {
            name: "Castel di Ieri",
            codCat: "C090"
        },
        {
            name: "Castel di Sangro",
            codCat: "C096"
        },
        {
            name: "Castellafiume",
            codCat: "C126"
        },
        {
            name: "Castelvecchio Calvisio",
            codCat: "C278"
        },
        {
            name: "Castelvecchio Subequo",
            codCat: "C279"
        },
        {
            name: "Celano",
            codCat: "C426"
        },
        {
            name: "Cerchio",
            codCat: "C492"
        },
        {
            name: "Civita d'Antino",
            codCat: "C766"
        },
        {
            name: "Civitella Alfedena",
            codCat: "C778"
        },
        {
            name: "Civitella Roveto",
            codCat: "C783"
        },
        {
            name: "Cocullo",
            codCat: "C811"
        },
        {
            name: "Collarmele",
            codCat: "C844"
        },
        {
            name: "Collelongo",
            codCat: "C862"
        },
        {
            name: "Collepietro",
            codCat: "C866"
        },
        {
            name: "Corfinio",
            codCat: "C999"
        },
        {
            name: "Fagnano Alto",
            codCat: "D465"
        },
        {
            name: "Fontecchio",
            codCat: "D681"
        },
        {
            name: "Fossa",
            codCat: "D736"
        },
        {
            name: "Gagliano Aterno",
            codCat: "D850"
        },
        {
            name: "Gioia dei Marsi",
            codCat: "E040"
        },
        {
            name: "Goriano Sicoli",
            codCat: "E096"
        },
        {
            name: "Introdacqua",
            codCat: "E307"
        },
        {
            name: "L'Aquila",
            codCat: "A345"
        },
        {
            name: "Lecce nei Marsi",
            codCat: "E505"
        },
        {
            name: "Luco dei Marsi",
            codCat: "E723"
        },
        {
            name: "Lucoli",
            codCat: "E724"
        },
        {
            name: "Magliano de' Marsi",
            codCat: "E811"
        },
        {
            name: "Massa d'Albe",
            codCat: "F022"
        },
        {
            name: "Molina Aterno",
            codCat: "M255"
        },
        {
            name: "Montereale",
            codCat: "F595"
        },
        {
            name: "Morino",
            codCat: "F732"
        },
        {
            name: "Navelli",
            codCat: "F852"
        },
        {
            name: "Ocre",
            codCat: "F996"
        },
        {
            name: "Ofena",
            codCat: "G002"
        },
        {
            name: "Opi",
            codCat: "G079"
        },
        {
            name: "Oricola",
            codCat: "G102"
        },
        {
            name: "Ortona dei Marsi",
            codCat: "G142"
        },
        {
            name: "Ortucchio",
            codCat: "G145"
        },
        {
            name: "Ovindoli",
            codCat: "G200"
        },
        {
            name: "Pacentro",
            codCat: "G210"
        },
        {
            name: "Pereto",
            codCat: "G449"
        },
        {
            name: "Pescasseroli",
            codCat: "G484"
        },
        {
            name: "Pescina",
            codCat: "G492"
        },
        {
            name: "Pescocostanzo",
            codCat: "G493"
        },
        {
            name: "Pettorano sul Gizio",
            codCat: "G524"
        },
        {
            name: "Pizzoli",
            codCat: "G726"
        },
        {
            name: "Poggio Picenze",
            codCat: "G766"
        },
        {
            name: "Prata d'Ansidonia",
            codCat: "G992"
        },
        {
            name: "Pratola Peligna",
            codCat: "H007"
        },
        {
            name: "Prezza",
            codCat: "H056"
        },
        {
            name: "Raiano",
            codCat: "H166"
        },
        {
            name: "Rivisondoli",
            codCat: "H353"
        },
        {
            name: "Roccacasale",
            codCat: "H389"
        },
        {
            name: "Rocca di Botte",
            codCat: "H399"
        },
        {
            name: "Rocca di Cambio",
            codCat: "H400"
        },
        {
            name: "Rocca di Mezzo",
            codCat: "H402"
        },
        {
            name: "Rocca Pia",
            codCat: "H429"
        },
        {
            name: "Roccaraso",
            codCat: "H434"
        },
        {
            name: "San Benedetto dei Marsi",
            codCat: "H772"
        },
        {
            name: "San Benedetto in Perillis",
            codCat: "H773"
        },
        {
            name: "San Demetrio ne' Vestini",
            codCat: "H819"
        },
        {
            name: "San Pio delle Camere",
            codCat: "I121"
        },
        {
            name: "Sante Marie",
            codCat: "I326"
        },
        {
            name: "Sant'Eusanio Forconese",
            codCat: "I336"
        },
        {
            name: "Santo Stefano di Sessanio",
            codCat: "I360"
        },
        {
            name: "San Vincenzo Valle Roveto",
            codCat: "I389"
        },
        {
            name: "Scanno",
            codCat: "I501"
        },
        {
            name: "Scontrone",
            codCat: "I543"
        },
        {
            name: "Scoppito",
            codCat: "I546"
        },
        {
            name: "Scurcola Marsicana",
            codCat: "I553"
        },
        {
            name: "Secinaro",
            codCat: "I558"
        },
        {
            name: "Sulmona",
            codCat: "I804"
        },
        {
            name: "Tagliacozzo",
            codCat: "L025"
        },
        {
            name: "Tione degli Abruzzi",
            codCat: "L173"
        },
        {
            name: "Tornimparte",
            codCat: "L227"
        },
        {
            name: "Trasacco",
            codCat: "L334"
        },
        {
            name: "Villalago",
            codCat: "L958"
        },
        {
            name: "Villa Santa Lucia degli Abruzzi",
            codCat: "M021"
        },
        {
            name: "Villa Sant'Angelo",
            codCat: "M023"
        },
        {
            name: "Villavallelonga",
            codCat: "M031"
        },
        {
            name: "Villetta Barrea",
            codCat: "M041"
        },
        {
            name: "Vittorito",
            codCat: "M090"
        },
        {
            name: "Alba Adriatica",
            codCat: "A125"
        },
        {
            name: "Ancarano",
            codCat: "A270"
        },
        {
            name: "Arsita",
            codCat: "A445"
        },
        {
            name: "Atri",
            codCat: "A488"
        },
        {
            name: "Basciano",
            codCat: "A692"
        },
        {
            name: "Bellante",
            codCat: "A746"
        },
        {
            name: "Bisenti",
            codCat: "A885"
        },
        {
            name: "Campli",
            codCat: "B515"
        },
        {
            name: "Canzano",
            codCat: "B640"
        },
        {
            name: "Castel Castagna",
            codCat: "C040"
        },
        {
            name: "Castellalto",
            codCat: "C128"
        },
        {
            name: "Castelli",
            codCat: "C169"
        },
        {
            name: "Castiglione Messer Raimondo",
            codCat: "C316"
        },
        {
            name: "Castilenti",
            codCat: "C322"
        },
        {
            name: "Cellino Attanasio",
            codCat: "C449"
        },
        {
            name: "Cermignano",
            codCat: "C517"
        },
        {
            name: "Civitella del Tronto",
            codCat: "C781"
        },
        {
            name: "Colledara",
            codCat: "C311"
        },
        {
            name: "Colonnella",
            codCat: "C901"
        },
        {
            name: "Controguerra",
            codCat: "C972"
        },
        {
            name: "Corropoli",
            codCat: "D043"
        },
        {
            name: "Cortino",
            codCat: "D076"
        },
        {
            name: "Crognaleto",
            codCat: "D179"
        },
        {
            name: "Fano Adriano",
            codCat: "D489"
        },
        {
            name: "Giulianova",
            codCat: "E058"
        },
        {
            name: "Isola del Gran Sasso d'Italia",
            codCat: "E343"
        },
        {
            name: "Montefino",
            codCat: "F500"
        },
        {
            name: "Montorio al Vomano",
            codCat: "F690"
        },
        {
            name: "Morro d'Oro",
            codCat: "F747"
        },
        {
            name: "Mosciano Sant'Angelo",
            codCat: "F764"
        },
        {
            name: "Nereto",
            codCat: "F870"
        },
        {
            name: "Notaresco",
            codCat: "F942"
        },
        {
            name: "Penna Sant'Andrea",
            codCat: "G437"
        },
        {
            name: "Pietracamela",
            codCat: "G608"
        },
        {
            name: "Pineto",
            codCat: "F831"
        },
        {
            name: "Rocca Santa Maria",
            codCat: "H440"
        },
        {
            name: "Roseto degli Abruzzi",
            codCat: "F585"
        },
        {
            name: "Sant'Egidio alla Vibrata",
            codCat: "I318"
        },
        {
            name: "Sant'Omero",
            codCat: "I348"
        },
        {
            name: "Silvi",
            codCat: "I741"
        },
        {
            name: "Teramo",
            codCat: "L103"
        },
        {
            name: "Torano Nuovo",
            codCat: "L207"
        },
        {
            name: "Torricella Sicura",
            codCat: "L295"
        },
        {
            name: "Tortoreto",
            codCat: "L307"
        },
        {
            name: "Tossicia",
            codCat: "L314"
        },
        {
            name: "Valle Castellana",
            codCat: "L597"
        },
        {
            name: "Martinsicuro",
            codCat: "E989"
        },
        {
            name: "Abbateggio",
            codCat: "A008"
        },
        {
            name: "Alanno",
            codCat: "A120"
        },
        {
            name: "Bolognano",
            codCat: "A945"
        },
        {
            name: "Brittoli",
            codCat: "B193"
        },
        {
            name: "Bussi sul Tirino",
            codCat: "B294"
        },
        {
            name: "Cappelle sul Tavo",
            codCat: "B681"
        },
        {
            name: "Caramanico Terme",
            codCat: "B722"
        },
        {
            name: "Carpineto della Nora",
            codCat: "B827"
        },
        {
            name: "Castiglione a Casauria",
            codCat: "C308"
        },
        {
            name: "Catignano",
            codCat: "C354"
        },
        {
            name: "Cepagatti",
            codCat: "C474"
        },
        {
            name: "Città Sant'Angelo",
            codCat: "C750"
        },
        {
            name: "Civitaquana",
            codCat: "C771"
        },
        {
            name: "Civitella Casanova",
            codCat: "C779"
        },
        {
            name: "Collecorvino",
            codCat: "C853"
        },
        {
            name: "Corvara",
            codCat: "D078"
        },
        {
            name: "Cugnoli",
            codCat: "D201"
        },
        {
            name: "Elice",
            codCat: "D394"
        },
        {
            name: "Farindola",
            codCat: "D501"
        },
        {
            name: "Lettomanoppello",
            codCat: "E558"
        },
        {
            name: "Loreto Aprutino",
            codCat: "E691"
        },
        {
            name: "Manoppello",
            codCat: "E892"
        },
        {
            name: "Montebello di Bertona",
            codCat: "F441"
        },
        {
            name: "Montesilvano",
            codCat: "F646"
        },
        {
            name: "Moscufo",
            codCat: "F765"
        },
        {
            name: "Nocciano",
            codCat: "F908"
        },
        {
            name: "Penne",
            codCat: "G438"
        },
        {
            name: "Pescara",
            codCat: "G482"
        },
        {
            name: "Pescosansonesco",
            codCat: "G499"
        },
        {
            name: "Pianella",
            codCat: "G555"
        },
        {
            name: "Picciano",
            codCat: "G589"
        },
        {
            name: "Pietranico",
            codCat: "G621"
        },
        {
            name: "Popoli",
            codCat: "G878"
        },
        {
            name: "Roccamorice",
            codCat: "H425"
        },
        {
            name: "Rosciano",
            codCat: "H562"
        },
        {
            name: "Salle",
            codCat: "H715"
        },
        {
            name: "Sant'Eufemia a Maiella",
            codCat: "I332"
        },
        {
            name: "San Valentino in Abruzzo Citeriore",
            codCat: "I376"
        },
        {
            name: "Scafa",
            codCat: "I482"
        },
        {
            name: "Serramonacesca",
            codCat: "I649"
        },
        {
            name: "Spoltore",
            codCat: "I922"
        },
        {
            name: "Tocco da Casauria",
            codCat: "L186"
        },
        {
            name: "Torre de' Passeri",
            codCat: "L263"
        },
        {
            name: "Turrivalignani",
            codCat: "L475"
        },
        {
            name: "Vicoli",
            codCat: "L846"
        },
        {
            name: "Villa Celiera",
            codCat: "L922"
        },
        {
            name: "Altino",
            codCat: "A235"
        },
        {
            name: "Archi",
            codCat: "A367"
        },
        {
            name: "Ari",
            codCat: "A398"
        },
        {
            name: "Arielli",
            codCat: "A402"
        },
        {
            name: "Atessa",
            codCat: "A485"
        },
        {
            name: "Bomba",
            codCat: "A956"
        },
        {
            name: "Borrello",
            codCat: "B057"
        },
        {
            name: "Bucchianico",
            codCat: "B238"
        },
        {
            name: "Montebello sul Sangro",
            codCat: "B268"
        },
        {
            name: "Canosa Sannita",
            codCat: "B620"
        },
        {
            name: "Carpineto Sinello",
            codCat: "B826"
        },
        {
            name: "Carunchio",
            codCat: "B853"
        },
        {
            name: "Casacanditella",
            codCat: "B859"
        },
        {
            name: "Casalanguida",
            codCat: "B861"
        },
        {
            name: "Casalbordino",
            codCat: "B865"
        },
        {
            name: "Casalincontrada",
            codCat: "B896"
        },
        {
            name: "Casoli",
            codCat: "B985"
        },
        {
            name: "Castel Frentano",
            codCat: "C114"
        },
        {
            name: "Castelguidone",
            codCat: "C123"
        },
        {
            name: "Castiglione Messer Marino",
            codCat: "C298"
        },
        {
            name: "Celenza sul Trigno",
            codCat: "C428"
        },
        {
            name: "Chieti",
            codCat: "C632"
        },
        {
            name: "Civitaluparella",
            codCat: "C768"
        },
        {
            name: "Civitella Messer Raimondo",
            codCat: "C776"
        },
        {
            name: "Colledimacine",
            codCat: "C855"
        },
        {
            name: "Colledimezzo",
            codCat: "C856"
        },
        {
            name: "Crecchio",
            codCat: "D137"
        },
        {
            name: "Cupello",
            codCat: "D209"
        },
        {
            name: "Dogliola",
            codCat: "D315"
        },
        {
            name: "Fara Filiorum Petri",
            codCat: "D494"
        },
        {
            name: "Fara San Martino",
            codCat: "D495"
        },
        {
            name: "Filetto",
            codCat: "D592"
        },
        {
            name: "Fossacesia",
            codCat: "D738"
        },
        {
            name: "Fraine",
            codCat: "D757"
        },
        {
            name: "Francavilla al Mare",
            codCat: "D763"
        },
        {
            name: "Fresagrandinaria",
            codCat: "D796"
        },
        {
            name: "Frisa",
            codCat: "D803"
        },
        {
            name: "Furci",
            codCat: "D823"
        },
        {
            name: "Gamberale",
            codCat: "D898"
        },
        {
            name: "Gessopalena",
            codCat: "D996"
        },
        {
            name: "Gissi",
            codCat: "E052"
        },
        {
            name: "Giuliano Teatino",
            codCat: "E056"
        },
        {
            name: "Guardiagrele",
            codCat: "E243"
        },
        {
            name: "Guilmi",
            codCat: "E266"
        },
        {
            name: "Lama dei Peligni",
            codCat: "E424"
        },
        {
            name: "Lanciano",
            codCat: "E435"
        },
        {
            name: "Lentella",
            codCat: "E531"
        },
        {
            name: "Lettopalena",
            codCat: "E559"
        },
        {
            name: "Liscia",
            codCat: "E611"
        },
        {
            name: "Miglianico",
            codCat: "F196"
        },
        {
            name: "Montazzoli",
            codCat: "F433"
        },
        {
            name: "Monteferrante",
            codCat: "F498"
        },
        {
            name: "Montelapiano",
            codCat: "F535"
        },
        {
            name: "Montenerodomo",
            codCat: "F578"
        },
        {
            name: "Monteodorisio",
            codCat: "F582"
        },
        {
            name: "Mozzagrogna",
            codCat: "F785"
        },
        {
            name: "Orsogna",
            codCat: "G128"
        },
        {
            name: "Ortona",
            codCat: "G141"
        },
        {
            name: "Paglieta",
            codCat: "G237"
        },
        {
            name: "Palena",
            codCat: "G271"
        },
        {
            name: "Palmoli",
            codCat: "G290"
        },
        {
            name: "Palombaro",
            codCat: "G294"
        },
        {
            name: "Pennadomo",
            codCat: "G434"
        },
        {
            name: "Pennapiedimonte",
            codCat: "G435"
        },
        {
            name: "Perano",
            codCat: "G441"
        },
        {
            name: "Pizzoferrato",
            codCat: "G724"
        },
        {
            name: "Poggiofiorito",
            codCat: "G760"
        },
        {
            name: "Pollutri",
            codCat: "G799"
        },
        {
            name: "Pretoro",
            codCat: "H052"
        },
        {
            name: "Quadri",
            codCat: "H098"
        },
        {
            name: "Rapino",
            codCat: "H184"
        },
        {
            name: "Ripa Teatina",
            codCat: "H320"
        },
        {
            name: "Roccamontepiano",
            codCat: "H424"
        },
        {
            name: "Rocca San Giovanni",
            codCat: "H439"
        },
        {
            name: "Roccascalegna",
            codCat: "H442"
        },
        {
            name: "Roccaspinalveti",
            codCat: "H448"
        },
        {
            name: "Roio del Sangro",
            codCat: "H495"
        },
        {
            name: "Rosello",
            codCat: "H566"
        },
        {
            name: "San Buono",
            codCat: "H784"
        },
        {
            name: "San Giovanni Lipioni",
            codCat: "H923"
        },
        {
            name: "San Giovanni Teatino",
            codCat: "D690"
        },
        {
            name: "San Martino sulla Marrucina",
            codCat: "H991"
        },
        {
            name: "San Salvo",
            codCat: "I148"
        },
        {
            name: "Santa Maria Imbaro",
            codCat: "I244"
        },
        {
            name: "Sant'Eusanio del Sangro",
            codCat: "I335"
        },
        {
            name: "San Vito Chietino",
            codCat: "I394"
        },
        {
            name: "Scerni",
            codCat: "I520"
        },
        {
            name: "Schiavi di Abruzzo",
            codCat: "I526"
        },
        {
            name: "Taranta Peligna",
            codCat: "L047"
        },
        {
            name: "Tollo",
            codCat: "L194"
        },
        {
            name: "Torino di Sangro",
            codCat: "L218"
        },
        {
            name: "Tornareccio",
            codCat: "L224"
        },
        {
            name: "Torrebruna",
            codCat: "L253"
        },
        {
            name: "Torrevecchia Teatina",
            codCat: "L284"
        },
        {
            name: "Torricella Peligna",
            codCat: "L291"
        },
        {
            name: "Treglio",
            codCat: "L363"
        },
        {
            name: "Tufillo",
            codCat: "L459"
        },
        {
            name: "Vacri",
            codCat: "L526"
        },
        {
            name: "Vasto",
            codCat: "E372"
        },
        {
            name: "Villalfonsina",
            codCat: "L961"
        },
        {
            name: "Villamagna",
            codCat: "L964"
        },
        {
            name: "Villa Santa Maria",
            codCat: "M022"
        },
        {
            name: "Pietraferrazzana",
            codCat: "G613"
        },
        {
            name: "Fallo",
            codCat: "D480"
        },
        {
            name: "Acquaviva Collecroce",
            codCat: "A050"
        },
        {
            name: "Baranello",
            codCat: "A616"
        },
        {
            name: "Bojano",
            codCat: "A930"
        },
        {
            name: "Bonefro",
            codCat: "A971"
        },
        {
            name: "Busso",
            codCat: "B295"
        },
        {
            name: "Campobasso",
            codCat: "B519"
        },
        {
            name: "Campochiaro",
            codCat: "B522"
        },
        {
            name: "Campodipietra",
            codCat: "B528"
        },
        {
            name: "Campolieto",
            codCat: "B544"
        },
        {
            name: "Campomarino",
            codCat: "B550"
        },
        {
            name: "Casacalenda",
            codCat: "B858"
        },
        {
            name: "Casalciprano",
            codCat: "B871"
        },
        {
            name: "Castelbottaccio",
            codCat: "C066"
        },
        {
            name: "Castellino del Biferno",
            codCat: "C175"
        },
        {
            name: "Castelmauro",
            codCat: "C197"
        },
        {
            name: "Castropignano",
            codCat: "C346"
        },
        {
            name: "Cercemaggiore",
            codCat: "C486"
        },
        {
            name: "Cercepiccola",
            codCat: "C488"
        },
        {
            name: "Civitacampomarano",
            codCat: "C764"
        },
        {
            name: "Colle d'Anchise",
            codCat: "C854"
        },
        {
            name: "Colletorto",
            codCat: "C875"
        },
        {
            name: "Duronia",
            codCat: "C772"
        },
        {
            name: "Ferrazzano",
            codCat: "D550"
        },
        {
            name: "Fossalto",
            codCat: "D737"
        },
        {
            name: "Gambatesa",
            codCat: "D896"
        },
        {
            name: "Gildone",
            codCat: "E030"
        },
        {
            name: "Guardialfiera",
            codCat: "E244"
        },
        {
            name: "Guardiaregia",
            codCat: "E248"
        },
        {
            name: "Guglionesi",
            codCat: "E259"
        },
        {
            name: "Jelsi",
            codCat: "E381"
        },
        {
            name: "Larino",
            codCat: "E456"
        },
        {
            name: "Limosano",
            codCat: "E599"
        },
        {
            name: "Lucito",
            codCat: "E722"
        },
        {
            name: "Lupara",
            codCat: "E748"
        },
        {
            name: "Macchia Valfortore",
            codCat: "E780"
        },
        {
            name: "Mafalda",
            codCat: "E799"
        },
        {
            name: "Matrice",
            codCat: "F055"
        },
        {
            name: "Mirabello Sannitico",
            codCat: "F233"
        },
        {
            name: "Molise",
            codCat: "F294"
        },
        {
            name: "Monacilioni",
            codCat: "F322"
        },
        {
            name: "Montagano",
            codCat: "F391"
        },
        {
            name: "Montecilfone",
            codCat: "F475"
        },
        {
            name: "Montefalcone nel Sannio",
            codCat: "F495"
        },
        {
            name: "Montelongo",
            codCat: "F548"
        },
        {
            name: "Montemitro",
            codCat: "F569"
        },
        {
            name: "Montenero di Bisaccia",
            codCat: "F576"
        },
        {
            name: "Montorio nei Frentani",
            codCat: "F689"
        },
        {
            name: "Morrone del Sannio",
            codCat: "F748"
        },
        {
            name: "Oratino",
            codCat: "G086"
        },
        {
            name: "Palata",
            codCat: "G257"
        },
        {
            name: "Petacciato",
            codCat: "G506"
        },
        {
            name: "Petrella Tifernina",
            codCat: "G512"
        },
        {
            name: "Pietracatella",
            codCat: "G609"
        },
        {
            name: "Pietracupa",
            codCat: "G610"
        },
        {
            name: "Portocannone",
            codCat: "G910"
        },
        {
            name: "Provvidenti",
            codCat: "H083"
        },
        {
            name: "Riccia",
            codCat: "H273"
        },
        {
            name: "Ripabottoni",
            codCat: "H311"
        },
        {
            name: "Ripalimosani",
            codCat: "H313"
        },
        {
            name: "Roccavivara",
            codCat: "H454"
        },
        {
            name: "Rotello",
            codCat: "H589"
        },
        {
            name: "Salcito",
            codCat: "H693"
        },
        {
            name: "San Biase",
            codCat: "H782"
        },
        {
            name: "San Felice del Molise",
            codCat: "H833"
        },
        {
            name: "San Giacomo degli Schiavoni",
            codCat: "H867"
        },
        {
            name: "San Giovanni in Galdo",
            codCat: "H920"
        },
        {
            name: "San Giuliano del Sannio",
            codCat: "H928"
        },
        {
            name: "San Giuliano di Puglia",
            codCat: "H929"
        },
        {
            name: "San Martino in Pensilis",
            codCat: "H990"
        },
        {
            name: "San Massimo",
            codCat: "I023"
        },
        {
            name: "San Polo Matese",
            codCat: "I122"
        },
        {
            name: "Santa Croce di Magliano",
            codCat: "I181"
        },
        {
            name: "Sant'Angelo Limosano",
            codCat: "I289"
        },
        {
            name: "Sant'Elia a Pianisi",
            codCat: "I320"
        },
        {
            name: "Sepino",
            codCat: "I618"
        },
        {
            name: "Spinete",
            codCat: "I910"
        },
        {
            name: "Tavenna",
            codCat: "L069"
        },
        {
            name: "Termoli",
            codCat: "L113"
        },
        {
            name: "Torella del Sannio",
            codCat: "L215"
        },
        {
            name: "Toro",
            codCat: "L230"
        },
        {
            name: "Trivento",
            codCat: "L435"
        },
        {
            name: "Tufara",
            codCat: "L458"
        },
        {
            name: "Ururi",
            codCat: "L505"
        },
        {
            name: "Vinchiaturo",
            codCat: "M057"
        },
        {
            name: "Acquaviva d'Isernia",
            codCat: "A051"
        },
        {
            name: "Agnone",
            codCat: "A080"
        },
        {
            name: "Bagnoli del Trigno",
            codCat: "A567"
        },
        {
            name: "Belmonte del Sannio",
            codCat: "A761"
        },
        {
            name: "Cantalupo nel Sannio",
            codCat: "B630"
        },
        {
            name: "Capracotta",
            codCat: "B682"
        },
        {
            name: "Carovilli",
            codCat: "B810"
        },
        {
            name: "Carpinone",
            codCat: "B830"
        },
        {
            name: "Castel del Giudice",
            codCat: "C082"
        },
        {
            name: "Castelpetroso",
            codCat: "C246"
        },
        {
            name: "Castelpizzuto",
            codCat: "C247"
        },
        {
            name: "Castel San Vincenzo",
            codCat: "C270"
        },
        {
            name: "Castelverrino",
            codCat: "C200"
        },
        {
            name: "Cerro al Volturno",
            codCat: "C534"
        },
        {
            name: "Chiauci",
            codCat: "C620"
        },
        {
            name: "Civitanova del Sannio",
            codCat: "C769"
        },
        {
            name: "Colli a Volturno",
            codCat: "C878"
        },
        {
            name: "Conca Casale",
            codCat: "C941"
        },
        {
            name: "Filignano",
            codCat: "D595"
        },
        {
            name: "Forlì del Sannio",
            codCat: "D703"
        },
        {
            name: "Fornelli",
            codCat: "D715"
        },
        {
            name: "Frosolone",
            codCat: "D811"
        },
        {
            name: "Isernia",
            codCat: "E335"
        },
        {
            name: "Longano",
            codCat: "E669"
        },
        {
            name: "Macchia d'Isernia",
            codCat: "E778"
        },
        {
            name: "Macchiagodena",
            codCat: "E779"
        },
        {
            name: "Miranda",
            codCat: "F239"
        },
        {
            name: "Montaquila",
            codCat: "F429"
        },
        {
            name: "Montenero Val Cocchiara",
            codCat: "F580"
        },
        {
            name: "Monteroduni",
            codCat: "F601"
        },
        {
            name: "Pesche",
            codCat: "G486"
        },
        {
            name: "Pescolanciano",
            codCat: "G495"
        },
        {
            name: "Pescopennataro",
            codCat: "G497"
        },
        {
            name: "Pettoranello del Molise",
            codCat: "G523"
        },
        {
            name: "Pietrabbondante",
            codCat: "G606"
        },
        {
            name: "Pizzone",
            codCat: "G727"
        },
        {
            name: "Poggio Sannita",
            codCat: "B317"
        },
        {
            name: "Pozzilli",
            codCat: "G954"
        },
        {
            name: "Rionero Sannitico",
            codCat: "H308"
        },
        {
            name: "Roccamandolfi",
            codCat: "H420"
        },
        {
            name: "Roccasicura",
            codCat: "H445"
        },
        {
            name: "Rocchetta a Volturno",
            codCat: "H458"
        },
        {
            name: "San Pietro Avellana",
            codCat: "I096"
        },
        {
            name: "Sant'Agapito",
            codCat: "I189"
        },
        {
            name: "Santa Maria del Molise",
            codCat: "I238"
        },
        {
            name: "Sant'Angelo del Pesco",
            codCat: "I282"
        },
        {
            name: "Sant'Elena Sannita",
            codCat: "B466"
        },
        {
            name: "Scapoli",
            codCat: "I507"
        },
        {
            name: "Sessano del Molise",
            codCat: "I679"
        },
        {
            name: "Sesto Campano",
            codCat: "I682"
        },
        {
            name: "Vastogirardi",
            codCat: "L696"
        },
        {
            name: "Venafro",
            codCat: "L725"
        },
        {
            name: "Ailano",
            codCat: "A106"
        },
        {
            name: "Alife",
            codCat: "A200"
        },
        {
            name: "Alvignano",
            codCat: "A243"
        },
        {
            name: "Arienzo",
            codCat: "A403"
        },
        {
            name: "Aversa",
            codCat: "A512"
        },
        {
            name: "Baia e Latina",
            codCat: "A579"
        },
        {
            name: "Bellona",
            codCat: "A755"
        },
        {
            name: "Caianello",
            codCat: "B361"
        },
        {
            name: "Caiazzo",
            codCat: "B362"
        },
        {
            name: "Calvi Risorta",
            codCat: "B445"
        },
        {
            name: "Camigliano",
            codCat: "B477"
        },
        {
            name: "Cancello ed Arnone",
            codCat: "B581"
        },
        {
            name: "Capodrise",
            codCat: "B667"
        },
        {
            name: "Capriati a Volturno",
            codCat: "B704"
        },
        {
            name: "Capua",
            codCat: "B715"
        },
        {
            name: "Carinaro",
            codCat: "B779"
        },
        {
            name: "Carinola",
            codCat: "B781"
        },
        {
            name: "Casagiove",
            codCat: "B860"
        },
        {
            name: "Casal di Principe",
            codCat: "B872"
        },
        {
            name: "Casaluce",
            codCat: "B916"
        },
        {
            name: "Casapulla",
            codCat: "B935"
        },
        {
            name: "Caserta",
            codCat: "B963"
        },
        {
            name: "Castel Campagnano",
            codCat: "B494"
        },
        {
            name: "Castel di Sasso",
            codCat: "C097"
        },
        {
            name: "Castello del Matese",
            codCat: "C178"
        },
        {
            name: "Castel Morrone",
            codCat: "C211"
        },
        {
            name: "Castel Volturno",
            codCat: "C291"
        },
        {
            name: "Cervino",
            codCat: "C558"
        },
        {
            name: "Cesa",
            codCat: "C561"
        },
        {
            name: "Ciorlano",
            codCat: "C716"
        },
        {
            name: "Conca della Campania",
            codCat: "C939"
        },
        {
            name: "Curti",
            codCat: "D228"
        },
        {
            name: "Dragoni",
            codCat: "D361"
        },
        {
            name: "Fontegreca",
            codCat: "D683"
        },
        {
            name: "Formicola",
            codCat: "D709"
        },
        {
            name: "Francolise",
            codCat: "D769"
        },
        {
            name: "Frignano",
            codCat: "D799"
        },
        {
            name: "Gallo Matese",
            codCat: "D884"
        },
        {
            name: "Galluccio",
            codCat: "D886"
        },
        {
            name: "Giano Vetusto",
            codCat: "E011"
        },
        {
            name: "Gioia Sannitica",
            codCat: "E039"
        },
        {
            name: "Grazzanise",
            codCat: "E158"
        },
        {
            name: "Gricignano di Aversa",
            codCat: "E173"
        },
        {
            name: "Letino",
            codCat: "E554"
        },
        {
            name: "Liberi",
            codCat: "E570"
        },
        {
            name: "Lusciano",
            codCat: "E754"
        },
        {
            name: "Macerata Campania",
            codCat: "E784"
        },
        {
            name: "Maddaloni",
            codCat: "E791"
        },
        {
            name: "Marcianise",
            codCat: "E932"
        },
        {
            name: "Marzano Appio",
            codCat: "E998"
        },
        {
            name: "Mignano Monte Lungo",
            codCat: "F203"
        },
        {
            name: "Mondragone",
            codCat: "F352"
        },
        {
            name: "Orta di Atella",
            codCat: "G130"
        },
        {
            name: "Parete",
            codCat: "G333"
        },
        {
            name: "Pastorano",
            codCat: "G364"
        },
        {
            name: "Piana di Monte Verna",
            codCat: "G541"
        },
        {
            name: "Piedimonte Matese",
            codCat: "G596"
        },
        {
            name: "Pietramelara",
            codCat: "G620"
        },
        {
            name: "Pietravairano",
            codCat: "G630"
        },
        {
            name: "Pignataro Maggiore",
            codCat: "G661"
        },
        {
            name: "Pontelatone",
            codCat: "G849"
        },
        {
            name: "Portico di Caserta",
            codCat: "G903"
        },
        {
            name: "Prata Sannita",
            codCat: "G991"
        },
        {
            name: "Pratella",
            codCat: "G995"
        },
        {
            name: "Presenzano",
            codCat: "H045"
        },
        {
            name: "Raviscanina",
            codCat: "H202"
        },
        {
            name: "Recale",
            codCat: "H210"
        },
        {
            name: "Riardo",
            codCat: "H268"
        },
        {
            name: "Rocca d'Evandro",
            codCat: "H398"
        },
        {
            name: "Roccamonfina",
            codCat: "H423"
        },
        {
            name: "Roccaromana",
            codCat: "H436"
        },
        {
            name: "Rocchetta e Croce",
            codCat: "H459"
        },
        {
            name: "Ruviano",
            codCat: "H165"
        },
        {
            name: "San Cipriano d'Aversa",
            codCat: "H798"
        },
        {
            name: "San Felice a Cancello",
            codCat: "H834"
        },
        {
            name: "San Gregorio Matese",
            codCat: "H939"
        },
        {
            name: "San Marcellino",
            codCat: "H978"
        },
        {
            name: "San Nicola la Strada",
            codCat: "I056"
        },
        {
            name: "San Pietro Infine",
            codCat: "I113"
        },
        {
            name: "San Potito Sannitico",
            codCat: "I130"
        },
        {
            name: "San Prisco",
            codCat: "I131"
        },
        {
            name: "Santa Maria a Vico",
            codCat: "I233"
        },
        {
            name: "Santa Maria Capua Vetere",
            codCat: "I234"
        },
        {
            name: "Santa Maria la Fossa",
            codCat: "I247"
        },
        {
            name: "San Tammaro",
            codCat: "I261"
        },
        {
            name: "Sant'Angelo d'Alife",
            codCat: "I273"
        },
        {
            name: "Sant'Arpino",
            codCat: "I306"
        },
        {
            name: "Sessa Aurunca",
            codCat: "I676"
        },
        {
            name: "Sparanise",
            codCat: "I885"
        },
        {
            name: "Succivo",
            codCat: "I993"
        },
        {
            name: "Teano",
            codCat: "L083"
        },
        {
            name: "Teverola",
            codCat: "L155"
        },
        {
            name: "Tora e Piccilli",
            codCat: "L205"
        },
        {
            name: "Trentola Ducenta",
            codCat: "L379"
        },
        {
            name: "Vairano Patenora",
            codCat: "L540"
        },
        {
            name: "Valle Agricola",
            codCat: "L594"
        },
        {
            name: "Valle di Maddaloni",
            codCat: "L591"
        },
        {
            name: "Villa di Briano",
            codCat: "D801"
        },
        {
            name: "Villa Literno",
            codCat: "L844"
        },
        {
            name: "Vitulazio",
            codCat: "M092"
        },
        {
            name: "Falciano del Massico",
            codCat: "D471"
        },
        {
            name: "Cellole",
            codCat: "M262"
        },
        {
            name: "Casapesenna",
            codCat: "M260"
        },
        {
            name: "San Marco Evangelista",
            codCat: "F043"
        },
        {
            name: "Airola",
            codCat: "A110"
        },
        {
            name: "Amorosi",
            codCat: "A265"
        },
        {
            name: "Apice",
            codCat: "A328"
        },
        {
            name: "Apollosa",
            codCat: "A330"
        },
        {
            name: "Arpaia",
            codCat: "A431"
        },
        {
            name: "Arpaise",
            codCat: "A432"
        },
        {
            name: "Baselice",
            codCat: "A696"
        },
        {
            name: "Benevento",
            codCat: "A783"
        },
        {
            name: "Bonea",
            codCat: "A970"
        },
        {
            name: "Bucciano",
            codCat: "B239"
        },
        {
            name: "Buonalbergo",
            codCat: "B267"
        },
        {
            name: "Calvi",
            codCat: "B444"
        },
        {
            name: "Campolattaro",
            codCat: "B541"
        },
        {
            name: "Campoli del Monte Taburno",
            codCat: "B542"
        },
        {
            name: "Casalduni",
            codCat: "B873"
        },
        {
            name: "Castelfranco in Miscano",
            codCat: "C106"
        },
        {
            name: "Castelpagano",
            codCat: "C245"
        },
        {
            name: "Castelpoto",
            codCat: "C250"
        },
        {
            name: "Castelvenere",
            codCat: "C280"
        },
        {
            name: "Castelvetere in Val Fortore",
            codCat: "C284"
        },
        {
            name: "Cautano",
            codCat: "C359"
        },
        {
            name: "Ceppaloni",
            codCat: "C476"
        },
        {
            name: "Cerreto Sannita",
            codCat: "C525"
        },
        {
            name: "Circello",
            codCat: "C719"
        },
        {
            name: "Colle Sannita",
            codCat: "C846"
        },
        {
            name: "Cusano Mutri",
            codCat: "D230"
        },
        {
            name: "Dugenta",
            codCat: "D380"
        },
        {
            name: "Durazzano",
            codCat: "D386"
        },
        {
            name: "Faicchio",
            codCat: "D469"
        },
        {
            name: "Foglianise",
            codCat: "D644"
        },
        {
            name: "Foiano di Val Fortore",
            codCat: "D650"
        },
        {
            name: "Forchia",
            codCat: "D693"
        },
        {
            name: "Fragneto l'Abate",
            codCat: "D755"
        },
        {
            name: "Fragneto Monforte",
            codCat: "D756"
        },
        {
            name: "Frasso Telesino",
            codCat: "D784"
        },
        {
            name: "Ginestra degli Schiavoni",
            codCat: "E034"
        },
        {
            name: "Guardia Sanframondi",
            codCat: "E249"
        },
        {
            name: "Limatola",
            codCat: "E589"
        },
        {
            name: "Melizzano",
            codCat: "F113"
        },
        {
            name: "Moiano",
            codCat: "F274"
        },
        {
            name: "Molinara",
            codCat: "F287"
        },
        {
            name: "Montefalcone di Val Fortore",
            codCat: "F494"
        },
        {
            name: "Montesarchio",
            codCat: "F636"
        },
        {
            name: "Morcone",
            codCat: "F717"
        },
        {
            name: "Paduli",
            codCat: "G227"
        },
        {
            name: "Pago Veiano",
            codCat: "G243"
        },
        {
            name: "Pannarano",
            codCat: "G311"
        },
        {
            name: "Paolisi",
            codCat: "G318"
        },
        {
            name: "Paupisi",
            codCat: "G386"
        },
        {
            name: "Pesco Sannita",
            codCat: "G494"
        },
        {
            name: "Pietraroja",
            codCat: "G626"
        },
        {
            name: "Pietrelcina",
            codCat: "G631"
        },
        {
            name: "Ponte",
            codCat: "G827"
        },
        {
            name: "Pontelandolfo",
            codCat: "G848"
        },
        {
            name: "Puglianello",
            codCat: "H087"
        },
        {
            name: "Reino",
            codCat: "H227"
        },
        {
            name: "San Bartolomeo in Galdo",
            codCat: "H764"
        },
        {
            name: "San Giorgio del Sannio",
            codCat: "H894"
        },
        {
            name: "San Giorgio La Molara",
            codCat: "H898"
        },
        {
            name: "San Leucio del Sannio",
            codCat: "H953"
        },
        {
            name: "San Lorenzello",
            codCat: "H955"
        },
        {
            name: "San Lorenzo Maggiore",
            codCat: "H967"
        },
        {
            name: "San Lupo",
            codCat: "H973"
        },
        {
            name: "San Marco dei Cavoti",
            codCat: "H984"
        },
        {
            name: "San Martino Sannita",
            codCat: "I002"
        },
        {
            name: "San Nazzaro",
            codCat: "I049"
        },
        {
            name: "San Nicola Manfredi",
            codCat: "I062"
        },
        {
            name: "San Salvatore Telesino",
            codCat: "I145"
        },
        {
            name: "Santa Croce del Sannio",
            codCat: "I179"
        },
        {
            name: "Sant'Agata de' Goti",
            codCat: "I197"
        },
        {
            name: "Sant'Angelo a Cupolo",
            codCat: "I277"
        },
        {
            name: "Sassinoro",
            codCat: "I455"
        },
        {
            name: "Solopaca",
            codCat: "I809"
        },
        {
            name: "Telese Terme",
            codCat: "L086"
        },
        {
            name: "Tocco Caudio",
            codCat: "L185"
        },
        {
            name: "Torrecuso",
            codCat: "L254"
        },
        {
            name: "Vitulano",
            codCat: "M093"
        },
        {
            name: "Sant'Arcangelo Trimonte",
            codCat: "F557"
        },
        {
            name: "Acerra",
            codCat: "A024"
        },
        {
            name: "Afragola",
            codCat: "A064"
        },
        {
            name: "Agerola",
            codCat: "A068"
        },
        {
            name: "Anacapri",
            codCat: "A268"
        },
        {
            name: "Arzano",
            codCat: "A455"
        },
        {
            name: "Bacoli",
            codCat: "A535"
        },
        {
            name: "Barano d'Ischia",
            codCat: "A617"
        },
        {
            name: "Boscoreale",
            codCat: "B076"
        },
        {
            name: "Boscotrecase",
            codCat: "B077"
        },
        {
            name: "Brusciano",
            codCat: "B227"
        },
        {
            name: "Caivano",
            codCat: "B371"
        },
        {
            name: "Calvizzano",
            codCat: "B452"
        },
        {
            name: "Camposano",
            codCat: "B565"
        },
        {
            name: "Capri",
            codCat: "B696"
        },
        {
            name: "Carbonara di Nola",
            codCat: "B740"
        },
        {
            name: "Cardito",
            codCat: "B759"
        },
        {
            name: "Casalnuovo di Napoli",
            codCat: "B905"
        },
        {
            name: "Casamarciano",
            codCat: "B922"
        },
        {
            name: "Casamicciola Terme",
            codCat: "B924"
        },
        {
            name: "Casandrino",
            codCat: "B925"
        },
        {
            name: "Casavatore",
            codCat: "B946"
        },
        {
            name: "Casola di Napoli",
            codCat: "B980"
        },
        {
            name: "Casoria",
            codCat: "B990"
        },
        {
            name: "Castellammare di Stabia",
            codCat: "C129"
        },
        {
            name: "Castello di Cisterna",
            codCat: "C188"
        },
        {
            name: "Cercola",
            codCat: "C495"
        },
        {
            name: "Cicciano",
            codCat: "C675"
        },
        {
            name: "Cimitile",
            codCat: "C697"
        },
        {
            name: "Comiziano",
            codCat: "C929"
        },
        {
            name: "Crispano",
            codCat: "D170"
        },
        {
            name: "Forio",
            codCat: "D702"
        },
        {
            name: "Frattamaggiore",
            codCat: "D789"
        },
        {
            name: "Frattaminore",
            codCat: "D790"
        },
        {
            name: "Giugliano in Campania",
            codCat: "E054"
        },
        {
            name: "Gragnano",
            codCat: "E131"
        },
        {
            name: "Grumo Nevano",
            codCat: "E224"
        },
        {
            name: "Ischia",
            codCat: "E329"
        },
        {
            name: "Lacco Ameno",
            codCat: "E396"
        },
        {
            name: "Lettere",
            codCat: "E557"
        },
        {
            name: "Liveri",
            codCat: "E620"
        },
        {
            name: "Marano di Napoli",
            codCat: "E906"
        },
        {
            name: "Mariglianella",
            codCat: "E954"
        },
        {
            name: "Marigliano",
            codCat: "E955"
        },
        {
            name: "Massa Lubrense",
            codCat: "F030"
        },
        {
            name: "Melito di Napoli",
            codCat: "F111"
        },
        {
            name: "Meta",
            codCat: "F162"
        },
        {
            name: "Monte di Procida",
            codCat: "F488"
        },
        {
            name: "Mugnano di Napoli",
            codCat: "F799"
        },
        {
            name: "Napoli",
            codCat: "F839"
        },
        {
            name: "Nola",
            codCat: "F924"
        },
        {
            name: "Ottaviano",
            codCat: "G190"
        },
        {
            name: "Palma Campania",
            codCat: "G283"
        },
        {
            name: "Piano di Sorrento",
            codCat: "G568"
        },
        {
            name: "Pimonte",
            codCat: "G670"
        },
        {
            name: "Poggiomarino",
            codCat: "G762"
        },
        {
            name: "Pollena Trocchia",
            codCat: "G795"
        },
        {
            name: "Pomigliano d'Arco",
            codCat: "G812"
        },
        {
            name: "Pompei",
            codCat: "G813"
        },
        {
            name: "Portici",
            codCat: "G902"
        },
        {
            name: "Pozzuoli",
            codCat: "G964"
        },
        {
            name: "Procida",
            codCat: "H072"
        },
        {
            name: "Qualiano",
            codCat: "H101"
        },
        {
            name: "Quarto",
            codCat: "H114"
        },
        {
            name: "Ercolano",
            codCat: "H243"
        },
        {
            name: "Roccarainola",
            codCat: "H433"
        },
        {
            name: "San Gennaro Vesuviano",
            codCat: "H860"
        },
        {
            name: "San Giorgio a Cremano",
            codCat: "H892"
        },
        {
            name: "San Giuseppe Vesuviano",
            codCat: "H931"
        },
        {
            name: "San Paolo Bel Sito",
            codCat: "I073"
        },
        {
            name: "San Sebastiano al Vesuvio",
            codCat: "I151"
        },
        {
            name: "Sant'Agnello",
            codCat: "I208"
        },
        {
            name: "Sant'Anastasia",
            codCat: "I262"
        },
        {
            name: "Sant'Antimo",
            codCat: "I293"
        },
        {
            name: "Sant'Antonio Abate",
            codCat: "I300"
        },
        {
            name: "San Vitaliano",
            codCat: "I391"
        },
        {
            name: "Saviano",
            codCat: "I469"
        },
        {
            name: "Scisciano",
            codCat: "I540"
        },
        {
            name: "Serrara Fontana",
            codCat: "I652"
        },
        {
            name: "Somma Vesuviana",
            codCat: "I820"
        },
        {
            name: "Sorrento",
            codCat: "I862"
        },
        {
            name: "Striano",
            codCat: "I978"
        },
        {
            name: "Terzigno",
            codCat: "L142"
        },
        {
            name: "Torre Annunziata",
            codCat: "L245"
        },
        {
            name: "Torre del Greco",
            codCat: "L259"
        },
        {
            name: "Tufino",
            codCat: "L460"
        },
        {
            name: "Vico Equense",
            codCat: "L845"
        },
        {
            name: "Villaricca",
            codCat: "G309"
        },
        {
            name: "Visciano",
            codCat: "M072"
        },
        {
            name: "Volla",
            codCat: "M115"
        },
        {
            name: "Santa Maria la Carità",
            codCat: "M273"
        },
        {
            name: "Trecase",
            codCat: "M280"
        },
        {
            name: "Massa di Somma",
            codCat: "M289"
        },
        {
            name: "Aiello del Sabato",
            codCat: "A101"
        },
        {
            name: "Altavilla Irpina",
            codCat: "A228"
        },
        {
            name: "Andretta",
            codCat: "A284"
        },
        {
            name: "Aquilonia",
            codCat: "A347"
        },
        {
            name: "Ariano Irpino",
            codCat: "A399"
        },
        {
            name: "Atripalda",
            codCat: "A489"
        },
        {
            name: "Avella",
            codCat: "A508"
        },
        {
            name: "Avellino",
            codCat: "A509"
        },
        {
            name: "Bagnoli Irpino",
            codCat: "A566"
        },
        {
            name: "Baiano",
            codCat: "A580"
        },
        {
            name: "Bisaccia",
            codCat: "A881"
        },
        {
            name: "Bonito",
            codCat: "A975"
        },
        {
            name: "Cairano",
            codCat: "B367"
        },
        {
            name: "Calabritto",
            codCat: "B374"
        },
        {
            name: "Calitri",
            codCat: "B415"
        },
        {
            name: "Candida",
            codCat: "B590"
        },
        {
            name: "Caposele",
            codCat: "B674"
        },
        {
            name: "Capriglia Irpina",
            codCat: "B706"
        },
        {
            name: "Carife",
            codCat: "B776"
        },
        {
            name: "Casalbore",
            codCat: "B866"
        },
        {
            name: "Cassano Irpino",
            codCat: "B997"
        },
        {
            name: "Castel Baronia",
            codCat: "C058"
        },
        {
            name: "Castelfranci",
            codCat: "C105"
        },
        {
            name: "Castelvetere sul Calore",
            codCat: "C283"
        },
        {
            name: "Cervinara",
            codCat: "C557"
        },
        {
            name: "Cesinali",
            codCat: "C576"
        },
        {
            name: "Chianche",
            codCat: "C606"
        },
        {
            name: "Chiusano di San Domenico",
            codCat: "C659"
        },
        {
            name: "Contrada",
            codCat: "C971"
        },
        {
            name: "Conza della Campania",
            codCat: "C976"
        },
        {
            name: "Domicella",
            codCat: "D331"
        },
        {
            name: "Flumeri",
            codCat: "D638"
        },
        {
            name: "Fontanarosa",
            codCat: "D671"
        },
        {
            name: "Forino",
            codCat: "D701"
        },
        {
            name: "Frigento",
            codCat: "D798"
        },
        {
            name: "Gesualdo",
            codCat: "D998"
        },
        {
            name: "Greci",
            codCat: "E161"
        },
        {
            name: "Grottaminarda",
            codCat: "E206"
        },
        {
            name: "Grottolella",
            codCat: "E214"
        },
        {
            name: "Guardia Lombardi",
            codCat: "E245"
        },
        {
            name: "Lacedonia",
            codCat: "E397"
        },
        {
            name: "Lapio",
            codCat: "E448"
        },
        {
            name: "Lauro",
            codCat: "E487"
        },
        {
            name: "Lioni",
            codCat: "E605"
        },
        {
            name: "Luogosano",
            codCat: "E746"
        },
        {
            name: "Manocalzati",
            codCat: "E891"
        },
        {
            name: "Marzano di Nola",
            codCat: "E997"
        },
        {
            name: "Melito Irpino",
            codCat: "F110"
        },
        {
            name: "Mercogliano",
            codCat: "F141"
        },
        {
            name: "Mirabella Eclano",
            codCat: "F230"
        },
        {
            name: "Montaguto",
            codCat: "F397"
        },
        {
            name: "Montecalvo Irpino",
            codCat: "F448"
        },
        {
            name: "Montefalcione",
            codCat: "F491"
        },
        {
            name: "Monteforte Irpino",
            codCat: "F506"
        },
        {
            name: "Montefredane",
            codCat: "F511"
        },
        {
            name: "Montefusco",
            codCat: "F512"
        },
        {
            name: "Montella",
            codCat: "F546"
        },
        {
            name: "Montemarano",
            codCat: "F559"
        },
        {
            name: "Montemiletto",
            codCat: "F566"
        },
        {
            name: "Monteverde",
            codCat: "F660"
        },
        {
            name: "Morra De Sanctis",
            codCat: "F744"
        },
        {
            name: "Moschiano",
            codCat: "F762"
        },
        {
            name: "Mugnano del Cardinale",
            codCat: "F798"
        },
        {
            name: "Nusco",
            codCat: "F988"
        },
        {
            name: "Ospedaletto d'Alpinolo",
            codCat: "G165"
        },
        {
            name: "Pago del Vallo di Lauro",
            codCat: "G242"
        },
        {
            name: "Parolise",
            codCat: "G340"
        },
        {
            name: "Paternopoli",
            codCat: "G370"
        },
        {
            name: "Petruro Irpino",
            codCat: "G519"
        },
        {
            name: "Pietradefusi",
            codCat: "G611"
        },
        {
            name: "Pietrastornina",
            codCat: "G629"
        },
        {
            name: "Prata di Principato Ultra",
            codCat: "G990"
        },
        {
            name: "Pratola Serra",
            codCat: "H006"
        },
        {
            name: "Quadrelle",
            codCat: "H097"
        },
        {
            name: "Quindici",
            codCat: "H128"
        },
        {
            name: "Roccabascerana",
            codCat: "H382"
        },
        {
            name: "Rocca San Felice",
            codCat: "H438"
        },
        {
            name: "Rotondi",
            codCat: "H592"
        },
        {
            name: "Salza Irpina",
            codCat: "H733"
        },
        {
            name: "San Mango sul Calore",
            codCat: "H975"
        },
        {
            name: "San Martino Valle Caudina",
            codCat: "I016"
        },
        {
            name: "San Michele di Serino",
            codCat: "I034"
        },
        {
            name: "San Nicola Baronia",
            codCat: "I061"
        },
        {
            name: "San Potito Ultra",
            codCat: "I129"
        },
        {
            name: "San Sossio Baronia",
            codCat: "I163"
        },
        {
            name: "Santa Lucia di Serino",
            codCat: "I219"
        },
        {
            name: "Sant'Andrea di Conza",
            codCat: "I264"
        },
        {
            name: "Sant'Angelo all'Esca",
            codCat: "I279"
        },
        {
            name: "Sant'Angelo a Scala",
            codCat: "I280"
        },
        {
            name: "Sant'Angelo dei Lombardi",
            codCat: "I281"
        },
        {
            name: "Santa Paolina",
            codCat: "I301"
        },
        {
            name: "Santo Stefano del Sole",
            codCat: "I357"
        },
        {
            name: "Savignano Irpino",
            codCat: "I471"
        },
        {
            name: "Scampitella",
            codCat: "I493"
        },
        {
            name: "Senerchia",
            codCat: "I606"
        },
        {
            name: "Serino",
            codCat: "I630"
        },
        {
            name: "Sirignano",
            codCat: "I756"
        },
        {
            name: "Solofra",
            codCat: "I805"
        },
        {
            name: "Sorbo Serpico",
            codCat: "I843"
        },
        {
            name: "Sperone",
            codCat: "I893"
        },
        {
            name: "Sturno",
            codCat: "I990"
        },
        {
            name: "Summonte",
            codCat: "L004"
        },
        {
            name: "Taurano",
            codCat: "L061"
        },
        {
            name: "Taurasi",
            codCat: "L062"
        },
        {
            name: "Teora",
            codCat: "L102"
        },
        {
            name: "Torella dei Lombardi",
            codCat: "L214"
        },
        {
            name: "Torre Le Nocelle",
            codCat: "L272"
        },
        {
            name: "Torrioni",
            codCat: "L301"
        },
        {
            name: "Trevico",
            codCat: "L399"
        },
        {
            name: "Tufo",
            codCat: "L461"
        },
        {
            name: "Vallata",
            codCat: "L589"
        },
        {
            name: "Vallesaccarda",
            codCat: "L616"
        },
        {
            name: "Venticano",
            codCat: "L739"
        },
        {
            name: "Villamaina",
            codCat: "L965"
        },
        {
            name: "Villanova del Battista",
            codCat: "L973"
        },
        {
            name: "Volturara Irpina",
            codCat: "M130"
        },
        {
            name: "Zungoli",
            codCat: "M203"
        },
        {
            name: "Montoro",
            codCat: "M330"
        },
        {
            name: "Acerno",
            codCat: "A023"
        },
        {
            name: "Agropoli",
            codCat: "A091"
        },
        {
            name: "Albanella",
            codCat: "A128"
        },
        {
            name: "Alfano",
            codCat: "A186"
        },
        {
            name: "Altavilla Silentina",
            codCat: "A230"
        },
        {
            name: "Amalfi",
            codCat: "A251"
        },
        {
            name: "Angri",
            codCat: "A294"
        },
        {
            name: "Aquara",
            codCat: "A343"
        },
        {
            name: "Ascea",
            codCat: "A460"
        },
        {
            name: "Atena Lucana",
            codCat: "A484"
        },
        {
            name: "Atrani",
            codCat: "A487"
        },
        {
            name: "Auletta",
            codCat: "A495"
        },
        {
            name: "Baronissi",
            codCat: "A674"
        },
        {
            name: "Battipaglia",
            codCat: "A717"
        },
        {
            name: "Bellosguardo",
            codCat: "A756"
        },
        {
            name: "Bracigliano",
            codCat: "B115"
        },
        {
            name: "Buccino",
            codCat: "B242"
        },
        {
            name: "Buonabitacolo",
            codCat: "B266"
        },
        {
            name: "Caggiano",
            codCat: "B351"
        },
        {
            name: "Calvanico",
            codCat: "B437"
        },
        {
            name: "Camerota",
            codCat: "B476"
        },
        {
            name: "Campagna",
            codCat: "B492"
        },
        {
            name: "Campora",
            codCat: "B555"
        },
        {
            name: "Cannalonga",
            codCat: "B608"
        },
        {
            name: "Capaccio Paestum",
            codCat: "B644"
        },
        {
            name: "Casalbuono",
            codCat: "B868"
        },
        {
            name: "Casaletto Spartano",
            codCat: "B888"
        },
        {
            name: "Casal Velino",
            codCat: "B895"
        },
        {
            name: "Caselle in Pittari",
            codCat: "B959"
        },
        {
            name: "Castelcivita",
            codCat: "C069"
        },
        {
            name: "Castellabate",
            codCat: "C125"
        },
        {
            name: "Castelnuovo Cilento",
            codCat: "C231"
        },
        {
            name: "Castelnuovo di Conza",
            codCat: "C235"
        },
        {
            name: "Castel San Giorgio",
            codCat: "C259"
        },
        {
            name: "Castel San Lorenzo",
            codCat: "C262"
        },
        {
            name: "Castiglione del Genovesi",
            codCat: "C306"
        },
        {
            name: "Cava de' Tirreni",
            codCat: "C361"
        },
        {
            name: "Celle di Bulgheria",
            codCat: "C444"
        },
        {
            name: "Centola",
            codCat: "C470"
        },
        {
            name: "Ceraso",
            codCat: "C485"
        },
        {
            name: "Cetara",
            codCat: "C584"
        },
        {
            name: "Cicerale",
            codCat: "C676"
        },
        {
            name: "Colliano",
            codCat: "C879"
        },
        {
            name: "Conca dei Marini",
            codCat: "C940"
        },
        {
            name: "Controne",
            codCat: "C973"
        },
        {
            name: "Contursi Terme",
            codCat: "C974"
        },
        {
            name: "Corbara",
            codCat: "C984"
        },
        {
            name: "Corleto Monforte",
            codCat: "D011"
        },
        {
            name: "Cuccaro Vetere",
            codCat: "D195"
        },
        {
            name: "Eboli",
            codCat: "D390"
        },
        {
            name: "Felitto",
            codCat: "D527"
        },
        {
            name: "Fisciano",
            codCat: "D615"
        },
        {
            name: "Furore",
            codCat: "D826"
        },
        {
            name: "Futani",
            codCat: "D832"
        },
        {
            name: "Giffoni Sei Casali",
            codCat: "E026"
        },
        {
            name: "Giffoni Valle Piana",
            codCat: "E027"
        },
        {
            name: "Gioi",
            codCat: "E037"
        },
        {
            name: "Giungano",
            codCat: "E060"
        },
        {
            name: "Ispani",
            codCat: "E365"
        },
        {
            name: "Laureana Cilento",
            codCat: "E480"
        },
        {
            name: "Laurino",
            codCat: "E485"
        },
        {
            name: "Laurito",
            codCat: "E486"
        },
        {
            name: "Laviano",
            codCat: "E498"
        },
        {
            name: "Lustra",
            codCat: "E767"
        },
        {
            name: "Magliano Vetere",
            codCat: "E814"
        },
        {
            name: "Maiori",
            codCat: "E839"
        },
        {
            name: "Mercato San Severino",
            codCat: "F138"
        },
        {
            name: "Minori",
            codCat: "F223"
        },
        {
            name: "Moio della Civitella",
            codCat: "F278"
        },
        {
            name: "Montano Antilia",
            codCat: "F426"
        },
        {
            name: "Montecorice",
            codCat: "F479"
        },
        {
            name: "Montecorvino Pugliano",
            codCat: "F480"
        },
        {
            name: "Montecorvino Rovella",
            codCat: "F481"
        },
        {
            name: "Monteforte Cilento",
            codCat: "F507"
        },
        {
            name: "Monte San Giacomo",
            codCat: "F618"
        },
        {
            name: "Montesano sulla Marcellana",
            codCat: "F625"
        },
        {
            name: "Morigerati",
            codCat: "F731"
        },
        {
            name: "Nocera Inferiore",
            codCat: "F912"
        },
        {
            name: "Nocera Superiore",
            codCat: "F913"
        },
        {
            name: "Novi Velia",
            codCat: "F967"
        },
        {
            name: "Ogliastro Cilento",
            codCat: "G011"
        },
        {
            name: "Olevano sul Tusciano",
            codCat: "G023"
        },
        {
            name: "Oliveto Citra",
            codCat: "G039"
        },
        {
            name: "Omignano",
            codCat: "G063"
        },
        {
            name: "Orria",
            codCat: "G121"
        },
        {
            name: "Ottati",
            codCat: "G192"
        },
        {
            name: "Padula",
            codCat: "G226"
        },
        {
            name: "Pagani",
            codCat: "G230"
        },
        {
            name: "Palomonte",
            codCat: "G292"
        },
        {
            name: "Pellezzano",
            codCat: "G426"
        },
        {
            name: "Perdifumo",
            codCat: "G447"
        },
        {
            name: "Perito",
            codCat: "G455"
        },
        {
            name: "Pertosa",
            codCat: "G476"
        },
        {
            name: "Petina",
            codCat: "G509"
        },
        {
            name: "Piaggine",
            codCat: "G538"
        },
        {
            name: "Pisciotta",
            codCat: "G707"
        },
        {
            name: "Polla",
            codCat: "G793"
        },
        {
            name: "Pollica",
            codCat: "G796"
        },
        {
            name: "Pontecagnano Faiano",
            codCat: "G834"
        },
        {
            name: "Positano",
            codCat: "G932"
        },
        {
            name: "Postiglione",
            codCat: "G939"
        },
        {
            name: "Praiano",
            codCat: "G976"
        },
        {
            name: "Prignano Cilento",
            codCat: "H062"
        },
        {
            name: "Ravello",
            codCat: "H198"
        },
        {
            name: "Ricigliano",
            codCat: "H277"
        },
        {
            name: "Roccadaspide",
            codCat: "H394"
        },
        {
            name: "Roccagloriosa",
            codCat: "H412"
        },
        {
            name: "Roccapiemonte",
            codCat: "H431"
        },
        {
            name: "Rofrano",
            codCat: "H485"
        },
        {
            name: "Romagnano al Monte",
            codCat: "H503"
        },
        {
            name: "Roscigno",
            codCat: "H564"
        },
        {
            name: "Rutino",
            codCat: "H644"
        },
        {
            name: "Sacco",
            codCat: "H654"
        },
        {
            name: "Sala Consilina",
            codCat: "H683"
        },
        {
            name: "Salento",
            codCat: "H686"
        },
        {
            name: "Salerno",
            codCat: "H703"
        },
        {
            name: "Salvitelle",
            codCat: "H732"
        },
        {
            name: "San Cipriano Picentino",
            codCat: "H800"
        },
        {
            name: "San Giovanni a Piro",
            codCat: "H907"
        },
        {
            name: "San Gregorio Magno",
            codCat: "H943"
        },
        {
            name: "San Mango Piemonte",
            codCat: "H977"
        },
        {
            name: "San Marzano sul Sarno",
            codCat: "I019"
        },
        {
            name: "San Mauro Cilento",
            codCat: "I031"
        },
        {
            name: "San Mauro la Bruca",
            codCat: "I032"
        },
        {
            name: "San Pietro al Tanagro",
            codCat: "I089"
        },
        {
            name: "San Rufo",
            codCat: "I143"
        },
        {
            name: "Santa Marina",
            codCat: "I253"
        },
        {
            name: "Sant'Angelo a Fasanella",
            codCat: "I278"
        },
        {
            name: "Sant'Arsenio",
            codCat: "I307"
        },
        {
            name: "Sant'Egidio del Monte Albino",
            codCat: "I317"
        },
        {
            name: "Santomenna",
            codCat: "I260"
        },
        {
            name: "San Valentino Torio",
            codCat: "I377"
        },
        {
            name: "Sanza",
            codCat: "I410"
        },
        {
            name: "Sapri",
            codCat: "I422"
        },
        {
            name: "Sarno",
            codCat: "I438"
        },
        {
            name: "Sassano",
            codCat: "I451"
        },
        {
            name: "Scafati",
            codCat: "I483"
        },
        {
            name: "Scala",
            codCat: "I486"
        },
        {
            name: "Serramezzana",
            codCat: "I648"
        },
        {
            name: "Serre",
            codCat: "I666"
        },
        {
            name: "Sessa Cilento",
            codCat: "I677"
        },
        {
            name: "Siano",
            codCat: "I720"
        },
        {
            name: "Sicignano degli Alburni",
            codCat: "M253"
        },
        {
            name: "Stella Cilento",
            codCat: "G887"
        },
        {
            name: "Stio",
            codCat: "I960"
        },
        {
            name: "Teggiano",
            codCat: "D292"
        },
        {
            name: "Torchiara",
            codCat: "L212"
        },
        {
            name: "Torraca",
            codCat: "L233"
        },
        {
            name: "Torre Orsaia",
            codCat: "L274"
        },
        {
            name: "Tortorella",
            codCat: "L306"
        },
        {
            name: "Tramonti",
            codCat: "L323"
        },
        {
            name: "Trentinara",
            codCat: "L377"
        },
        {
            name: "Valle dell'Angelo",
            codCat: "G540"
        },
        {
            name: "Vallo della Lucania",
            codCat: "L628"
        },
        {
            name: "Valva",
            codCat: "L656"
        },
        {
            name: "Vibonati",
            codCat: "L835"
        },
        {
            name: "Vietri sul Mare",
            codCat: "L860"
        },
        {
            name: "Bellizzi",
            codCat: "M294"
        },
        {
            name: "Accadia",
            codCat: "A015"
        },
        {
            name: "Alberona",
            codCat: "A150"
        },
        {
            name: "Anzano di Puglia",
            codCat: "A320"
        },
        {
            name: "Apricena",
            codCat: "A339"
        },
        {
            name: "Ascoli Satriano",
            codCat: "A463"
        },
        {
            name: "Biccari",
            codCat: "A854"
        },
        {
            name: "Bovino",
            codCat: "B104"
        },
        {
            name: "Cagnano Varano",
            codCat: "B357"
        },
        {
            name: "Candela",
            codCat: "B584"
        },
        {
            name: "Carapelle",
            codCat: "B724"
        },
        {
            name: "Carlantino",
            codCat: "B784"
        },
        {
            name: "Carpino",
            codCat: "B829"
        },
        {
            name: "Casalnuovo Monterotaro",
            codCat: "B904"
        },
        {
            name: "Casalvecchio di Puglia",
            codCat: "B917"
        },
        {
            name: "Castelluccio dei Sauri",
            codCat: "C198"
        },
        {
            name: "Castelluccio Valmaggiore",
            codCat: "C202"
        },
        {
            name: "Castelnuovo della Daunia",
            codCat: "C222"
        },
        {
            name: "Celenza Valfortore",
            codCat: "C429"
        },
        {
            name: "Celle di San Vito",
            codCat: "C442"
        },
        {
            name: "Cerignola",
            codCat: "C514"
        },
        {
            name: "Chieuti",
            codCat: "C633"
        },
        {
            name: "Deliceto",
            codCat: "D269"
        },
        {
            name: "Faeto",
            codCat: "D459"
        },
        {
            name: "Foggia",
            codCat: "D643"
        },
        {
            name: "Ischitella",
            codCat: "E332"
        },
        {
            name: "Isole Tremiti",
            codCat: "E363"
        },
        {
            name: "Lesina",
            codCat: "E549"
        },
        {
            name: "Lucera",
            codCat: "E716"
        },
        {
            name: "Manfredonia",
            codCat: "E885"
        },
        {
            name: "Mattinata",
            codCat: "F059"
        },
        {
            name: "Monteleone di Puglia",
            codCat: "F538"
        },
        {
            name: "Monte Sant'Angelo",
            codCat: "F631"
        },
        {
            name: "Motta Montecorvino",
            codCat: "F777"
        },
        {
            name: "Orsara di Puglia",
            codCat: "G125"
        },
        {
            name: "Orta Nova",
            codCat: "G131"
        },
        {
            name: "Panni",
            codCat: "G312"
        },
        {
            name: "Peschici",
            codCat: "G487"
        },
        {
            name: "Pietramontecorvino",
            codCat: "G604"
        },
        {
            name: "Poggio Imperiale",
            codCat: "G761"
        },
        {
            name: "Rignano Garganico",
            codCat: "H287"
        },
        {
            name: "Rocchetta Sant'Antonio",
            codCat: "H467"
        },
        {
            name: "Rodi Garganico",
            codCat: "H480"
        },
        {
            name: "Roseto Valfortore",
            codCat: "H568"
        },
        {
            name: "San Giovanni Rotondo",
            codCat: "H926"
        },
        {
            name: "San Marco in Lamis",
            codCat: "H985"
        },
        {
            name: "San Marco la Catola",
            codCat: "H986"
        },
        {
            name: "San Nicandro Garganico",
            codCat: "I054"
        },
        {
            name: "San Paolo di Civitate",
            codCat: "I072"
        },
        {
            name: "San Severo",
            codCat: "I158"
        },
        {
            name: "Sant'Agata di Puglia",
            codCat: "I193"
        },
        {
            name: "Serracapriola",
            codCat: "I641"
        },
        {
            name: "Stornara",
            codCat: "I962"
        },
        {
            name: "Stornarella",
            codCat: "I963"
        },
        {
            name: "Torremaggiore",
            codCat: "L273"
        },
        {
            name: "Troia",
            codCat: "L447"
        },
        {
            name: "Vico del Gargano",
            codCat: "L842"
        },
        {
            name: "Vieste",
            codCat: "L858"
        },
        {
            name: "Volturara Appula",
            codCat: "M131"
        },
        {
            name: "Volturino",
            codCat: "M132"
        },
        {
            name: "Ordona",
            codCat: "M266"
        },
        {
            name: "Zapponeta",
            codCat: "M267"
        },
        {
            name: "Acquaviva delle Fonti",
            codCat: "A048"
        },
        {
            name: "Adelfia",
            codCat: "A055"
        },
        {
            name: "Alberobello",
            codCat: "A149"
        },
        {
            name: "Altamura",
            codCat: "A225"
        },
        {
            name: "Bari",
            codCat: "A662"
        },
        {
            name: "Binetto",
            codCat: "A874"
        },
        {
            name: "Bitetto",
            codCat: "A892"
        },
        {
            name: "Bitonto",
            codCat: "A893"
        },
        {
            name: "Bitritto",
            codCat: "A894"
        },
        {
            name: "Capurso",
            codCat: "B716"
        },
        {
            name: "Casamassima",
            codCat: "B923"
        },
        {
            name: "Cassano delle Murge",
            codCat: "B998"
        },
        {
            name: "Castellana Grotte",
            codCat: "C134"
        },
        {
            name: "Cellamare",
            codCat: "C436"
        },
        {
            name: "Conversano",
            codCat: "C975"
        },
        {
            name: "Corato",
            codCat: "C983"
        },
        {
            name: "Gioia del Colle",
            codCat: "E038"
        },
        {
            name: "Giovinazzo",
            codCat: "E047"
        },
        {
            name: "Gravina in Puglia",
            codCat: "E155"
        },
        {
            name: "Grumo Appula",
            codCat: "E223"
        },
        {
            name: "Locorotondo",
            codCat: "E645"
        },
        {
            name: "Modugno",
            codCat: "F262"
        },
        {
            name: "Mola di Bari",
            codCat: "F280"
        },
        {
            name: "Molfetta",
            codCat: "F284"
        },
        {
            name: "Monopoli",
            codCat: "F376"
        },
        {
            name: "Noci",
            codCat: "F915"
        },
        {
            name: "Noicattaro",
            codCat: "F923"
        },
        {
            name: "Palo del Colle",
            codCat: "G291"
        },
        {
            name: "Poggiorsini",
            codCat: "G769"
        },
        {
            name: "Polignano a Mare",
            codCat: "G787"
        },
        {
            name: "Putignano",
            codCat: "H096"
        },
        {
            name: "Rutigliano",
            codCat: "H643"
        },
        {
            name: "Ruvo di Puglia",
            codCat: "H645"
        },
        {
            name: "Sammichele di Bari",
            codCat: "H749"
        },
        {
            name: "Sannicandro di Bari",
            codCat: "I053"
        },
        {
            name: "Santeramo in Colle",
            codCat: "I330"
        },
        {
            name: "Terlizzi",
            codCat: "L109"
        },
        {
            name: "Toritto",
            codCat: "L220"
        },
        {
            name: "Triggiano",
            codCat: "L425"
        },
        {
            name: "Turi",
            codCat: "L472"
        },
        {
            name: "Valenzano",
            codCat: "L571"
        },
        {
            name: "Avetrana",
            codCat: "A514"
        },
        {
            name: "Carosino",
            codCat: "B808"
        },
        {
            name: "Castellaneta",
            codCat: "C136"
        },
        {
            name: "Crispiano",
            codCat: "D171"
        },
        {
            name: "Faggiano",
            codCat: "D463"
        },
        {
            name: "Fragagnano",
            codCat: "D754"
        },
        {
            name: "Ginosa",
            codCat: "E036"
        },
        {
            name: "Grottaglie",
            codCat: "E205"
        },
        {
            name: "Laterza",
            codCat: "E469"
        },
        {
            name: "Leporano",
            codCat: "E537"
        },
        {
            name: "Lizzano",
            codCat: "E630"
        },
        {
            name: "Manduria",
            codCat: "E882"
        },
        {
            name: "Martina Franca",
            codCat: "E986"
        },
        {
            name: "Maruggio",
            codCat: "E995"
        },
        {
            name: "Massafra",
            codCat: "F027"
        },
        {
            name: "Monteiasi",
            codCat: "F531"
        },
        {
            name: "Montemesola",
            codCat: "F563"
        },
        {
            name: "Monteparano",
            codCat: "F587"
        },
        {
            name: "Mottola",
            codCat: "F784"
        },
        {
            name: "Palagianello",
            codCat: "G251"
        },
        {
            name: "Palagiano",
            codCat: "G252"
        },
        {
            name: "Pulsano",
            codCat: "H090"
        },
        {
            name: "Roccaforzata",
            codCat: "H409"
        },
        {
            name: "San Giorgio Ionico",
            codCat: "H882"
        },
        {
            name: "San Marzano di San Giuseppe",
            codCat: "I018"
        },
        {
            name: "Sava",
            codCat: "I467"
        },
        {
            name: "Taranto",
            codCat: "L049"
        },
        {
            name: "Torricella",
            codCat: "L294"
        },
        {
            name: "Statte",
            codCat: "M298"
        },
        {
            name: "Brindisi",
            codCat: "B180"
        },
        {
            name: "Carovigno",
            codCat: "B809"
        },
        {
            name: "Ceglie Messapica",
            codCat: "C424"
        },
        {
            name: "Cellino San Marco",
            codCat: "C448"
        },
        {
            name: "Cisternino",
            codCat: "C741"
        },
        {
            name: "Erchie",
            codCat: "D422"
        },
        {
            name: "Fasano",
            codCat: "D508"
        },
        {
            name: "Francavilla Fontana",
            codCat: "D761"
        },
        {
            name: "Latiano",
            codCat: "E471"
        },
        {
            name: "Mesagne",
            codCat: "F152"
        },
        {
            name: "Oria",
            codCat: "G098"
        },
        {
            name: "Ostuni",
            codCat: "G187"
        },
        {
            name: "San Donaci",
            codCat: "H822"
        },
        {
            name: "San Michele Salentino",
            codCat: "I045"
        },
        {
            name: "San Pancrazio Salentino",
            codCat: "I066"
        },
        {
            name: "San Pietro Vernotico",
            codCat: "I119"
        },
        {
            name: "San Vito dei Normanni",
            codCat: "I396"
        },
        {
            name: "Torchiarolo",
            codCat: "L213"
        },
        {
            name: "Torre Santa Susanna",
            codCat: "L280"
        },
        {
            name: "Villa Castelli",
            codCat: "L920"
        },
        {
            name: "Alessano",
            codCat: "A184"
        },
        {
            name: "Alezio",
            codCat: "A185"
        },
        {
            name: "Alliste",
            codCat: "A208"
        },
        {
            name: "Andrano",
            codCat: "A281"
        },
        {
            name: "Aradeo",
            codCat: "A350"
        },
        {
            name: "Arnesano",
            codCat: "A425"
        },
        {
            name: "Bagnolo del Salento",
            codCat: "A572"
        },
        {
            name: "Botrugno",
            codCat: "B086"
        },
        {
            name: "Calimera",
            codCat: "B413"
        },
        {
            name: "Campi Salentina",
            codCat: "B506"
        },
        {
            name: "Cannole",
            codCat: "B616"
        },
        {
            name: "Caprarica di Lecce",
            codCat: "B690"
        },
        {
            name: "Carmiano",
            codCat: "B792"
        },
        {
            name: "Carpignano Salentino",
            codCat: "B822"
        },
        {
            name: "Casarano",
            codCat: "B936"
        },
        {
            name: "Castri di Lecce",
            codCat: "C334"
        },
        {
            name: "Castrignano de' Greci",
            codCat: "C335"
        },
        {
            name: "Castrignano del Capo",
            codCat: "C336"
        },
        {
            name: "Cavallino",
            codCat: "C377"
        },
        {
            name: "Collepasso",
            codCat: "C865"
        },
        {
            name: "Copertino",
            codCat: "C978"
        },
        {
            name: "Corigliano d'Otranto",
            codCat: "D006"
        },
        {
            name: "Corsano",
            codCat: "D044"
        },
        {
            name: "Cursi",
            codCat: "D223"
        },
        {
            name: "Cutrofiano",
            codCat: "D237"
        },
        {
            name: "Diso",
            codCat: "D305"
        },
        {
            name: "Gagliano del Capo",
            codCat: "D851"
        },
        {
            name: "Galatina",
            codCat: "D862"
        },
        {
            name: "Galatone",
            codCat: "D863"
        },
        {
            name: "Gallipoli",
            codCat: "D883"
        },
        {
            name: "Giuggianello",
            codCat: "E053"
        },
        {
            name: "Giurdignano",
            codCat: "E061"
        },
        {
            name: "Guagnano",
            codCat: "E227"
        },
        {
            name: "Lecce",
            codCat: "E506"
        },
        {
            name: "Lequile",
            codCat: "E538"
        },
        {
            name: "Leverano",
            codCat: "E563"
        },
        {
            name: "Lizzanello",
            codCat: "E629"
        },
        {
            name: "Maglie",
            codCat: "E815"
        },
        {
            name: "Martano",
            codCat: "E979"
        },
        {
            name: "Martignano",
            codCat: "E984"
        },
        {
            name: "Matino",
            codCat: "F054"
        },
        {
            name: "Melendugno",
            codCat: "F101"
        },
        {
            name: "Melissano",
            codCat: "F109"
        },
        {
            name: "Melpignano",
            codCat: "F117"
        },
        {
            name: "Miggiano",
            codCat: "F194"
        },
        {
            name: "Minervino di Lecce",
            codCat: "F221"
        },
        {
            name: "Monteroni di Lecce",
            codCat: "F604"
        },
        {
            name: "Montesano Salentino",
            codCat: "F623"
        },
        {
            name: "Morciano di Leuca",
            codCat: "F716"
        },
        {
            name: "Muro Leccese",
            codCat: "F816"
        },
        {
            name: "Nardò",
            codCat: "F842"
        },
        {
            name: "Neviano",
            codCat: "F881"
        },
        {
            name: "Nociglia",
            codCat: "F916"
        },
        {
            name: "Novoli",
            codCat: "F970"
        },
        {
            name: "Ortelle",
            codCat: "G136"
        },
        {
            name: "Otranto",
            codCat: "G188"
        },
        {
            name: "Palmariggi",
            codCat: "G285"
        },
        {
            name: "Parabita",
            codCat: "G325"
        },
        {
            name: "Patù",
            codCat: "G378"
        },
        {
            name: "Poggiardo",
            codCat: "G751"
        },
        {
            name: "Racale",
            codCat: "H147"
        },
        {
            name: "Ruffano",
            codCat: "H632"
        },
        {
            name: "Salice Salentino",
            codCat: "H708"
        },
        {
            name: "Salve",
            codCat: "H729"
        },
        {
            name: "Sanarica",
            codCat: "H757"
        },
        {
            name: "San Cesario di Lecce",
            codCat: "H793"
        },
        {
            name: "San Donato di Lecce",
            codCat: "H826"
        },
        {
            name: "Sannicola",
            codCat: "I059"
        },
        {
            name: "San Pietro in Lama",
            codCat: "I115"
        },
        {
            name: "Santa Cesarea Terme",
            codCat: "I172"
        },
        {
            name: "Scorrano",
            codCat: "I549"
        },
        {
            name: "Seclì",
            codCat: "I559"
        },
        {
            name: "Sogliano Cavour",
            codCat: "I780"
        },
        {
            name: "Soleto",
            codCat: "I800"
        },
        {
            name: "Specchia",
            codCat: "I887"
        },
        {
            name: "Spongano",
            codCat: "I923"
        },
        {
            name: "Squinzano",
            codCat: "I930"
        },
        {
            name: "Sternatia",
            codCat: "I950"
        },
        {
            name: "Supersano",
            codCat: "L008"
        },
        {
            name: "Surano",
            codCat: "L010"
        },
        {
            name: "Surbo",
            codCat: "L011"
        },
        {
            name: "Taurisano",
            codCat: "L064"
        },
        {
            name: "Taviano",
            codCat: "L074"
        },
        {
            name: "Tiggiano",
            codCat: "L166"
        },
        {
            name: "Trepuzzi",
            codCat: "L383"
        },
        {
            name: "Tricase",
            codCat: "L419"
        },
        {
            name: "Tuglie",
            codCat: "L462"
        },
        {
            name: "Ugento",
            codCat: "L484"
        },
        {
            name: "Uggiano la Chiesa",
            codCat: "L485"
        },
        {
            name: "Veglie",
            codCat: "L711"
        },
        {
            name: "Vernole",
            codCat: "L776"
        },
        {
            name: "Zollino",
            codCat: "M187"
        },
        {
            name: "San Cassiano",
            codCat: "M264"
        },
        {
            name: "Castro",
            codCat: "M261"
        },
        {
            name: "Porto Cesareo",
            codCat: "M263"
        },
        {
            name: "Presicce-Acquarica",
            codCat: "M428"
        },
        {
            name: "Andria",
            codCat: "A285"
        },
        {
            name: "Barletta",
            codCat: "A669"
        },
        {
            name: "Bisceglie",
            codCat: "A883"
        },
        {
            name: "Canosa di Puglia",
            codCat: "B619"
        },
        {
            name: "Margherita di Savoia",
            codCat: "E946"
        },
        {
            name: "Minervino Murge",
            codCat: "F220"
        },
        {
            name: "San Ferdinando di Puglia",
            codCat: "H839"
        },
        {
            name: "Spinazzola",
            codCat: "I907"
        },
        {
            name: "Trani",
            codCat: "L328"
        },
        {
            name: "Trinitapoli",
            codCat: "B915"
        },
        {
            name: "Abriola",
            codCat: "A013"
        },
        {
            name: "Acerenza",
            codCat: "A020"
        },
        {
            name: "Albano di Lucania",
            codCat: "A131"
        },
        {
            name: "Anzi",
            codCat: "A321"
        },
        {
            name: "Armento",
            codCat: "A415"
        },
        {
            name: "Atella",
            codCat: "A482"
        },
        {
            name: "Avigliano",
            codCat: "A519"
        },
        {
            name: "Balvano",
            codCat: "A604"
        },
        {
            name: "Banzi",
            codCat: "A612"
        },
        {
            name: "Baragiano",
            codCat: "A615"
        },
        {
            name: "Barile",
            codCat: "A666"
        },
        {
            name: "Bella",
            codCat: "A743"
        },
        {
            name: "Brienza",
            codCat: "B173"
        },
        {
            name: "Brindisi Montagna",
            codCat: "B181"
        },
        {
            name: "Calvello",
            codCat: "B440"
        },
        {
            name: "Calvera",
            codCat: "B443"
        },
        {
            name: "Campomaggiore",
            codCat: "B549"
        },
        {
            name: "Cancellara",
            codCat: "B580"
        },
        {
            name: "Carbone",
            codCat: "B743"
        },
        {
            name: "San Paolo Albanese",
            codCat: "B906"
        },
        {
            name: "Castelgrande",
            codCat: "C120"
        },
        {
            name: "Castelluccio Inferiore",
            codCat: "C199"
        },
        {
            name: "Castelluccio Superiore",
            codCat: "C201"
        },
        {
            name: "Castelmezzano",
            codCat: "C209"
        },
        {
            name: "Castelsaraceno",
            codCat: "C271"
        },
        {
            name: "Castronuovo di Sant'Andrea",
            codCat: "C345"
        },
        {
            name: "Cersosimo",
            codCat: "C539"
        },
        {
            name: "Chiaromonte",
            codCat: "C619"
        },
        {
            name: "Corleto Perticara",
            codCat: "D010"
        },
        {
            name: "Episcopia",
            codCat: "D414"
        },
        {
            name: "Fardella",
            codCat: "D497"
        },
        {
            name: "Filiano",
            codCat: "D593"
        },
        {
            name: "Forenza",
            codCat: "D696"
        },
        {
            name: "Francavilla in Sinni",
            codCat: "D766"
        },
        {
            name: "Gallicchio",
            codCat: "D876"
        },
        {
            name: "Genzano di Lucania",
            codCat: "D971"
        },
        {
            name: "Grumento Nova",
            codCat: "E221"
        },
        {
            name: "Guardia Perticara",
            codCat: "E246"
        },
        {
            name: "Lagonegro",
            codCat: "E409"
        },
        {
            name: "Latronico",
            codCat: "E474"
        },
        {
            name: "Laurenzana",
            codCat: "E482"
        },
        {
            name: "Lauria",
            codCat: "E483"
        },
        {
            name: "Lavello",
            codCat: "E493"
        },
        {
            name: "Maratea",
            codCat: "E919"
        },
        {
            name: "Marsico Nuovo",
            codCat: "E976"
        },
        {
            name: "Marsicovetere",
            codCat: "E977"
        },
        {
            name: "Maschito",
            codCat: "F006"
        },
        {
            name: "Melfi",
            codCat: "F104"
        },
        {
            name: "Missanello",
            codCat: "F249"
        },
        {
            name: "Moliterno",
            codCat: "F295"
        },
        {
            name: "Montemilone",
            codCat: "F568"
        },
        {
            name: "Montemurro",
            codCat: "F573"
        },
        {
            name: "Muro Lucano",
            codCat: "F817"
        },
        {
            name: "Nemoli",
            codCat: "F866"
        },
        {
            name: "Noepoli",
            codCat: "F917"
        },
        {
            name: "Oppido Lucano",
            codCat: "G081"
        },
        {
            name: "Palazzo San Gervasio",
            codCat: "G261"
        },
        {
            name: "Pescopagano",
            codCat: "G496"
        },
        {
            name: "Picerno",
            codCat: "G590"
        },
        {
            name: "Pietragalla",
            codCat: "G616"
        },
        {
            name: "Pietrapertosa",
            codCat: "G623"
        },
        {
            name: "Pignola",
            codCat: "G663"
        },
        {
            name: "Potenza",
            codCat: "G942"
        },
        {
            name: "Rapolla",
            codCat: "H186"
        },
        {
            name: "Rapone",
            codCat: "H187"
        },
        {
            name: "Rionero in Vulture",
            codCat: "H307"
        },
        {
            name: "Ripacandida",
            codCat: "H312"
        },
        {
            name: "Rivello",
            codCat: "H348"
        },
        {
            name: "Roccanova",
            codCat: "H426"
        },
        {
            name: "Rotonda",
            codCat: "H590"
        },
        {
            name: "Ruoti",
            codCat: "H641"
        },
        {
            name: "Ruvo del Monte",
            codCat: "H646"
        },
        {
            name: "San Chirico Nuovo",
            codCat: "H795"
        },
        {
            name: "San Chirico Raparo",
            codCat: "H796"
        },
        {
            name: "San Costantino Albanese",
            codCat: "H808"
        },
        {
            name: "San Fele",
            codCat: "H831"
        },
        {
            name: "San Martino d'Agri",
            codCat: "H994"
        },
        {
            name: "San Severino Lucano",
            codCat: "I157"
        },
        {
            name: "Sant'Angelo Le Fratte",
            codCat: "I288"
        },
        {
            name: "Sant'Arcangelo",
            codCat: "I305"
        },
        {
            name: "Sarconi",
            codCat: "I426"
        },
        {
            name: "Sasso di Castalda",
            codCat: "I457"
        },
        {
            name: "Satriano di Lucania",
            codCat: "G614"
        },
        {
            name: "Savoia di Lucania",
            codCat: "H730"
        },
        {
            name: "Senise",
            codCat: "I610"
        },
        {
            name: "Spinoso",
            codCat: "I917"
        },
        {
            name: "Teana",
            codCat: "L082"
        },
        {
            name: "Terranova di Pollino",
            codCat: "L126"
        },
        {
            name: "Tito",
            codCat: "L181"
        },
        {
            name: "Tolve",
            codCat: "L197"
        },
        {
            name: "Tramutola",
            codCat: "L326"
        },
        {
            name: "Trecchina",
            codCat: "L357"
        },
        {
            name: "Trivigno",
            codCat: "L439"
        },
        {
            name: "Vaglio Basilicata",
            codCat: "L532"
        },
        {
            name: "Venosa",
            codCat: "L738"
        },
        {
            name: "Vietri di Potenza",
            codCat: "L859"
        },
        {
            name: "Viggianello",
            codCat: "L873"
        },
        {
            name: "Viggiano",
            codCat: "L874"
        },
        {
            name: "Ginestra",
            codCat: "E033"
        },
        {
            name: "Paterno",
            codCat: "M269"
        },
        {
            name: "Accettura",
            codCat: "A017"
        },
        {
            name: "Aliano",
            codCat: "A196"
        },
        {
            name: "Bernalda",
            codCat: "A801"
        },
        {
            name: "Calciano",
            codCat: "B391"
        },
        {
            name: "Cirigliano",
            codCat: "C723"
        },
        {
            name: "Colobraro",
            codCat: "C888"
        },
        {
            name: "Craco",
            codCat: "D128"
        },
        {
            name: "Ferrandina",
            codCat: "D547"
        },
        {
            name: "Garaguso",
            codCat: "D909"
        },
        {
            name: "Gorgoglione",
            codCat: "E093"
        },
        {
            name: "Grassano",
            codCat: "E147"
        },
        {
            name: "Grottole",
            codCat: "E213"
        },
        {
            name: "Irsina",
            codCat: "E326"
        },
        {
            name: "Matera",
            codCat: "F052"
        },
        {
            name: "Miglionico",
            codCat: "F201"
        },
        {
            name: "Montalbano Jonico",
            codCat: "F399"
        },
        {
            name: "Montescaglioso",
            codCat: "F637"
        },
        {
            name: "Nova Siri",
            codCat: "A942"
        },
        {
            name: "Oliveto Lucano",
            codCat: "G037"
        },
        {
            name: "Pisticci",
            codCat: "G712"
        },
        {
            name: "Policoro",
            codCat: "G786"
        },
        {
            name: "Pomarico",
            codCat: "G806"
        },
        {
            name: "Rotondella",
            codCat: "H591"
        },
        {
            name: "Salandra",
            codCat: "H687"
        },
        {
            name: "San Giorgio Lucano",
            codCat: "H888"
        },
        {
            name: "San Mauro Forte",
            codCat: "I029"
        },
        {
            name: "Stigliano",
            codCat: "I954"
        },
        {
            name: "Tricarico",
            codCat: "L418"
        },
        {
            name: "Tursi",
            codCat: "L477"
        },
        {
            name: "Valsinni",
            codCat: "D513"
        },
        {
            name: "Scanzano Jonico",
            codCat: "M256"
        },
        {
            name: "Acquaformosa",
            codCat: "A033"
        },
        {
            name: "Acquappesa",
            codCat: "A041"
        },
        {
            name: "Acri",
            codCat: "A053"
        },
        {
            name: "Aiello Calabro",
            codCat: "A102"
        },
        {
            name: "Aieta",
            codCat: "A105"
        },
        {
            name: "Albidona",
            codCat: "A160"
        },
        {
            name: "Alessandria del Carretto",
            codCat: "A183"
        },
        {
            name: "Altilia",
            codCat: "A234"
        },
        {
            name: "Altomonte",
            codCat: "A240"
        },
        {
            name: "Amantea",
            codCat: "A253"
        },
        {
            name: "Amendolara",
            codCat: "A263"
        },
        {
            name: "Aprigliano",
            codCat: "A340"
        },
        {
            name: "Belmonte Calabro",
            codCat: "A762"
        },
        {
            name: "Belsito",
            codCat: "A768"
        },
        {
            name: "Belvedere Marittimo",
            codCat: "A773"
        },
        {
            name: "Bianchi",
            codCat: "A842"
        },
        {
            name: "Bisignano",
            codCat: "A887"
        },
        {
            name: "Bocchigliero",
            codCat: "A912"
        },
        {
            name: "Bonifati",
            codCat: "A973"
        },
        {
            name: "Buonvicino",
            codCat: "B270"
        },
        {
            name: "Calopezzati",
            codCat: "B424"
        },
        {
            name: "Caloveto",
            codCat: "B426"
        },
        {
            name: "Campana",
            codCat: "B500"
        },
        {
            name: "Canna",
            codCat: "B607"
        },
        {
            name: "Cariati",
            codCat: "B774"
        },
        {
            name: "Carolei",
            codCat: "B802"
        },
        {
            name: "Carpanzano",
            codCat: "B813"
        },
        {
            name: "Cassano all'Ionio",
            codCat: "C002"
        },
        {
            name: "Castiglione Cosentino",
            codCat: "C301"
        },
        {
            name: "Castrolibero",
            codCat: "C108"
        },
        {
            name: "Castroregio",
            codCat: "C348"
        },
        {
            name: "Castrovillari",
            codCat: "C349"
        },
        {
            name: "Celico",
            codCat: "C430"
        },
        {
            name: "Cellara",
            codCat: "C437"
        },
        {
            name: "Cerchiara di Calabria",
            codCat: "C489"
        },
        {
            name: "Cerisano",
            codCat: "C515"
        },
        {
            name: "Cervicati",
            codCat: "C554"
        },
        {
            name: "Cerzeto",
            codCat: "C560"
        },
        {
            name: "Cetraro",
            codCat: "C588"
        },
        {
            name: "Civita",
            codCat: "C763"
        },
        {
            name: "Cleto",
            codCat: "C795"
        },
        {
            name: "Colosimi",
            codCat: "C905"
        },
        {
            name: "Cosenza",
            codCat: "D086"
        },
        {
            name: "Cropalati",
            codCat: "D180"
        },
        {
            name: "Crosia",
            codCat: "D184"
        },
        {
            name: "Diamante",
            codCat: "D289"
        },
        {
            name: "Dipignano",
            codCat: "D304"
        },
        {
            name: "Domanico",
            codCat: "D328"
        },
        {
            name: "Fagnano Castello",
            codCat: "D464"
        },
        {
            name: "Falconara Albanese",
            codCat: "D473"
        },
        {
            name: "Figline Vegliaturo",
            codCat: "D582"
        },
        {
            name: "Firmo",
            codCat: "D614"
        },
        {
            name: "Fiumefreddo Bruzio",
            codCat: "D624"
        },
        {
            name: "Francavilla Marittima",
            codCat: "D764"
        },
        {
            name: "Frascineto",
            codCat: "D774"
        },
        {
            name: "Fuscaldo",
            codCat: "D828"
        },
        {
            name: "Grimaldi",
            codCat: "E180"
        },
        {
            name: "Grisolia",
            codCat: "E185"
        },
        {
            name: "Guardia Piemontese",
            codCat: "E242"
        },
        {
            name: "Lago",
            codCat: "E407"
        },
        {
            name: "Laino Borgo",
            codCat: "E417"
        },
        {
            name: "Laino Castello",
            codCat: "E419"
        },
        {
            name: "Lappano",
            codCat: "E450"
        },
        {
            name: "Lattarico",
            codCat: "E475"
        },
        {
            name: "Longobardi",
            codCat: "E677"
        },
        {
            name: "Longobucco",
            codCat: "E678"
        },
        {
            name: "Lungro",
            codCat: "E745"
        },
        {
            name: "Luzzi",
            codCat: "E773"
        },
        {
            name: "Maierà",
            codCat: "E835"
        },
        {
            name: "Malito",
            codCat: "E859"
        },
        {
            name: "Malvito",
            codCat: "E872"
        },
        {
            name: "Mandatoriccio",
            codCat: "E878"
        },
        {
            name: "Mangone",
            codCat: "E888"
        },
        {
            name: "Marano Marchesato",
            codCat: "E914"
        },
        {
            name: "Marano Principato",
            codCat: "E915"
        },
        {
            name: "Marzi",
            codCat: "F001"
        },
        {
            name: "Mendicino",
            codCat: "F125"
        },
        {
            name: "Mongrassano",
            codCat: "F370"
        },
        {
            name: "Montalto Uffugo",
            codCat: "F416"
        },
        {
            name: "Montegiordano",
            codCat: "F519"
        },
        {
            name: "Morano Calabro",
            codCat: "F708"
        },
        {
            name: "Mormanno",
            codCat: "F735"
        },
        {
            name: "Mottafollone",
            codCat: "F775"
        },
        {
            name: "Nocara",
            codCat: "F907"
        },
        {
            name: "Oriolo",
            codCat: "G110"
        },
        {
            name: "Orsomarso",
            codCat: "G129"
        },
        {
            name: "Paludi",
            codCat: "G298"
        },
        {
            name: "Panettieri",
            codCat: "G307"
        },
        {
            name: "Paola",
            codCat: "G317"
        },
        {
            name: "Papasidero",
            codCat: "G320"
        },
        {
            name: "Parenti",
            codCat: "G331"
        },
        {
            name: "Paterno Calabro",
            codCat: "G372"
        },
        {
            name: "Pedivigliano",
            codCat: "G411"
        },
        {
            name: "Piane Crati",
            codCat: "G553"
        },
        {
            name: "Pietrafitta",
            codCat: "G615"
        },
        {
            name: "Pietrapaola",
            codCat: "G622"
        },
        {
            name: "Plataci",
            codCat: "G733"
        },
        {
            name: "Praia a Mare",
            codCat: "G975"
        },
        {
            name: "Rende",
            codCat: "H235"
        },
        {
            name: "Rocca Imperiale",
            codCat: "H416"
        },
        {
            name: "Roggiano Gravina",
            codCat: "H488"
        },
        {
            name: "Rogliano",
            codCat: "H490"
        },
        {
            name: "Rose",
            codCat: "H565"
        },
        {
            name: "Roseto Capo Spulico",
            codCat: "H572"
        },
        {
            name: "Rota Greca",
            codCat: "H585"
        },
        {
            name: "Rovito",
            codCat: "H621"
        },
        {
            name: "San Basile",
            codCat: "H765"
        },
        {
            name: "San Benedetto Ullano",
            codCat: "H774"
        },
        {
            name: "San Cosmo Albanese",
            codCat: "H806"
        },
        {
            name: "San Demetrio Corone",
            codCat: "H818"
        },
        {
            name: "San Donato di Ninea",
            codCat: "H825"
        },
        {
            name: "San Fili",
            codCat: "H841"
        },
        {
            name: "Sangineto",
            codCat: "H877"
        },
        {
            name: "San Giorgio Albanese",
            codCat: "H881"
        },
        {
            name: "San Giovanni in Fiore",
            codCat: "H919"
        },
        {
            name: "San Lorenzo Bellizzi",
            codCat: "H961"
        },
        {
            name: "San Lorenzo del Vallo",
            codCat: "H962"
        },
        {
            name: "San Lucido",
            codCat: "H971"
        },
        {
            name: "San Marco Argentano",
            codCat: "H981"
        },
        {
            name: "San Martino di Finita",
            codCat: "H992"
        },
        {
            name: "San Nicola Arcella",
            codCat: "I060"
        },
        {
            name: "San Pietro in Amantea",
            codCat: "I108"
        },
        {
            name: "San Pietro in Guarano",
            codCat: "I114"
        },
        {
            name: "San Sosti",
            codCat: "I165"
        },
        {
            name: "Santa Caterina Albanese",
            codCat: "I171"
        },
        {
            name: "Santa Domenica Talao",
            codCat: "I183"
        },
        {
            name: "Sant'Agata di Esaro",
            codCat: "I192"
        },
        {
            name: "Santa Maria del Cedro",
            codCat: "C717"
        },
        {
            name: "Santa Sofia d'Epiro",
            codCat: "I309"
        },
        {
            name: "Santo Stefano di Rogliano",
            codCat: "I359"
        },
        {
            name: "San Vincenzo La Costa",
            codCat: "I388"
        },
        {
            name: "Saracena",
            codCat: "I423"
        },
        {
            name: "Scala Coeli",
            codCat: "I485"
        },
        {
            name: "Scalea",
            codCat: "I489"
        },
        {
            name: "Scigliano",
            codCat: "D290"
        },
        {
            name: "Serra d'Aiello",
            codCat: "I642"
        },
        {
            name: "Spezzano Albanese",
            codCat: "I895"
        },
        {
            name: "Spezzano della Sila",
            codCat: "I896"
        },
        {
            name: "Tarsia",
            codCat: "L055"
        },
        {
            name: "Terranova da Sibari",
            codCat: "L124"
        },
        {
            name: "Terravecchia",
            codCat: "L134"
        },
        {
            name: "Torano Castello",
            codCat: "L206"
        },
        {
            name: "Tortora",
            codCat: "L305"
        },
        {
            name: "Trebisacce",
            codCat: "L353"
        },
        {
            name: "Vaccarizzo Albanese",
            codCat: "L524"
        },
        {
            name: "Verbicaro",
            codCat: "L747"
        },
        {
            name: "Villapiana",
            codCat: "B903"
        },
        {
            name: "Zumpano",
            codCat: "M202"
        },
        {
            name: "Casali del Manco",
            codCat: "M385"
        },
        {
            name: "Corigliano-Rossano",
            codCat: "M403"
        },
        {
            name: "Albi",
            codCat: "A155"
        },
        {
            name: "Amaroni",
            codCat: "A255"
        },
        {
            name: "Amato",
            codCat: "A257"
        },
        {
            name: "Andali",
            codCat: "A272"
        },
        {
            name: "Argusto",
            codCat: "A397"
        },
        {
            name: "Badolato",
            codCat: "A542"
        },
        {
            name: "Belcastro",
            codCat: "A736"
        },
        {
            name: "Borgia",
            codCat: "B002"
        },
        {
            name: "Botricello",
            codCat: "B085"
        },
        {
            name: "Caraffa di Catanzaro",
            codCat: "B717"
        },
        {
            name: "Cardinale",
            codCat: "B758"
        },
        {
            name: "Carlopoli",
            codCat: "B790"
        },
        {
            name: "Catanzaro",
            codCat: "C352"
        },
        {
            name: "Cenadi",
            codCat: "C453"
        },
        {
            name: "Centrache",
            codCat: "C472"
        },
        {
            name: "Cerva",
            codCat: "C542"
        },
        {
            name: "Chiaravalle Centrale",
            codCat: "C616"
        },
        {
            name: "Cicala",
            codCat: "C674"
        },
        {
            name: "Conflenti",
            codCat: "C960"
        },
        {
            name: "Cortale",
            codCat: "D049"
        },
        {
            name: "Cropani",
            codCat: "D181"
        },
        {
            name: "Curinga",
            codCat: "D218"
        },
        {
            name: "Davoli",
            codCat: "D257"
        },
        {
            name: "Decollatura",
            codCat: "D261"
        },
        {
            name: "Falerna",
            codCat: "D476"
        },
        {
            name: "Feroleto Antico",
            codCat: "D544"
        },
        {
            name: "Fossato Serralta",
            codCat: "D744"
        },
        {
            name: "Gagliato",
            codCat: "D852"
        },
        {
            name: "Gasperina",
            codCat: "D932"
        },
        {
            name: "Gimigliano",
            codCat: "E031"
        },
        {
            name: "Girifalco",
            codCat: "E050"
        },
        {
            name: "Gizzeria",
            codCat: "E068"
        },
        {
            name: "Guardavalle",
            codCat: "E239"
        },
        {
            name: "Isca sullo Ionio",
            codCat: "E328"
        },
        {
            name: "Jacurso",
            codCat: "E274"
        },
        {
            name: "Magisano",
            codCat: "E806"
        },
        {
            name: "Maida",
            codCat: "E834"
        },
        {
            name: "Marcedusa",
            codCat: "E923"
        },
        {
            name: "Marcellinara",
            codCat: "E925"
        },
        {
            name: "Martirano",
            codCat: "E990"
        },
        {
            name: "Martirano Lombardo",
            codCat: "E991"
        },
        {
            name: "Miglierina",
            codCat: "F200"
        },
        {
            name: "Montauro",
            codCat: "F432"
        },
        {
            name: "Montepaone",
            codCat: "F586"
        },
        {
            name: "Motta Santa Lucia",
            codCat: "F780"
        },
        {
            name: "Nocera Terinese",
            codCat: "F910"
        },
        {
            name: "Olivadi",
            codCat: "G034"
        },
        {
            name: "Palermiti",
            codCat: "G272"
        },
        {
            name: "Pentone",
            codCat: "G439"
        },
        {
            name: "Petrizzi",
            codCat: "G517"
        },
        {
            name: "Petronà",
            codCat: "G518"
        },
        {
            name: "Pianopoli",
            codCat: "D546"
        },
        {
            name: "Platania",
            codCat: "G734"
        },
        {
            name: "San Floro",
            codCat: "H846"
        },
        {
            name: "San Mango d'Aquino",
            codCat: "H976"
        },
        {
            name: "San Pietro a Maida",
            codCat: "I093"
        },
        {
            name: "San Pietro Apostolo",
            codCat: "I095"
        },
        {
            name: "San Sostene",
            codCat: "I164"
        },
        {
            name: "Santa Caterina dello Ionio",
            codCat: "I170"
        },
        {
            name: "Sant'Andrea Apostolo dello Ionio",
            codCat: "I266"
        },
        {
            name: "San Vito sullo Ionio",
            codCat: "I393"
        },
        {
            name: "Satriano",
            codCat: "I463"
        },
        {
            name: "Sellia",
            codCat: "I589"
        },
        {
            name: "Sellia Marina",
            codCat: "I590"
        },
        {
            name: "Serrastretta",
            codCat: "I655"
        },
        {
            name: "Sersale",
            codCat: "I671"
        },
        {
            name: "Settingiano",
            codCat: "I704"
        },
        {
            name: "Simeri Crichi",
            codCat: "I745"
        },
        {
            name: "Sorbo San Basile",
            codCat: "I844"
        },
        {
            name: "Soverato",
            codCat: "I872"
        },
        {
            name: "Soveria Mannelli",
            codCat: "I874"
        },
        {
            name: "Soveria Simeri",
            codCat: "I875"
        },
        {
            name: "Squillace",
            codCat: "I929"
        },
        {
            name: "Stalettì",
            codCat: "I937"
        },
        {
            name: "Taverna",
            codCat: "L070"
        },
        {
            name: "Tiriolo",
            codCat: "L177"
        },
        {
            name: "Torre di Ruggiero",
            codCat: "L240"
        },
        {
            name: "Vallefiorita",
            codCat: "I322"
        },
        {
            name: "Zagarise",
            codCat: "M140"
        },
        {
            name: "Lamezia Terme",
            codCat: "M208"
        },
        {
            name: "Africo",
            codCat: "A065"
        },
        {
            name: "Agnana Calabra",
            codCat: "A077"
        },
        {
            name: "Anoia",
            codCat: "A303"
        },
        {
            name: "Antonimina",
            codCat: "A314"
        },
        {
            name: "Ardore",
            codCat: "A385"
        },
        {
            name: "Bagaladi",
            codCat: "A544"
        },
        {
            name: "Bagnara Calabra",
            codCat: "A552"
        },
        {
            name: "Benestare",
            codCat: "A780"
        },
        {
            name: "Bianco",
            codCat: "A843"
        },
        {
            name: "Bivongi",
            codCat: "A897"
        },
        {
            name: "Bova",
            codCat: "B097"
        },
        {
            name: "Bovalino",
            codCat: "B098"
        },
        {
            name: "Bova Marina",
            codCat: "B099"
        },
        {
            name: "Brancaleone",
            codCat: "B118"
        },
        {
            name: "Bruzzano Zeffirio",
            codCat: "B234"
        },
        {
            name: "Calanna",
            codCat: "B379"
        },
        {
            name: "Camini",
            codCat: "B481"
        },
        {
            name: "Campo Calabro",
            codCat: "B516"
        },
        {
            name: "Candidoni",
            codCat: "B591"
        },
        {
            name: "Canolo",
            codCat: "B617"
        },
        {
            name: "Caraffa del Bianco",
            codCat: "B718"
        },
        {
            name: "Cardeto",
            codCat: "B756"
        },
        {
            name: "Careri",
            codCat: "B766"
        },
        {
            name: "Casignana",
            codCat: "B966"
        },
        {
            name: "Caulonia",
            codCat: "C285"
        },
        {
            name: "Ciminà",
            codCat: "C695"
        },
        {
            name: "Cinquefrondi",
            codCat: "C710"
        },
        {
            name: "Cittanova",
            codCat: "C747"
        },
        {
            name: "Condofuri",
            codCat: "C954"
        },
        {
            name: "Cosoleto",
            codCat: "D089"
        },
        {
            name: "Delianuova",
            codCat: "D268"
        },
        {
            name: "Feroleto della Chiesa",
            codCat: "D545"
        },
        {
            name: "Ferruzzano",
            codCat: "D557"
        },
        {
            name: "Fiumara",
            codCat: "D619"
        },
        {
            name: "Galatro",
            codCat: "D864"
        },
        {
            name: "Gerace",
            codCat: "D975"
        },
        {
            name: "Giffone",
            codCat: "E025"
        },
        {
            name: "Gioia Tauro",
            codCat: "E041"
        },
        {
            name: "Gioiosa Ionica",
            codCat: "E044"
        },
        {
            name: "Grotteria",
            codCat: "E212"
        },
        {
            name: "Laganadi",
            codCat: "E402"
        },
        {
            name: "Laureana di Borrello",
            codCat: "E479"
        },
        {
            name: "Locri",
            codCat: "D976"
        },
        {
            name: "Mammola",
            codCat: "E873"
        },
        {
            name: "Marina di Gioiosa Ionica",
            codCat: "E956"
        },
        {
            name: "Maropati",
            codCat: "E968"
        },
        {
            name: "Martone",
            codCat: "E993"
        },
        {
            name: "Melicuccà",
            codCat: "F105"
        },
        {
            name: "Melicucco",
            codCat: "F106"
        },
        {
            name: "Melito di Porto Salvo",
            codCat: "F112"
        },
        {
            name: "Molochio",
            codCat: "F301"
        },
        {
            name: "Monasterace",
            codCat: "F324"
        },
        {
            name: "Montebello Jonico",
            codCat: "D746"
        },
        {
            name: "Motta San Giovanni",
            codCat: "F779"
        },
        {
            name: "Oppido Mamertina",
            codCat: "G082"
        },
        {
            name: "Palizzi",
            codCat: "G277"
        },
        {
            name: "Palmi",
            codCat: "G288"
        },
        {
            name: "Pazzano",
            codCat: "G394"
        },
        {
            name: "Placanica",
            codCat: "G729"
        },
        {
            name: "Platì",
            codCat: "G735"
        },
        {
            name: "Polistena",
            codCat: "G791"
        },
        {
            name: "Portigliola",
            codCat: "G905"
        },
        {
            name: "Reggio di Calabria",
            codCat: "H224"
        },
        {
            name: "Riace",
            codCat: "H265"
        },
        {
            name: "Rizziconi",
            codCat: "H359"
        },
        {
            name: "Roccaforte del Greco",
            codCat: "H408"
        },
        {
            name: "Roccella Ionica",
            codCat: "H456"
        },
        {
            name: "Roghudi",
            codCat: "H489"
        },
        {
            name: "Rosarno",
            codCat: "H558"
        },
        {
            name: "Samo",
            codCat: "H013"
        },
        {
            name: "San Giorgio Morgeto",
            codCat: "H889"
        },
        {
            name: "San Giovanni di Gerace",
            codCat: "H903"
        },
        {
            name: "San Lorenzo",
            codCat: "H959"
        },
        {
            name: "San Luca",
            codCat: "H970"
        },
        {
            name: "San Pietro di Caridà",
            codCat: "I102"
        },
        {
            name: "San Procopio",
            codCat: "I132"
        },
        {
            name: "San Roberto",
            codCat: "I139"
        },
        {
            name: "Santa Cristina d'Aspromonte",
            codCat: "I176"
        },
        {
            name: "Sant'Agata del Bianco",
            codCat: "I198"
        },
        {
            name: "Sant'Alessio in Aspromonte",
            codCat: "I214"
        },
        {
            name: "Sant'Eufemia d'Aspromonte",
            codCat: "I333"
        },
        {
            name: "Sant'Ilario dello Ionio",
            codCat: "I341"
        },
        {
            name: "Santo Stefano in Aspromonte",
            codCat: "I371"
        },
        {
            name: "Scido",
            codCat: "I536"
        },
        {
            name: "Scilla",
            codCat: "I537"
        },
        {
            name: "Seminara",
            codCat: "I600"
        },
        {
            name: "Serrata",
            codCat: "I656"
        },
        {
            name: "Siderno",
            codCat: "I725"
        },
        {
            name: "Sinopoli",
            codCat: "I753"
        },
        {
            name: "Staiti",
            codCat: "I936"
        },
        {
            name: "Stignano",
            codCat: "I955"
        },
        {
            name: "Stilo",
            codCat: "I956"
        },
        {
            name: "Taurianova",
            codCat: "L063"
        },
        {
            name: "Terranova Sappo Minulio",
            codCat: "L127"
        },
        {
            name: "Varapodio",
            codCat: "L673"
        },
        {
            name: "Villa San Giovanni",
            codCat: "M018"
        },
        {
            name: "San Ferdinando",
            codCat: "M277"
        },
        {
            name: "Belvedere di Spinello",
            codCat: "A772"
        },
        {
            name: "Caccuri",
            codCat: "B319"
        },
        {
            name: "Carfizzi",
            codCat: "B771"
        },
        {
            name: "Casabona",
            codCat: "B857"
        },
        {
            name: "Castelsilano",
            codCat: "B968"
        },
        {
            name: "Cerenzia",
            codCat: "C501"
        },
        {
            name: "Cirò",
            codCat: "C725"
        },
        {
            name: "Cirò Marina",
            codCat: "C726"
        },
        {
            name: "Cotronei",
            codCat: "D123"
        },
        {
            name: "Crotone",
            codCat: "D122"
        },
        {
            name: "Crucoli",
            codCat: "D189"
        },
        {
            name: "Cutro",
            codCat: "D236"
        },
        {
            name: "Isola di Capo Rizzuto",
            codCat: "E339"
        },
        {
            name: "Melissa",
            codCat: "F108"
        },
        {
            name: "Mesoraca",
            codCat: "F157"
        },
        {
            name: "Pallagorio",
            codCat: "G278"
        },
        {
            name: "Petilia Policastro",
            codCat: "G508"
        },
        {
            name: "Roccabernarda",
            codCat: "H383"
        },
        {
            name: "Rocca di Neto",
            codCat: "H403"
        },
        {
            name: "San Mauro Marchesato",
            codCat: "I026"
        },
        {
            name: "San Nicola dell'Alto",
            codCat: "I057"
        },
        {
            name: "Santa Severina",
            codCat: "I308"
        },
        {
            name: "Savelli",
            codCat: "I468"
        },
        {
            name: "Scandale",
            codCat: "I494"
        },
        {
            name: "Strongoli",
            codCat: "I982"
        },
        {
            name: "Umbriatico",
            codCat: "L492"
        },
        {
            name: "Verzino",
            codCat: "L802"
        },
        {
            name: "Acquaro",
            codCat: "A043"
        },
        {
            name: "Arena",
            codCat: "A386"
        },
        {
            name: "Briatico",
            codCat: "B169"
        },
        {
            name: "Brognaturo",
            codCat: "B197"
        },
        {
            name: "Capistrano",
            codCat: "B655"
        },
        {
            name: "Cessaniti",
            codCat: "C581"
        },
        {
            name: "Dasà",
            codCat: "D253"
        },
        {
            name: "Dinami",
            codCat: "D303"
        },
        {
            name: "Drapia",
            codCat: "D364"
        },
        {
            name: "Fabrizia",
            codCat: "D453"
        },
        {
            name: "Filadelfia",
            codCat: "D587"
        },
        {
            name: "Filandari",
            codCat: "D589"
        },
        {
            name: "Filogaso",
            codCat: "D596"
        },
        {
            name: "Francavilla Angitola",
            codCat: "D762"
        },
        {
            name: "Francica",
            codCat: "D767"
        },
        {
            name: "Gerocarne",
            codCat: "D988"
        },
        {
            name: "Ionadi",
            codCat: "E321"
        },
        {
            name: "Joppolo",
            codCat: "E389"
        },
        {
            name: "Limbadi",
            codCat: "E590"
        },
        {
            name: "Maierato",
            codCat: "E836"
        },
        {
            name: "Mileto",
            codCat: "F207"
        },
        {
            name: "Mongiana",
            codCat: "F364"
        },
        {
            name: "Monterosso Calabro",
            codCat: "F607"
        },
        {
            name: "Nardodipace",
            codCat: "F843"
        },
        {
            name: "Nicotera",
            codCat: "F893"
        },
        {
            name: "Parghelia",
            codCat: "G335"
        },
        {
            name: "Pizzo",
            codCat: "G722"
        },
        {
            name: "Pizzoni",
            codCat: "G728"
        },
        {
            name: "Polia",
            codCat: "G785"
        },
        {
            name: "Ricadi",
            codCat: "H271"
        },
        {
            name: "Rombiolo",
            codCat: "H516"
        },
        {
            name: "San Calogero",
            codCat: "H785"
        },
        {
            name: "San Costantino Calabro",
            codCat: "H807"
        },
        {
            name: "San Gregorio d'Ippona",
            codCat: "H941"
        },
        {
            name: "San Nicola da Crissa",
            codCat: "I058"
        },
        {
            name: "Sant'Onofrio",
            codCat: "I350"
        },
        {
            name: "Serra San Bruno",
            codCat: "I639"
        },
        {
            name: "Simbario",
            codCat: "I744"
        },
        {
            name: "Sorianello",
            codCat: "I853"
        },
        {
            name: "Soriano Calabro",
            codCat: "I854"
        },
        {
            name: "Spadola",
            codCat: "I884"
        },
        {
            name: "Spilinga",
            codCat: "I905"
        },
        {
            name: "Stefanaconi",
            codCat: "I945"
        },
        {
            name: "Tropea",
            codCat: "L452"
        },
        {
            name: "Vallelonga",
            codCat: "L607"
        },
        {
            name: "Vazzano",
            codCat: "L699"
        },
        {
            name: "Vibo Valentia",
            codCat: "F537"
        },
        {
            name: "Zaccanopoli",
            codCat: "M138"
        },
        {
            name: "Zambrone",
            codCat: "M143"
        },
        {
            name: "Zungri",
            codCat: "M204"
        },
        {
            name: "Alcamo",
            codCat: "A176"
        },
        {
            name: "Buseto Palizzolo",
            codCat: "B288"
        },
        {
            name: "Calatafimi-Segesta",
            codCat: "B385"
        },
        {
            name: "Campobello di Mazara",
            codCat: "B521"
        },
        {
            name: "Castellammare del Golfo",
            codCat: "C130"
        },
        {
            name: "Castelvetrano",
            codCat: "C286"
        },
        {
            name: "Custonaci",
            codCat: "D234"
        },
        {
            name: "Erice",
            codCat: "D423"
        },
        {
            name: "Favignana",
            codCat: "D518"
        },
        {
            name: "Gibellina",
            codCat: "E023"
        },
        {
            name: "Marsala",
            codCat: "E974"
        },
        {
            name: "Mazara del Vallo",
            codCat: "F061"
        },
        {
            name: "Paceco",
            codCat: "G208"
        },
        {
            name: "Pantelleria",
            codCat: "G315"
        },
        {
            name: "Partanna",
            codCat: "G347"
        },
        {
            name: "Poggioreale",
            codCat: "G767"
        },
        {
            name: "Salaparuta",
            codCat: "H688"
        },
        {
            name: "Salemi",
            codCat: "H700"
        },
        {
            name: "Santa Ninfa",
            codCat: "I291"
        },
        {
            name: "San Vito Lo Capo",
            codCat: "I407"
        },
        {
            name: "Trapani",
            codCat: "L331"
        },
        {
            name: "Valderice",
            codCat: "G319"
        },
        {
            name: "Vita",
            codCat: "M081"
        },
        {
            name: "Petrosino",
            codCat: "M281"
        },
        {
            name: "Misiliscemi",
            codCat: "M432"
        },
        {
            name: "Alia",
            codCat: "A195"
        },
        {
            name: "Alimena",
            codCat: "A202"
        },
        {
            name: "Aliminusa",
            codCat: "A203"
        },
        {
            name: "Altavilla Milicia",
            codCat: "A229"
        },
        {
            name: "Altofonte",
            codCat: "A239"
        },
        {
            name: "Bagheria",
            codCat: "A546"
        },
        {
            name: "Balestrate",
            codCat: "A592"
        },
        {
            name: "Baucina",
            codCat: "A719"
        },
        {
            name: "Belmonte Mezzagno",
            codCat: "A764"
        },
        {
            name: "Bisacquino",
            codCat: "A882"
        },
        {
            name: "Bolognetta",
            codCat: "A946"
        },
        {
            name: "Bompietro",
            codCat: "A958"
        },
        {
            name: "Borgetto",
            codCat: "A991"
        },
        {
            name: "Caccamo",
            codCat: "B315"
        },
        {
            name: "Caltavuturo",
            codCat: "B430"
        },
        {
            name: "Campofelice di Fitalia",
            codCat: "B533"
        },
        {
            name: "Campofelice di Roccella",
            codCat: "B532"
        },
        {
            name: "Campofiorito",
            codCat: "B535"
        },
        {
            name: "Camporeale",
            codCat: "B556"
        },
        {
            name: "Capaci",
            codCat: "B645"
        },
        {
            name: "Carini",
            codCat: "B780"
        },
        {
            name: "Castelbuono",
            codCat: "C067"
        },
        {
            name: "Casteldaccia",
            codCat: "C074"
        },
        {
            name: "Castellana Sicula",
            codCat: "C135"
        },
        {
            name: "Castronovo di Sicilia",
            codCat: "C344"
        },
        {
            name: "Cefalà Diana",
            codCat: "C420"
        },
        {
            name: "Cefalù",
            codCat: "C421"
        },
        {
            name: "Cerda",
            codCat: "C496"
        },
        {
            name: "Chiusa Sclafani",
            codCat: "C654"
        },
        {
            name: "Ciminna",
            codCat: "C696"
        },
        {
            name: "Cinisi",
            codCat: "C708"
        },
        {
            name: "Collesano",
            codCat: "C871"
        },
        {
            name: "Contessa Entellina",
            codCat: "C968"
        },
        {
            name: "Corleone",
            codCat: "D009"
        },
        {
            name: "Ficarazzi",
            codCat: "D567"
        },
        {
            name: "Gangi",
            codCat: "D907"
        },
        {
            name: "Geraci Siculo",
            codCat: "D977"
        },
        {
            name: "Giardinello",
            codCat: "E013"
        },
        {
            name: "Giuliana",
            codCat: "E055"
        },
        {
            name: "Godrano",
            codCat: "E074"
        },
        {
            name: "Gratteri",
            codCat: "E149"
        },
        {
            name: "Isnello",
            codCat: "E337"
        },
        {
            name: "Isola delle Femmine",
            codCat: "E350"
        },
        {
            name: "Lascari",
            codCat: "E459"
        },
        {
            name: "Lercara Friddi",
            codCat: "E541"
        },
        {
            name: "Marineo",
            codCat: "E957"
        },
        {
            name: "Mezzojuso",
            codCat: "F184"
        },
        {
            name: "Misilmeri",
            codCat: "F246"
        },
        {
            name: "Monreale",
            codCat: "F377"
        },
        {
            name: "Montelepre",
            codCat: "F544"
        },
        {
            name: "Montemaggiore Belsito",
            codCat: "F553"
        },
        {
            name: "Palazzo Adriano",
            codCat: "G263"
        },
        {
            name: "Palermo",
            codCat: "G273"
        },
        {
            name: "Partinico",
            codCat: "G348"
        },
        {
            name: "Petralia Soprana",
            codCat: "G510"
        },
        {
            name: "Petralia Sottana",
            codCat: "G511"
        },
        {
            name: "Piana degli Albanesi",
            codCat: "G543"
        },
        {
            name: "Polizzi Generosa",
            codCat: "G792"
        },
        {
            name: "Pollina",
            codCat: "G797"
        },
        {
            name: "Prizzi",
            codCat: "H070"
        },
        {
            name: "Roccamena",
            codCat: "H422"
        },
        {
            name: "Roccapalumba",
            codCat: "H428"
        },
        {
            name: "San Cipirello",
            codCat: "H797"
        },
        {
            name: "San Giuseppe Jato",
            codCat: "H933"
        },
        {
            name: "San Mauro Castelverde",
            codCat: "I028"
        },
        {
            name: "Santa Cristina Gela",
            codCat: "I174"
        },
        {
            name: "Santa Flavia",
            codCat: "I188"
        },
        {
            name: "Sciara",
            codCat: "I534"
        },
        {
            name: "Sclafani Bagni",
            codCat: "I541"
        },
        {
            name: "Termini Imerese",
            codCat: "L112"
        },
        {
            name: "Terrasini",
            codCat: "L131"
        },
        {
            name: "Torretta",
            codCat: "L282"
        },
        {
            name: "Trabia",
            codCat: "L317"
        },
        {
            name: "Trappeto",
            codCat: "L332"
        },
        {
            name: "Ustica",
            codCat: "L519"
        },
        {
            name: "Valledolmo",
            codCat: "L603"
        },
        {
            name: "Ventimiglia di Sicilia",
            codCat: "L740"
        },
        {
            name: "Vicari",
            codCat: "L837"
        },
        {
            name: "Villabate",
            codCat: "L916"
        },
        {
            name: "Villafrati",
            codCat: "L951"
        },
        {
            name: "Scillato",
            codCat: "I538"
        },
        {
            name: "Blufi",
            codCat: "M268"
        },
        {
            name: "Alcara li Fusi",
            codCat: "A177"
        },
        {
            name: "Alì",
            codCat: "A194"
        },
        {
            name: "Alì Terme",
            codCat: "A201"
        },
        {
            name: "Antillo",
            codCat: "A313"
        },
        {
            name: "Barcellona Pozzo di Gotto",
            codCat: "A638"
        },
        {
            name: "Basicò",
            codCat: "A698"
        },
        {
            name: "Brolo",
            codCat: "B198"
        },
        {
            name: "Capizzi",
            codCat: "B660"
        },
        {
            name: "Capo d'Orlando",
            codCat: "B666"
        },
        {
            name: "Capri Leone",
            codCat: "B695"
        },
        {
            name: "Caronia",
            codCat: "B804"
        },
        {
            name: "Casalvecchio Siculo",
            codCat: "B918"
        },
        {
            name: "Castel di Lucio",
            codCat: "C094"
        },
        {
            name: "Castell'Umberto",
            codCat: "C051"
        },
        {
            name: "Castelmola",
            codCat: "C210"
        },
        {
            name: "Castroreale",
            codCat: "C347"
        },
        {
            name: "Cesarò",
            codCat: "C568"
        },
        {
            name: "Condrò",
            codCat: "C956"
        },
        {
            name: "Falcone",
            codCat: "D474"
        },
        {
            name: "Ficarra",
            codCat: "D569"
        },
        {
            name: "Fiumedinisi",
            codCat: "D622"
        },
        {
            name: "Floresta",
            codCat: "D635"
        },
        {
            name: "Fondachelli-Fantina",
            codCat: "D661"
        },
        {
            name: "Forza d'Agrò",
            codCat: "D733"
        },
        {
            name: "Francavilla di Sicilia",
            codCat: "D765"
        },
        {
            name: "Frazzanò",
            codCat: "D793"
        },
        {
            name: "Furci Siculo",
            codCat: "D824"
        },
        {
            name: "Furnari",
            codCat: "D825"
        },
        {
            name: "Gaggi",
            codCat: "D844"
        },
        {
            name: "Galati Mamertino",
            codCat: "D861"
        },
        {
            name: "Gallodoro",
            codCat: "D885"
        },
        {
            name: "Giardini-Naxos",
            codCat: "E014"
        },
        {
            name: "Gioiosa Marea",
            codCat: "E043"
        },
        {
            name: "Graniti",
            codCat: "E142"
        },
        {
            name: "Gualtieri Sicaminò",
            codCat: "E233"
        },
        {
            name: "Itala",
            codCat: "E374"
        },
        {
            name: "Leni",
            codCat: "E523"
        },
        {
            name: "Letojanni",
            codCat: "E555"
        },
        {
            name: "Librizzi",
            codCat: "E571"
        },
        {
            name: "Limina",
            codCat: "E594"
        },
        {
            name: "Lipari",
            codCat: "E606"
        },
        {
            name: "Longi",
            codCat: "E674"
        },
        {
            name: "Malfa",
            codCat: "E855"
        },
        {
            name: "Malvagna",
            codCat: "E869"
        },
        {
            name: "Mandanici",
            codCat: "E876"
        },
        {
            name: "Mazzarrà Sant'Andrea",
            codCat: "F066"
        },
        {
            name: "Merì",
            codCat: "F147"
        },
        {
            name: "Messina",
            codCat: "F158"
        },
        {
            name: "Milazzo",
            codCat: "F206"
        },
        {
            name: "Militello Rosmarino",
            codCat: "F210"
        },
        {
            name: "Mirto",
            codCat: "F242"
        },
        {
            name: "Mistretta",
            codCat: "F251"
        },
        {
            name: "Moio Alcantara",
            codCat: "F277"
        },
        {
            name: "Monforte San Giorgio",
            codCat: "F359"
        },
        {
            name: "Mongiuffi Melia",
            codCat: "F368"
        },
        {
            name: "Montagnareale",
            codCat: "F395"
        },
        {
            name: "Montalbano Elicona",
            codCat: "F400"
        },
        {
            name: "Motta Camastra",
            codCat: "F772"
        },
        {
            name: "Motta d'Affermo",
            codCat: "F773"
        },
        {
            name: "Naso",
            codCat: "F848"
        },
        {
            name: "Nizza di Sicilia",
            codCat: "F901"
        },
        {
            name: "Novara di Sicilia",
            codCat: "F951"
        },
        {
            name: "Oliveri",
            codCat: "G036"
        },
        {
            name: "Pace del Mela",
            codCat: "G209"
        },
        {
            name: "Pagliara",
            codCat: "G234"
        },
        {
            name: "Patti",
            codCat: "G377"
        },
        {
            name: "Pettineo",
            codCat: "G522"
        },
        {
            name: "Piraino",
            codCat: "G699"
        },
        {
            name: "Raccuja",
            codCat: "H151"
        },
        {
            name: "Reitano",
            codCat: "H228"
        },
        {
            name: "Roccafiorita",
            codCat: "H405"
        },
        {
            name: "Roccalumera",
            codCat: "H418"
        },
        {
            name: "Roccavaldina",
            codCat: "H380"
        },
        {
            name: "Roccella Valdemone",
            codCat: "H455"
        },
        {
            name: "Rodì Milici",
            codCat: "H479"
        },
        {
            name: "Rometta",
            codCat: "H519"
        },
        {
            name: "San Filippo del Mela",
            codCat: "H842"
        },
        {
            name: "San Fratello",
            codCat: "H850"
        },
        {
            name: "San Marco d'Alunzio",
            codCat: "H982"
        },
        {
            name: "San Pier Niceto",
            codCat: "I084"
        },
        {
            name: "San Piero Patti",
            codCat: "I086"
        },
        {
            name: "San Salvatore di Fitalia",
            codCat: "I147"
        },
        {
            name: "Santa Domenica Vittoria",
            codCat: "I184"
        },
        {
            name: "Sant'Agata di Militello",
            codCat: "I199"
        },
        {
            name: "Sant'Alessio Siculo",
            codCat: "I215"
        },
        {
            name: "Santa Lucia del Mela",
            codCat: "I220"
        },
        {
            name: "Santa Marina Salina",
            codCat: "I254"
        },
        {
            name: "Sant'Angelo di Brolo",
            codCat: "I283"
        },
        {
            name: "Santa Teresa di Riva",
            codCat: "I311"
        },
        {
            name: "San Teodoro",
            codCat: "I328"
        },
        {
            name: "Santo Stefano di Camastra",
            codCat: "I370"
        },
        {
            name: "Saponara",
            codCat: "I420"
        },
        {
            name: "Savoca",
            codCat: "I477"
        },
        {
            name: "Scaletta Zanclea",
            codCat: "I492"
        },
        {
            name: "Sinagra",
            codCat: "I747"
        },
        {
            name: "Spadafora",
            codCat: "I881"
        },
        {
            name: "Taormina",
            codCat: "L042"
        },
        {
            name: "Torregrotta",
            codCat: "L271"
        },
        {
            name: "Tortorici",
            codCat: "L308"
        },
        {
            name: "Tripi",
            codCat: "L431"
        },
        {
            name: "Tusa",
            codCat: "L478"
        },
        {
            name: "Ucria",
            codCat: "L482"
        },
        {
            name: "Valdina",
            codCat: "L561"
        },
        {
            name: "Venetico",
            codCat: "L735"
        },
        {
            name: "Villafranca Tirrena",
            codCat: "L950"
        },
        {
            name: "Terme Vigliatore",
            codCat: "M210"
        },
        {
            name: "Acquedolci",
            codCat: "M211"
        },
        {
            name: "Torrenova",
            codCat: "M286"
        },
        {
            name: "Agrigento",
            codCat: "A089"
        },
        {
            name: "Alessandria della Rocca",
            codCat: "A181"
        },
        {
            name: "Aragona",
            codCat: "A351"
        },
        {
            name: "Bivona",
            codCat: "A896"
        },
        {
            name: "Burgio",
            codCat: "B275"
        },
        {
            name: "Calamonaci",
            codCat: "B377"
        },
        {
            name: "Caltabellotta",
            codCat: "B427"
        },
        {
            name: "Camastra",
            codCat: "B460"
        },
        {
            name: "Cammarata",
            codCat: "B486"
        },
        {
            name: "Campobello di Licata",
            codCat: "B520"
        },
        {
            name: "Canicattì",
            codCat: "B602"
        },
        {
            name: "Casteltermini",
            codCat: "C275"
        },
        {
            name: "Castrofilippo",
            codCat: "C341"
        },
        {
            name: "Cattolica Eraclea",
            codCat: "C356"
        },
        {
            name: "Cianciana",
            codCat: "C668"
        },
        {
            name: "Comitini",
            codCat: "C928"
        },
        {
            name: "Favara",
            codCat: "D514"
        },
        {
            name: "Grotte",
            codCat: "E209"
        },
        {
            name: "Joppolo Giancaxio",
            codCat: "E390"
        },
        {
            name: "Lampedusa e Linosa",
            codCat: "E431"
        },
        {
            name: "Licata",
            codCat: "E573"
        },
        {
            name: "Lucca Sicula",
            codCat: "E714"
        },
        {
            name: "Menfi",
            codCat: "F126"
        },
        {
            name: "Montallegro",
            codCat: "F414"
        },
        {
            name: "Montevago",
            codCat: "F655"
        },
        {
            name: "Naro",
            codCat: "F845"
        },
        {
            name: "Palma di Montechiaro",
            codCat: "G282"
        },
        {
            name: "Porto Empedocle",
            codCat: "F299"
        },
        {
            name: "Racalmuto",
            codCat: "H148"
        },
        {
            name: "Raffadali",
            codCat: "H159"
        },
        {
            name: "Ravanusa",
            codCat: "H194"
        },
        {
            name: "Realmonte",
            codCat: "H205"
        },
        {
            name: "Ribera",
            codCat: "H269"
        },
        {
            name: "Sambuca di Sicilia",
            codCat: "H743"
        },
        {
            name: "San Biagio Platani",
            codCat: "H778"
        },
        {
            name: "San Giovanni Gemini",
            codCat: "H914"
        },
        {
            name: "Santa Elisabetta",
            codCat: "I185"
        },
        {
            name: "Santa Margherita di Belice",
            codCat: "I224"
        },
        {
            name: "Sant'Angelo Muxaro",
            codCat: "I290"
        },
        {
            name: "Santo Stefano Quisquina",
            codCat: "I356"
        },
        {
            name: "Sciacca",
            codCat: "I533"
        },
        {
            name: "Siculiana",
            codCat: "I723"
        },
        {
            name: "Villafranca Sicula",
            codCat: "L944"
        },
        {
            name: "Acquaviva Platani",
            codCat: "A049"
        },
        {
            name: "Bompensiere",
            codCat: "A957"
        },
        {
            name: "Butera",
            codCat: "B302"
        },
        {
            name: "Caltanissetta",
            codCat: "B429"
        },
        {
            name: "Campofranco",
            codCat: "B537"
        },
        {
            name: "Delia",
            codCat: "D267"
        },
        {
            name: "Gela",
            codCat: "D960"
        },
        {
            name: "Marianopoli",
            codCat: "E953"
        },
        {
            name: "Mazzarino",
            codCat: "F065"
        },
        {
            name: "Milena",
            codCat: "E618"
        },
        {
            name: "Montedoro",
            codCat: "F489"
        },
        {
            name: "Mussomeli",
            codCat: "F830"
        },
        {
            name: "Niscemi",
            codCat: "F899"
        },
        {
            name: "Resuttano",
            codCat: "H245"
        },
        {
            name: "Riesi",
            codCat: "H281"
        },
        {
            name: "San Cataldo",
            codCat: "H792"
        },
        {
            name: "Santa Caterina Villarmosa",
            codCat: "I169"
        },
        {
            name: "Serradifalco",
            codCat: "I644"
        },
        {
            name: "Sommatino",
            codCat: "I824"
        },
        {
            name: "Sutera",
            codCat: "L016"
        },
        {
            name: "Vallelunga Pratameno",
            codCat: "L609"
        },
        {
            name: "Villalba",
            codCat: "L959"
        },
        {
            name: "Agira",
            codCat: "A070"
        },
        {
            name: "Aidone",
            codCat: "A098"
        },
        {
            name: "Assoro",
            codCat: "A478"
        },
        {
            name: "Barrafranca",
            codCat: "A676"
        },
        {
            name: "Calascibetta",
            codCat: "B381"
        },
        {
            name: "Catenanuova",
            codCat: "C353"
        },
        {
            name: "Centuripe",
            codCat: "C471"
        },
        {
            name: "Cerami",
            codCat: "C480"
        },
        {
            name: "Enna",
            codCat: "C342"
        },
        {
            name: "Gagliano Castelferrato",
            codCat: "D849"
        },
        {
            name: "Leonforte",
            codCat: "E536"
        },
        {
            name: "Nicosia",
            codCat: "F892"
        },
        {
            name: "Nissoria",
            codCat: "F900"
        },
        {
            name: "Piazza Armerina",
            codCat: "G580"
        },
        {
            name: "Pietraperzia",
            codCat: "G624"
        },
        {
            name: "Regalbuto",
            codCat: "H221"
        },
        {
            name: "Sperlinga",
            codCat: "I891"
        },
        {
            name: "Troina",
            codCat: "L448"
        },
        {
            name: "Valguarnera Caropepe",
            codCat: "L583"
        },
        {
            name: "Villarosa",
            codCat: "M011"
        },
        {
            name: "Aci Bonaccorsi",
            codCat: "A025"
        },
        {
            name: "Aci Castello",
            codCat: "A026"
        },
        {
            name: "Aci Catena",
            codCat: "A027"
        },
        {
            name: "Acireale",
            codCat: "A028"
        },
        {
            name: "Aci Sant'Antonio",
            codCat: "A029"
        },
        {
            name: "Adrano",
            codCat: "A056"
        },
        {
            name: "Belpasso",
            codCat: "A766"
        },
        {
            name: "Biancavilla",
            codCat: "A841"
        },
        {
            name: "Bronte",
            codCat: "B202"
        },
        {
            name: "Calatabiano",
            codCat: "B384"
        },
        {
            name: "Caltagirone",
            codCat: "B428"
        },
        {
            name: "Camporotondo Etneo",
            codCat: "B561"
        },
        {
            name: "Castel di Iudica",
            codCat: "C091"
        },
        {
            name: "Castiglione di Sicilia",
            codCat: "C297"
        },
        {
            name: "Catania",
            codCat: "C351"
        },
        {
            name: "Fiumefreddo di Sicilia",
            codCat: "D623"
        },
        {
            name: "Giarre",
            codCat: "E017"
        },
        {
            name: "Grammichele",
            codCat: "E133"
        },
        {
            name: "Gravina di Catania",
            codCat: "E156"
        },
        {
            name: "Licodia Eubea",
            codCat: "E578"
        },
        {
            name: "Linguaglossa",
            codCat: "E602"
        },
        {
            name: "Maletto",
            codCat: "E854"
        },
        {
            name: "Mascali",
            codCat: "F004"
        },
        {
            name: "Mascalucia",
            codCat: "F005"
        },
        {
            name: "Militello in Val di Catania",
            codCat: "F209"
        },
        {
            name: "Milo",
            codCat: "F214"
        },
        {
            name: "Mineo",
            codCat: "F217"
        },
        {
            name: "Mirabella Imbaccari",
            codCat: "F231"
        },
        {
            name: "Misterbianco",
            codCat: "F250"
        },
        {
            name: "Motta Sant'Anastasia",
            codCat: "F781"
        },
        {
            name: "Nicolosi",
            codCat: "F890"
        },
        {
            name: "Palagonia",
            codCat: "G253"
        },
        {
            name: "Paternò",
            codCat: "G371"
        },
        {
            name: "Pedara",
            codCat: "G402"
        },
        {
            name: "Piedimonte Etneo",
            codCat: "G597"
        },
        {
            name: "Raddusa",
            codCat: "H154"
        },
        {
            name: "Ramacca",
            codCat: "H168"
        },
        {
            name: "Randazzo",
            codCat: "H175"
        },
        {
            name: "Riposto",
            codCat: "H325"
        },
        {
            name: "San Cono",
            codCat: "H805"
        },
        {
            name: "San Giovanni la Punta",
            codCat: "H922"
        },
        {
            name: "San Gregorio di Catania",
            codCat: "H940"
        },
        {
            name: "San Michele di Ganzaria",
            codCat: "I035"
        },
        {
            name: "San Pietro Clarenza",
            codCat: "I098"
        },
        {
            name: "Sant'Agata li Battiati",
            codCat: "I202"
        },
        {
            name: "Sant'Alfio",
            codCat: "I216"
        },
        {
            name: "Santa Maria di Licodia",
            codCat: "I240"
        },
        {
            name: "Santa Venerina",
            codCat: "I314"
        },
        {
            name: "Scordia",
            codCat: "I548"
        },
        {
            name: "Trecastagni",
            codCat: "L355"
        },
        {
            name: "Tremestieri Etneo",
            codCat: "L369"
        },
        {
            name: "Valverde",
            codCat: "L658"
        },
        {
            name: "Viagrande",
            codCat: "L828"
        },
        {
            name: "Vizzini",
            codCat: "M100"
        },
        {
            name: "Zafferana Etnea",
            codCat: "M139"
        },
        {
            name: "Mazzarrone",
            codCat: "M271"
        },
        {
            name: "Maniace",
            codCat: "M283"
        },
        {
            name: "Ragalna",
            codCat: "M287"
        },
        {
            name: "Acate",
            codCat: "A014"
        },
        {
            name: "Chiaramonte Gulfi",
            codCat: "C612"
        },
        {
            name: "Comiso",
            codCat: "C927"
        },
        {
            name: "Giarratana",
            codCat: "E016"
        },
        {
            name: "Ispica",
            codCat: "E366"
        },
        {
            name: "Modica",
            codCat: "F258"
        },
        {
            name: "Monterosso Almo",
            codCat: "F610"
        },
        {
            name: "Pozzallo",
            codCat: "G953"
        },
        {
            name: "Ragusa",
            codCat: "H163"
        },
        {
            name: "Santa Croce Camerina",
            codCat: "I178"
        },
        {
            name: "Scicli",
            codCat: "I535"
        },
        {
            name: "Vittoria",
            codCat: "M088"
        },
        {
            name: "Augusta",
            codCat: "A494"
        },
        {
            name: "Avola",
            codCat: "A522"
        },
        {
            name: "Buccheri",
            codCat: "B237"
        },
        {
            name: "Buscemi",
            codCat: "B287"
        },
        {
            name: "Canicattini Bagni",
            codCat: "B603"
        },
        {
            name: "Carlentini",
            codCat: "B787"
        },
        {
            name: "Cassaro",
            codCat: "C006"
        },
        {
            name: "Ferla",
            codCat: "D540"
        },
        {
            name: "Floridia",
            codCat: "D636"
        },
        {
            name: "Francofonte",
            codCat: "D768"
        },
        {
            name: "Lentini",
            codCat: "E532"
        },
        {
            name: "Melilli",
            codCat: "F107"
        },
        {
            name: "Noto",
            codCat: "F943"
        },
        {
            name: "Pachino",
            codCat: "G211"
        },
        {
            name: "Palazzolo Acreide",
            codCat: "G267"
        },
        {
            name: "Rosolini",
            codCat: "H574"
        },
        {
            name: "Siracusa",
            codCat: "I754"
        },
        {
            name: "Solarino",
            codCat: "I785"
        },
        {
            name: "Sortino",
            codCat: "I864"
        },
        {
            name: "Portopalo di Capo Passero",
            codCat: "M257"
        },
        {
            name: "Priolo Gargallo",
            codCat: "M279"
        },
        {
            name: "Aggius",
            codCat: "A069"
        },
        {
            name: "Alà dei Sardi",
            codCat: "A115"
        },
        {
            name: "Alghero",
            codCat: "A192"
        },
        {
            name: "Anela",
            codCat: "A287"
        },
        {
            name: "Ardara",
            codCat: "A379"
        },
        {
            name: "Arzachena",
            codCat: "A453"
        },
        {
            name: "Banari",
            codCat: "A606"
        },
        {
            name: "Benetutti",
            codCat: "A781"
        },
        {
            name: "Berchidda",
            codCat: "A789"
        },
        {
            name: "Bessude",
            codCat: "A827"
        },
        {
            name: "Bonnanaro",
            codCat: "A976"
        },
        {
            name: "Bono",
            codCat: "A977"
        },
        {
            name: "Bonorva",
            codCat: "A978"
        },
        {
            name: "Bortigiadas",
            codCat: "B063"
        },
        {
            name: "Borutta",
            codCat: "B064"
        },
        {
            name: "Bottidda",
            codCat: "B094"
        },
        {
            name: "Buddusò",
            codCat: "B246"
        },
        {
            name: "Bultei",
            codCat: "B264"
        },
        {
            name: "Bulzi",
            codCat: "B265"
        },
        {
            name: "Burgos",
            codCat: "B276"
        },
        {
            name: "Calangianus",
            codCat: "B378"
        },
        {
            name: "Cargeghe",
            codCat: "B772"
        },
        {
            name: "Castelsardo",
            codCat: "C272"
        },
        {
            name: "Cheremule",
            codCat: "C600"
        },
        {
            name: "Chiaramonti",
            codCat: "C613"
        },
        {
            name: "Codrongianos",
            codCat: "C818"
        },
        {
            name: "Cossoine",
            codCat: "D100"
        },
        {
            name: "Esporlatu",
            codCat: "D441"
        },
        {
            name: "Florinas",
            codCat: "D637"
        },
        {
            name: "Giave",
            codCat: "E019"
        },
        {
            name: "Illorai",
            codCat: "E285"
        },
        {
            name: "Ittireddu",
            codCat: "E376"
        },
        {
            name: "Ittiri",
            codCat: "E377"
        },
        {
            name: "Laerru",
            codCat: "E401"
        },
        {
            name: "La Maddalena",
            codCat: "E425"
        },
        {
            name: "Luogosanto",
            codCat: "E747"
        },
        {
            name: "Luras",
            codCat: "E752"
        },
        {
            name: "Mara",
            codCat: "E902"
        },
        {
            name: "Martis",
            codCat: "E992"
        },
        {
            name: "Monteleone Rocca Doria",
            codCat: "F542"
        },
        {
            name: "Monti",
            codCat: "F667"
        },
        {
            name: "Mores",
            codCat: "F721"
        },
        {
            name: "Muros",
            codCat: "F818"
        },
        {
            name: "Nughedu San Nicolò",
            codCat: "F975"
        },
        {
            name: "Nule",
            codCat: "F976"
        },
        {
            name: "Nulvi",
            codCat: "F977"
        },
        {
            name: "Olbia",
            codCat: "G015"
        },
        {
            name: "Olmedo",
            codCat: "G046"
        },
        {
            name: "Oschiri",
            codCat: "G153"
        },
        {
            name: "Osilo",
            codCat: "G156"
        },
        {
            name: "Ossi",
            codCat: "G178"
        },
        {
            name: "Ozieri",
            codCat: "G203"
        },
        {
            name: "Padria",
            codCat: "G225"
        },
        {
            name: "Palau",
            codCat: "G258"
        },
        {
            name: "Pattada",
            codCat: "G376"
        },
        {
            name: "Perfugas",
            codCat: "G450"
        },
        {
            name: "Ploaghe",
            codCat: "G740"
        },
        {
            name: "Porto Torres",
            codCat: "G924"
        },
        {
            name: "Pozzomaggiore",
            codCat: "G962"
        },
        {
            name: "Putifigari",
            codCat: "H095"
        },
        {
            name: "Romana",
            codCat: "H507"
        },
        {
            name: "Aglientu",
            codCat: "H848"
        },
        {
            name: "Santa Teresa Gallura",
            codCat: "I312"
        },
        {
            name: "Sassari",
            codCat: "I452"
        },
        {
            name: "Sedini",
            codCat: "I565"
        },
        {
            name: "Semestene",
            codCat: "I598"
        },
        {
            name: "Sennori",
            codCat: "I614"
        },
        {
            name: "Siligo",
            codCat: "I732"
        },
        {
            name: "Sorso",
            codCat: "I863"
        },
        {
            name: "Tempio Pausania",
            codCat: "L093"
        },
        {
            name: "Thiesi",
            codCat: "L158"
        },
        {
            name: "Tissi",
            codCat: "L180"
        },
        {
            name: "Torralba",
            codCat: "L235"
        },
        {
            name: "Trinità d'Agultu e Vignola",
            codCat: "L428"
        },
        {
            name: "Tula",
            codCat: "L464"
        },
        {
            name: "Uri",
            codCat: "L503"
        },
        {
            name: "Usini",
            codCat: "L509"
        },
        {
            name: "Villanova Monteleone",
            codCat: "L989"
        },
        {
            name: "Valledoria",
            codCat: "L604"
        },
        {
            name: "Telti",
            codCat: "L088"
        },
        {
            name: "Badesi",
            codCat: "M214"
        },
        {
            name: "Viddalba",
            codCat: "M259"
        },
        {
            name: "Golfo Aranci",
            codCat: "M274"
        },
        {
            name: "Loiri Porto San Paolo",
            codCat: "M275"
        },
        {
            name: "Sant'Antonio di Gallura",
            codCat: "M276"
        },
        {
            name: "Tergu",
            codCat: "M282"
        },
        {
            name: "Santa Maria Coghinas",
            codCat: "M284"
        },
        {
            name: "Erula",
            codCat: "M292"
        },
        {
            name: "Stintino",
            codCat: "M290"
        },
        {
            name: "Padru",
            codCat: "M301"
        },
        {
            name: "Budoni",
            codCat: "B248"
        },
        {
            name: "San Teodoro",
            codCat: "I329"
        },
        {
            name: "Aritzo",
            codCat: "A407"
        },
        {
            name: "Arzana",
            codCat: "A454"
        },
        {
            name: "Atzara",
            codCat: "A492"
        },
        {
            name: "Austis",
            codCat: "A503"
        },
        {
            name: "Bari Sardo",
            codCat: "A663"
        },
        {
            name: "Baunei",
            codCat: "A722"
        },
        {
            name: "Belvì",
            codCat: "A776"
        },
        {
            name: "Birori",
            codCat: "A880"
        },
        {
            name: "Bitti",
            codCat: "A895"
        },
        {
            name: "Bolotana",
            codCat: "A948"
        },
        {
            name: "Borore",
            codCat: "B056"
        },
        {
            name: "Bortigali",
            codCat: "B062"
        },
        {
            name: "Desulo",
            codCat: "D287"
        },
        {
            name: "Dorgali",
            codCat: "D345"
        },
        {
            name: "Dualchi",
            codCat: "D376"
        },
        {
            name: "Elini",
            codCat: "D395"
        },
        {
            name: "Fonni",
            codCat: "D665"
        },
        {
            name: "Gadoni",
            codCat: "D842"
        },
        {
            name: "Gairo",
            codCat: "D859"
        },
        {
            name: "Galtellì",
            codCat: "D888"
        },
        {
            name: "Gavoi",
            codCat: "D947"
        },
        {
            name: "Girasole",
            codCat: "E049"
        },
        {
            name: "Ilbono",
            codCat: "E283"
        },
        {
            name: "Irgoli",
            codCat: "E323"
        },
        {
            name: "Jerzu",
            codCat: "E387"
        },
        {
            name: "Lanusei",
            codCat: "E441"
        },
        {
            name: "Lei",
            codCat: "E517"
        },
        {
            name: "Loceri",
            codCat: "E644"
        },
        {
            name: "Loculi",
            codCat: "E646"
        },
        {
            name: "Lodè",
            codCat: "E647"
        },
        {
            name: "Lotzorai",
            codCat: "E700"
        },
        {
            name: "Lula",
            codCat: "E736"
        },
        {
            name: "Macomer",
            codCat: "E788"
        },
        {
            name: "Mamoiada",
            codCat: "E874"
        },
        {
            name: "Meana Sardo",
            codCat: "F073"
        },
        {
            name: "Noragugume",
            codCat: "F933"
        },
        {
            name: "Nuoro",
            codCat: "F979"
        },
        {
            name: "Oliena",
            codCat: "G031"
        },
        {
            name: "Ollolai",
            codCat: "G044"
        },
        {
            name: "Olzai",
            codCat: "G058"
        },
        {
            name: "Onanì",
            codCat: "G064"
        },
        {
            name: "Onifai",
            codCat: "G070"
        },
        {
            name: "Oniferi",
            codCat: "G071"
        },
        {
            name: "Orani",
            codCat: "G084"
        },
        {
            name: "Orgosolo",
            codCat: "G097"
        },
        {
            name: "Orosei",
            codCat: "G119"
        },
        {
            name: "Orotelli",
            codCat: "G120"
        },
        {
            name: "Ortueri",
            codCat: "G146"
        },
        {
            name: "Orune",
            codCat: "G147"
        },
        {
            name: "Osidda",
            codCat: "G154"
        },
        {
            name: "Osini",
            codCat: "G158"
        },
        {
            name: "Ottana",
            codCat: "G191"
        },
        {
            name: "Ovodda",
            codCat: "G201"
        },
        {
            name: "Perdasdefogu",
            codCat: "G445"
        },
        {
            name: "Posada",
            codCat: "G929"
        },
        {
            name: "Sarule",
            codCat: "I448"
        },
        {
            name: "Silanus",
            codCat: "I730"
        },
        {
            name: "Sindia",
            codCat: "I748"
        },
        {
            name: "Siniscola",
            codCat: "I751"
        },
        {
            name: "Sorgono",
            codCat: "I851"
        },
        {
            name: "Talana",
            codCat: "L036"
        },
        {
            name: "Tertenia",
            codCat: "L140"
        },
        {
            name: "Teti",
            codCat: "L153"
        },
        {
            name: "Tiana",
            codCat: "L160"
        },
        {
            name: "Tonara",
            codCat: "L202"
        },
        {
            name: "Torpè",
            codCat: "L231"
        },
        {
            name: "Tortolì",
            codCat: "A355"
        },
        {
            name: "Triei",
            codCat: "L423"
        },
        {
            name: "Ulassai",
            codCat: "L489"
        },
        {
            name: "Urzulei",
            codCat: "L506"
        },
        {
            name: "Ussassai",
            codCat: "L514"
        },
        {
            name: "Villagrande Strisaili",
            codCat: "L953"
        },
        {
            name: "Cardedu",
            codCat: "M285"
        },
        {
            name: "Lodine",
            codCat: "E649"
        },
        {
            name: "Assemini",
            codCat: "A474"
        },
        {
            name: "Cagliari",
            codCat: "B354"
        },
        {
            name: "Capoterra",
            codCat: "B675"
        },
        {
            name: "Decimomannu",
            codCat: "D259"
        },
        {
            name: "Maracalagonis",
            codCat: "E903"
        },
        {
            name: "Pula",
            codCat: "H088"
        },
        {
            name: "Quartu Sant'Elena",
            codCat: "H118"
        },
        {
            name: "Sarroch",
            codCat: "I443"
        },
        {
            name: "Selargius",
            codCat: "I580"
        },
        {
            name: "Sestu",
            codCat: "I695"
        },
        {
            name: "Settimo San Pietro",
            codCat: "I699"
        },
        {
            name: "Sinnai",
            codCat: "I752"
        },
        {
            name: "Uta",
            codCat: "L521"
        },
        {
            name: "Villa San Pietro",
            codCat: "I118"
        },
        {
            name: "Quartucciu",
            codCat: "H119"
        },
        {
            name: "Elmas",
            codCat: "D399"
        },
        {
            name: "Monserrato",
            codCat: "F383"
        },
        {
            name: "Abbasanta",
            codCat: "A007"
        },
        {
            name: "Aidomaggiore",
            codCat: "A097"
        },
        {
            name: "Albagiara",
            codCat: "A126"
        },
        {
            name: "Ales",
            codCat: "A180"
        },
        {
            name: "Allai",
            codCat: "A204"
        },
        {
            name: "Arborea",
            codCat: "A357"
        },
        {
            name: "Ardauli",
            codCat: "A380"
        },
        {
            name: "Assolo",
            codCat: "A477"
        },
        {
            name: "Asuni",
            codCat: "A480"
        },
        {
            name: "Baradili",
            codCat: "A614"
        },
        {
            name: "Baratili San Pietro",
            codCat: "A621"
        },
        {
            name: "Baressa",
            codCat: "A655"
        },
        {
            name: "Bauladu",
            codCat: "A721"
        },
        {
            name: "Bidonì",
            codCat: "A856"
        },
        {
            name: "Bonarcado",
            codCat: "A960"
        },
        {
            name: "Boroneddu",
            codCat: "B055"
        },
        {
            name: "Busachi",
            codCat: "B281"
        },
        {
            name: "Cabras",
            codCat: "B314"
        },
        {
            name: "Cuglieri",
            codCat: "D200"
        },
        {
            name: "Fordongianus",
            codCat: "D695"
        },
        {
            name: "Ghilarza",
            codCat: "E004"
        },
        {
            name: "Gonnoscodina",
            codCat: "E087"
        },
        {
            name: "Gonnosnò",
            codCat: "D585"
        },
        {
            name: "Gonnostramatza",
            codCat: "E088"
        },
        {
            name: "Marrubiu",
            codCat: "E972"
        },
        {
            name: "Masullas",
            codCat: "F050"
        },
        {
            name: "Milis",
            codCat: "F208"
        },
        {
            name: "Mogorella",
            codCat: "F270"
        },
        {
            name: "Mogoro",
            codCat: "F272"
        },
        {
            name: "Morgongiori",
            codCat: "F727"
        },
        {
            name: "Narbolia",
            codCat: "F840"
        },
        {
            name: "Neoneli",
            codCat: "F867"
        },
        {
            name: "Norbello",
            codCat: "F934"
        },
        {
            name: "Nughedu Santa Vittoria",
            codCat: "F974"
        },
        {
            name: "Nurachi",
            codCat: "F980"
        },
        {
            name: "Nureci",
            codCat: "F985"
        },
        {
            name: "Ollastra",
            codCat: "G043"
        },
        {
            name: "Oristano",
            codCat: "G113"
        },
        {
            name: "Palmas Arborea",
            codCat: "G286"
        },
        {
            name: "Pau",
            codCat: "G379"
        },
        {
            name: "Paulilatino",
            codCat: "G384"
        },
        {
            name: "Pompu",
            codCat: "G817"
        },
        {
            name: "Riola Sardo",
            codCat: "H301"
        },
        {
            name: "Ruinas",
            codCat: "F271"
        },
        {
            name: "Samugheo",
            codCat: "H756"
        },
        {
            name: "San Nicolò d'Arcidano",
            codCat: "A368"
        },
        {
            name: "Santa Giusta",
            codCat: "I205"
        },
        {
            name: "Villa Sant'Antonio",
            codCat: "I298"
        },
        {
            name: "Santu Lussurgiu",
            codCat: "I374"
        },
        {
            name: "San Vero Milis",
            codCat: "I384"
        },
        {
            name: "Scano di Montiferro",
            codCat: "I503"
        },
        {
            name: "Sedilo",
            codCat: "I564"
        },
        {
            name: "Seneghe",
            codCat: "I605"
        },
        {
            name: "Senis",
            codCat: "I609"
        },
        {
            name: "Sennariolo",
            codCat: "I613"
        },
        {
            name: "Siamaggiore",
            codCat: "I717"
        },
        {
            name: "Siamanna",
            codCat: "I718"
        },
        {
            name: "Simala",
            codCat: "I742"
        },
        {
            name: "Simaxis",
            codCat: "I743"
        },
        {
            name: "Sini",
            codCat: "I749"
        },
        {
            name: "Siris",
            codCat: "I757"
        },
        {
            name: "Solarussa",
            codCat: "I791"
        },
        {
            name: "Sorradile",
            codCat: "I861"
        },
        {
            name: "Tadasuni",
            codCat: "L023"
        },
        {
            name: "Terralba",
            codCat: "L122"
        },
        {
            name: "Tramatza",
            codCat: "L321"
        },
        {
            name: "Tresnuraghes",
            codCat: "L393"
        },
        {
            name: "Ulà Tirso",
            codCat: "L488"
        },
        {
            name: "Uras",
            codCat: "L496"
        },
        {
            name: "Usellus",
            codCat: "L508"
        },
        {
            name: "Villanova Truschedu",
            codCat: "L991"
        },
        {
            name: "Villaurbana",
            codCat: "M030"
        },
        {
            name: "Villa Verde",
            codCat: "A609"
        },
        {
            name: "Zeddiani",
            codCat: "M153"
        },
        {
            name: "Zerfaliu",
            codCat: "M168"
        },
        {
            name: "Siapiccia",
            codCat: "I721"
        },
        {
            name: "Curcuris",
            codCat: "D214"
        },
        {
            name: "Soddì",
            codCat: "I778"
        },
        {
            name: "Bosa",
            codCat: "B068"
        },
        {
            name: "Flussio",
            codCat: "D640"
        },
        {
            name: "Laconi",
            codCat: "E400"
        },
        {
            name: "Magomadas",
            codCat: "E825"
        },
        {
            name: "Modolo",
            codCat: "F261"
        },
        {
            name: "Montresta",
            codCat: "F698"
        },
        {
            name: "Sagama",
            codCat: "H661"
        },
        {
            name: "Suni",
            codCat: "L006"
        },
        {
            name: "Tinnura",
            codCat: "L172"
        },
        {
            name: "Arbus",
            codCat: "A359"
        },
        {
            name: "Armungia",
            codCat: "A419"
        },
        {
            name: "Ballao",
            codCat: "A597"
        },
        {
            name: "Barrali",
            codCat: "A677"
        },
        {
            name: "Barumini",
            codCat: "A681"
        },
        {
            name: "Buggerru",
            codCat: "B250"
        },
        {
            name: "Burcei",
            codCat: "B274"
        },
        {
            name: "Calasetta",
            codCat: "B383"
        },
        {
            name: "Carbonia",
            codCat: "B745"
        },
        {
            name: "Carloforte",
            codCat: "B789"
        },
        {
            name: "Castiadas",
            codCat: "M288"
        },
        {
            name: "Collinas",
            codCat: "C882"
        },
        {
            name: "Decimoputzu",
            codCat: "D260"
        },
        {
            name: "Dolianova",
            codCat: "D323"
        },
        {
            name: "Domus de Maria",
            codCat: "D333"
        },
        {
            name: "Domusnovas",
            codCat: "D334"
        },
        {
            name: "Donori",
            codCat: "D344"
        },
        {
            name: "Escalaplano",
            codCat: "D430"
        },
        {
            name: "Escolca",
            codCat: "D431"
        },
        {
            name: "Esterzili",
            codCat: "D443"
        },
        {
            name: "Fluminimaggiore",
            codCat: "D639"
        },
        {
            name: "Furtei",
            codCat: "D827"
        },
        {
            name: "Genoni",
            codCat: "D968"
        },
        {
            name: "Genuri",
            codCat: "D970"
        },
        {
            name: "Gergei",
            codCat: "D982"
        },
        {
            name: "Gesico",
            codCat: "D994"
        },
        {
            name: "Gesturi",
            codCat: "D997"
        },
        {
            name: "Giba",
            codCat: "E022"
        },
        {
            name: "Goni",
            codCat: "E084"
        },
        {
            name: "Gonnesa",
            codCat: "E086"
        },
        {
            name: "Gonnosfanadiga",
            codCat: "E085"
        },
        {
            name: "Guamaggiore",
            codCat: "E234"
        },
        {
            name: "Guasila",
            codCat: "E252"
        },
        {
            name: "Guspini",
            codCat: "E270"
        },
        {
            name: "Iglesias",
            codCat: "E281"
        },
        {
            name: "Isili",
            codCat: "E336"
        },
        {
            name: "Las Plassas",
            codCat: "E464"
        },
        {
            name: "Lunamatrona",
            codCat: "E742"
        },
        {
            name: "Mandas",
            codCat: "E877"
        },
        {
            name: "Masainas",
            codCat: "M270"
        },
        {
            name: "Monastir",
            codCat: "F333"
        },
        {
            name: "Muravera",
            codCat: "F808"
        },
        {
            name: "Musei",
            codCat: "F822"
        },
        {
            name: "Narcao",
            codCat: "F841"
        },
        {
            name: "Nuragus",
            codCat: "F981"
        },
        {
            name: "Nurallao",
            codCat: "F982"
        },
        {
            name: "Nuraminis",
            codCat: "F983"
        },
        {
            name: "Nurri",
            codCat: "F986"
        },
        {
            name: "Nuxis",
            codCat: "F991"
        },
        {
            name: "Orroli",
            codCat: "G122"
        },
        {
            name: "Ortacesus",
            codCat: "G133"
        },
        {
            name: "Pabillonis",
            codCat: "G207"
        },
        {
            name: "Pauli Arbarei",
            codCat: "G382"
        },
        {
            name: "Perdaxius",
            codCat: "G446"
        },
        {
            name: "Pimentel",
            codCat: "G669"
        },
        {
            name: "Piscinas",
            codCat: "M291"
        },
        {
            name: "Portoscuso",
            codCat: "G922"
        },
        {
            name: "Sadali",
            codCat: "H659"
        },
        {
            name: "Samassi",
            codCat: "H738"
        },
        {
            name: "Samatzai",
            codCat: "H739"
        },
        {
            name: "San Basilio",
            codCat: "H766"
        },
        {
            name: "San Gavino Monreale",
            codCat: "H856"
        },
        {
            name: "San Giovanni Suergiu",
            codCat: "G287"
        },
        {
            name: "San Nicolò Gerrei",
            codCat: "G383"
        },
        {
            name: "San Sperate",
            codCat: "I166"
        },
        {
            name: "San Vito",
            codCat: "I402"
        },
        {
            name: "Sanluri",
            codCat: "H974"
        },
        {
            name: "Santadi",
            codCat: "I182"
        },
        {
            name: "Sant'Andrea Frius",
            codCat: "I271"
        },
        {
            name: "Sant'Anna Arresi",
            codCat: "M209"
        },
        {
            name: "Sant'Antioco",
            codCat: "I294"
        },
        {
            name: "Sardara",
            codCat: "I428"
        },
        {
            name: "Segariu",
            codCat: "I570"
        },
        {
            name: "Selegas",
            codCat: "I582"
        },
        {
            name: "Senorbì",
            codCat: "I615"
        },
        {
            name: "Serdiana",
            codCat: "I624"
        },
        {
            name: "Serramanna",
            codCat: "I647"
        },
        {
            name: "Serrenti",
            codCat: "I667"
        },
        {
            name: "Serri",
            codCat: "I668"
        },
        {
            name: "Setzu",
            codCat: "I705"
        },
        {
            name: "Seui",
            codCat: "I706"
        },
        {
            name: "Seulo",
            codCat: "I707"
        },
        {
            name: "Siddi",
            codCat: "I724"
        },
        {
            name: "Siliqua",
            codCat: "I734"
        },
        {
            name: "Silius",
            codCat: "I735"
        },
        {
            name: "Siurgus Donigala",
            codCat: "I765"
        },
        {
            name: "Soleminis",
            codCat: "I797"
        },
        {
            name: "Suelli",
            codCat: "I995"
        },
        {
            name: "Teulada",
            codCat: "L154"
        },
        {
            name: "Tratalias",
            codCat: "L337"
        },
        {
            name: "Tuili",
            codCat: "L463"
        },
        {
            name: "Turri",
            codCat: "L473"
        },
        {
            name: "Ussana",
            codCat: "L512"
        },
        {
            name: "Ussaramanna",
            codCat: "L513"
        },
        {
            name: "Vallermosa",
            codCat: "L613"
        },
        {
            name: "Villacidro",
            codCat: "L924"
        },
        {
            name: "Villamar",
            codCat: "L966"
        },
        {
            name: "Villamassargia",
            codCat: "L968"
        },
        {
            name: "Villanova Tulo",
            codCat: "L992"
        },
        {
            name: "Villanovaforru",
            codCat: "L986"
        },
        {
            name: "Villanovafranca",
            codCat: "L987"
        },
        {
            name: "Villaperuccio",
            codCat: "M278"
        },
        {
            name: "Villaputzu",
            codCat: "L998"
        },
        {
            name: "Villasalto",
            codCat: "M016"
        },
        {
            name: "Villasimius",
            codCat: "B738"
        },
        {
            name: "Villasor",
            codCat: "M025"
        },
        {
            name: "Villaspeciosa",
            codCat: "M026"
        }
    ]